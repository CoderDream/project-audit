INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1', N'ExperienceLevelInfo', N'ExperienceLevel', N'ExperienceLevel', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2', N'ExperienceLevelInfo', N'EL01', N'轻度接触', N'1', null, N'参与过相关领域1到2个小型项目，非主导角色，大体了解一些领域里关键概念')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3', N'ExperienceLevelInfo', N'EL02', N'领域专家', N'1', null, N'对领域内的全局到局部有充分的掌握，10000小时以上工作经历')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'4', N'ExperienceLevelInfo', N'EL03', N'部分精通', N'1', null, N'在领域内的局部有5000小时以上工作经历，对局部概念、流程相当熟悉')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'5', N'MajorInfo', N'Major', N'', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'6', N'MajorInfo', N'M0001', N'旅游管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'7', N'MajorInfo', N'M0002', N'涉外旅游', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'8', N'MajorInfo', N'M0003', N'导游', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'9', N'MajorInfo', N'M0004', N'旅行社经营管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'10', N'MajorInfo', N'M0005', N'景区开发与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'11', N'MajorInfo', N'M0006', N'酒店管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'12', N'MajorInfo', N'M0007', N'餐饮管理与服务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'13', N'MajorInfo', N'M0008', N'烹饪工艺与营养', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'14', N'MajorInfo', N'M0009', N'旅游服务与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'15', N'MajorInfo', N'M0010', N'中国传统养生美容', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'16', N'MajorInfo', N'M0011', N'法学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'17', N'MajorInfo', N'M0012', N'法律', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'18', N'MajorInfo', N'M0013', N'知识产权', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'19', N'MajorInfo', N'M0014', N'监狱学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'20', N'MajorInfo', N'M0015', N'司法助理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'21', N'MajorInfo', N'M0016', N'法律文秘', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'22', N'MajorInfo', N'M0017', N'司法警务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'23', N'MajorInfo', N'M0018', N'法律事务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'24', N'MajorInfo', N'M0019', N'书记官', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'25', N'MajorInfo', N'M0020', N'刑事执行', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'26', N'MajorInfo', N'M0021', N'民事执行', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'27', N'MajorInfo', N'M0022', N'行政执行', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'28', N'MajorInfo', N'M0023', N'社会工作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'29', N'MajorInfo', N'M0024', N'社区管理与服务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'30', N'MajorInfo', N'M0025', N'青少年工作与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'31', N'MajorInfo', N'M0026', N'社会福利事业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'32', N'MajorInfo', N'M0027', N'公共关系', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'33', N'MajorInfo', N'M0028', N'商检技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'34', N'MajorInfo', N'M0029', N'人民武装', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'35', N'MajorInfo', N'M0030', N'涉外事务管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'36', N'MajorInfo', N'M0031', N'家政服务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'37', N'MajorInfo', N'M0032', N'老年服务与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'38', N'MajorInfo', N'M0033', N'社区康复', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'39', N'MajorInfo', N'M0034', N'心理咨询', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'40', N'MajorInfo', N'M0035', N'科技成果中介服务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'41', N'MajorInfo', N'M0036', N'职业中介服务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'42', N'MajorInfo', N'M0037', N'现代殡仪技术与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'43', N'MajorInfo', N'M0038', N'戒毒康复', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'44', N'MajorInfo', N'M0039', N'公共事务管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'45', N'MajorInfo', N'M0040', N'民政管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'46', N'MajorInfo', N'M0041', N'行政管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'47', N'MajorInfo', N'M0042', N'人力资源管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'48', N'MajorInfo', N'M0043', N'劳动与社会保障', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'49', N'MajorInfo', N'M0044', N'国土资源管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'50', N'MajorInfo', N'M0045', N'海关管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'51', N'MajorInfo', N'M0046', N'环境规划与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'52', N'MajorInfo', N'M0047', N'公共事业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'53', N'MajorInfo', N'M0048', N'土地资源管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'54', N'MajorInfo', N'M0049', N'公共关系学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'55', N'MajorInfo', N'M0050', N'公共政策学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'56', N'MajorInfo', N'M0051', N'城市管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'57', N'MajorInfo', N'M0052', N'公共管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'58', N'MajorInfo', N'M0053', N'文化产业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'59', N'MajorInfo', N'M0054', N'会展经济与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'60', N'MajorInfo', N'M0055', N'国防教育与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'61', N'MajorInfo', N'M0056', N'航运管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'62', N'MajorInfo', N'M0057', N'土地管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'63', N'MajorInfo', N'M0058', N'现代乡村综合管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'64', N'MajorInfo', N'M0059', N'历史学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'65', N'MajorInfo', N'M0060', N'世界历史', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'66', N'MajorInfo', N'M0061', N'考古学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'67', N'MajorInfo', N'M0062', N'博物馆学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'68', N'MajorInfo', N'M0063', N'民族学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'69', N'MajorInfo', N'M0064', N'文物保护技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'70', N'MajorInfo', N'M0065', N'社会学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'71', N'MajorInfo', N'M0066', N'社会工作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'72', N'MajorInfo', N'M0067', N'家政学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'73', N'MajorInfo', N'M0068', N'人类学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'74', N'MajorInfo', N'M0069', N'竞技体育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'75', N'MajorInfo', N'M0070', N'运动训练', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'76', N'MajorInfo', N'M0071', N'社会体育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'77', N'MajorInfo', N'M0072', N'体育保健', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'78', N'MajorInfo', N'M0073', N'体育服务与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'79', N'MajorInfo', N'M0074', N'体育教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'80', N'MajorInfo', N'M0075', N'运动训练', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'81', N'MajorInfo', N'M0076', N'社会体育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'82', N'MajorInfo', N'M0077', N'运动人体科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'83', N'MajorInfo', N'M0078', N'民族传统体育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'84', N'MajorInfo', N'M0079', N'体育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'85', N'MajorInfo', N'M0080', N'图书馆学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'86', N'MajorInfo', N'M0081', N'档案学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'87', N'MajorInfo', N'M0082', N'信息资源管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'88', N'MajorInfo', N'M0083', N'心理学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'89', N'MajorInfo', N'M0084', N'应用心理学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'90', N'MajorInfo', N'M0085', N'新闻学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'91', N'MajorInfo', N'M0086', N'广播电视新闻学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'92', N'MajorInfo', N'M0087', N'广告学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'93', N'MajorInfo', N'M0088', N'编辑出版学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'94', N'MajorInfo', N'M0089', N'传播学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'95', N'MajorInfo', N'M0090', N'媒体创意', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'96', N'MajorInfo', N'M0091', N'法制新闻', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'97', N'MajorInfo', N'M0092', N'新闻采编与制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'98', N'MajorInfo', N'M0093', N'传媒策划与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'99', N'MajorInfo', N'M0094', N'英语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'100', N'MajorInfo', N'M0095', N'俄语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'101', N'MajorInfo', N'M0096', N'德语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'102', N'MajorInfo', N'M0097', N'法语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'103', N'MajorInfo', N'M0098', N'西班牙语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'104', N'MajorInfo', N'M0099', N'阿拉伯语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'105', N'MajorInfo', N'M0100', N'日语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'106', N'MajorInfo', N'M0101', N'波斯语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'107', N'MajorInfo', N'M0102', N'朝鲜语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'108', N'MajorInfo', N'M0103', N'菲律宾语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'109', N'MajorInfo', N'M0104', N'梵语巴利语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'110', N'MajorInfo', N'M0105', N'印度尼西亚语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'111', N'MajorInfo', N'M0106', N'印地语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'112', N'MajorInfo', N'M0107', N'柬埔寨语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'113', N'MajorInfo', N'M0108', N'老挝语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'114', N'MajorInfo', N'M0109', N'缅甸语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'115', N'MajorInfo', N'M0110', N'马来语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'116', N'MajorInfo', N'M0111', N'蒙古语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'117', N'MajorInfo', N'M0112', N'僧加罗语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'118', N'MajorInfo', N'M0113', N'泰语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'119', N'MajorInfo', N'M0114', N'乌尔都语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'120', N'MajorInfo', N'M0115', N'希伯莱语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'121', N'MajorInfo', N'M0116', N'越南语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'122', N'MajorInfo', N'M0117', N'豪萨语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'123', N'MajorInfo', N'M0118', N'斯瓦希里语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'124', N'MajorInfo', N'M0119', N'阿尔巴尼亚语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'125', N'MajorInfo', N'M0120', N'保加利亚语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'126', N'MajorInfo', N'M0121', N'波兰语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'127', N'MajorInfo', N'M0122', N'捷克语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'128', N'MajorInfo', N'M0123', N'罗马尼亚语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'129', N'MajorInfo', N'M0124', N'葡萄牙语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'130', N'MajorInfo', N'M0125', N'瑞典语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'131', N'MajorInfo', N'M0126', N'塞尔维亚——克罗地亚语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'132', N'MajorInfo', N'M0127', N'土耳其语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'133', N'MajorInfo', N'M0128', N'希腊语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'134', N'MajorInfo', N'M0129', N'匈牙利语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'135', N'MajorInfo', N'M0130', N'意大利语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'136', N'MajorInfo', N'M0131', N'捷克语——斯洛伐克语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'137', N'MajorInfo', N'M0132', N'泰米尔语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'138', N'MajorInfo', N'M0133', N'普什图语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'139', N'MajorInfo', N'M0134', N'世界语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'140', N'MajorInfo', N'M0135', N'孟加拉语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'141', N'MajorInfo', N'M0136', N'尼泊尔语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'142', N'MajorInfo', N'M0137', N'塞尔维亚语——克罗地亚语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'143', N'MajorInfo', N'M0138', N'荷兰语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'144', N'MajorInfo', N'M0139', N'芬兰语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'145', N'MajorInfo', N'M0140', N'乌克兰语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'146', N'MajorInfo', N'M0141', N'韩国语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'147', N'MajorInfo', N'M0142', N'应用英语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'148', N'MajorInfo', N'M0143', N'应用日语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'149', N'MajorInfo', N'M0144', N'应用俄语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'150', N'MajorInfo', N'M0145', N'应用德语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'151', N'MajorInfo', N'M0146', N'应用法语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'152', N'MajorInfo', N'M0147', N'应用韩语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'153', N'MajorInfo', N'M0148', N'商务英语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'154', N'MajorInfo', N'M0149', N'旅游英语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'155', N'MajorInfo', N'M0150', N'商务日语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'156', N'MajorInfo', N'M0151', N'旅游日语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'157', N'MajorInfo', N'M0152', N'语文教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'158', N'MajorInfo', N'M0153', N'英语教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'159', N'MajorInfo', N'M0154', N'历史教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'160', N'MajorInfo', N'M0155', N'地理教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'161', N'MajorInfo', N'M0156', N'音乐教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'162', N'MajorInfo', N'M0157', N'美术教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'163', N'MajorInfo', N'M0158', N'思想政治教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'164', N'MajorInfo', N'M0159', N'初等教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'165', N'MajorInfo', N'M0160', N'学前教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'166', N'MajorInfo', N'M0161', N'儿童康复', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'167', N'MajorInfo', N'M0162', N'人群康复', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'168', N'MajorInfo', N'M0163', N'教育学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'169', N'MajorInfo', N'M0164', N'学前教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'170', N'MajorInfo', N'M0165', N'特殊教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'171', N'MajorInfo', N'M0166', N'小学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'172', N'MajorInfo', N'M0167', N'艺术教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'173', N'MajorInfo', N'M0168', N'人文教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'174', N'MajorInfo', N'M0169', N'言语听觉科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'175', N'MajorInfo', N'M0170', N'服装设计与工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'176', N'MajorInfo', N'M0171', N'装潢设计与工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'177', N'MajorInfo', N'M0172', N'旅游管理与服务教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'178', N'MajorInfo', N'M0173', N'烹饪与营养教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'179', N'MajorInfo', N'M0174', N'文秘教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'180', N'MajorInfo', N'M0175', N'综合文科', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'181', N'MajorInfo', N'M0176', N'幼儿教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'182', N'MajorInfo', N'M0177', N'中等师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'183', N'MajorInfo', N'M0178', N'汉语言文学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'184', N'MajorInfo', N'M0179', N'音乐学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'185', N'MajorInfo', N'M0180', N'作曲与作曲技术理论', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'186', N'MajorInfo', N'M0181', N'音乐表演', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'187', N'MajorInfo', N'M0182', N'绘画', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'188', N'MajorInfo', N'M0183', N'雕塑', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'189', N'MajorInfo', N'M0184', N'美术学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'190', N'MajorInfo', N'M0185', N'艺术设计学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'191', N'MajorInfo', N'M0186', N'艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'192', N'MajorInfo', N'M0187', N'舞蹈学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'193', N'MajorInfo', N'M0188', N'舞蹈编导', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'194', N'MajorInfo', N'M0189', N'戏剧学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'195', N'MajorInfo', N'M0190', N'表演', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'196', N'MajorInfo', N'M0191', N'导演', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'197', N'MajorInfo', N'M0192', N'戏剧影视文学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'198', N'MajorInfo', N'M0193', N'戏剧影视美术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'199', N'MajorInfo', N'M0194', N'摄影', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'200', N'MajorInfo', N'M0195', N'录音艺术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'201', N'MajorInfo', N'M0196', N'动画', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'202', N'MajorInfo', N'M0197', N'播音与主持艺术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'203', N'MajorInfo', N'M0198', N'广播电视编导', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'204', N'MajorInfo', N'M0199', N'影视教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'205', N'MajorInfo', N'M0200', N'艺术学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'206', N'MajorInfo', N'M0201', N'影视学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'207', N'MajorInfo', N'M0202', N'广播影视编导', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'208', N'MajorInfo', N'M0203', N'表演艺术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'209', N'MajorInfo', N'M0204', N'音乐表演', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'210', N'MajorInfo', N'M0205', N'舞蹈表演', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'211', N'MajorInfo', N'M0206', N'服装表演', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'212', N'MajorInfo', N'M0207', N'影视表演', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'213', N'MajorInfo', N'M0208', N'戏曲表演', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'214', N'MajorInfo', N'M0209', N'编导', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'215', N'MajorInfo', N'M0210', N'艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'216', N'MajorInfo', N'M0211', N'产品造型设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'217', N'MajorInfo', N'M0212', N'视觉传达艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'218', N'MajorInfo', N'M0213', N'电脑艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'219', N'MajorInfo', N'M0214', N'人物形象设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'220', N'MajorInfo', N'M0215', N'装潢艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'221', N'MajorInfo', N'M0216', N'装饰艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'222', N'MajorInfo', N'M0217', N'雕塑艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'223', N'MajorInfo', N'M0218', N'珠宝首饰工艺及鉴定', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'224', N'MajorInfo', N'M0219', N'雕刻艺术与家具设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'225', N'MajorInfo', N'M0220', N'旅游工艺品设计与制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'226', N'MajorInfo', N'M0221', N'广告设计与制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'227', N'MajorInfo', N'M0222', N'多媒体设计与制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'228', N'MajorInfo', N'M0223', N'包装与装饰设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'229', N'MajorInfo', N'M0224', N'服装设计与营销', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'230', N'MajorInfo', N'M0225', N'工艺美术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'231', N'MajorInfo', N'M0226', N'广告艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'232', N'MajorInfo', N'M0227', N'哲学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'233', N'MajorInfo', N'M0228', N'逻辑学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'234', N'MajorInfo', N'M0229', N'宗教学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'235', N'MajorInfo', N'M0230', N'伦理学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'236', N'MajorInfo', N'M0231', N'科学社会主义与国际共产主义运动', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'237', N'MajorInfo', N'M0232', N'中国革命史与中国共产党党史', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'238', N'MajorInfo', N'M0233', N'政治学与行政学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'239', N'MajorInfo', N'M0234', N'国际政治', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'240', N'MajorInfo', N'M0235', N'外交学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'241', N'MajorInfo', N'M0236', N'思想政治教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'242', N'MajorInfo', N'M0237', N'国际政治经济学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'243', N'MajorInfo', N'M0238', N'国际事务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'244', N'MajorInfo', N'M0239', N'汉语言文学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'245', N'MajorInfo', N'M0240', N'汉语言', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'246', N'MajorInfo', N'M0241', N'对外汉语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'247', N'MajorInfo', N'M0242', N'中国少数民族语言文学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'248', N'MajorInfo', N'M0243', N'古典文献', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'249', N'MajorInfo', N'M0244', N'中国语言文化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'250', N'MajorInfo', N'M0245', N'应用语言学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'251', N'MajorInfo', N'M0246', N'汉语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'252', N'MajorInfo', N'M0247', N'文秘', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'253', N'MajorInfo', N'M0248', N'文物鉴定与修复', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'254', N'MajorInfo', N'M0249', N'文化事业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'255', N'MajorInfo', N'M0250', N'文化市场经营与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'256', N'MajorInfo', N'M0251', N'图书档案管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'257', N'MajorInfo', N'M0252', N'汉语言文学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'258', N'MajorInfo', N'M0253', N'办公自动化与文秘', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'259', N'MajorInfo', N'M0254', N'秘书学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'260', N'MajorInfo', N'M0255', N'公关与文秘', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'261', N'MajorInfo', N'M0256', N'经济秘书', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'262', N'MajorInfo', N'M0257', N'商务秘书', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'263', N'MajorInfo', N'M0258', N'数学与应用数学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'264', N'MajorInfo', N'M0259', N'信息与计算科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'265', N'MajorInfo', N'M0260', N'数理基础科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'266', N'MajorInfo', N'M0261', N'数学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'267', N'MajorInfo', N'M0262', N'物理学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'268', N'MajorInfo', N'M0263', N'应用物理学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'269', N'MajorInfo', N'M0264', N'声学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'270', N'MajorInfo', N'M0265', N'理论与应用力学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'271', N'MajorInfo', N'M0266', N'物理电子技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'272', N'MajorInfo', N'M0267', N'物理教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'273', N'MajorInfo', N'M0268', N'化学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'274', N'MajorInfo', N'M0269', N'应用化学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'275', N'MajorInfo', N'M0270', N'化学生物学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'276', N'MajorInfo', N'M0271', N'分子科学与工程 ', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'277', N'MajorInfo', N'M0272', N'化学工程与工艺', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'278', N'MajorInfo', N'M0273', N'化学工程与工业生物工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'279', N'MajorInfo', N'M0274', N'资源科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'280', N'MajorInfo', N'M0275', N'应用化工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'281', N'MajorInfo', N'M0276', N'有机化工生产技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'282', N'MajorInfo', N'M0277', N'高聚物生产技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'283', N'MajorInfo', N'M0278', N'化纤生产技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'284', N'MajorInfo', N'M0279', N'精细化学品生产技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'285', N'MajorInfo', N'M0280', N'石油化工生产技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'286', N'MajorInfo', N'M0281', N'炼油技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'287', N'MajorInfo', N'M0282', N'工业分析与检验', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'288', N'MajorInfo', N'M0283', N'化工设备维修技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'289', N'MajorInfo', N'M0284', N'化学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'290', N'MajorInfo', N'M0285', N'生物科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'291', N'MajorInfo', N'M0286', N'生物技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'292', N'MajorInfo', N'M0287', N'生物信息学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'293', N'MajorInfo', N'M0288', N'生物信息技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'294', N'MajorInfo', N'M0289', N'生物科学与生物技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'295', N'MajorInfo', N'M0290', N'动植物检疫', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'296', N'MajorInfo', N'M0291', N'生物化学与分子生物学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'297', N'MajorInfo', N'M0292', N'医学信息学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'298', N'MajorInfo', N'M0293', N'植物生物技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'299', N'MajorInfo', N'M0294', N'动物生物技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'300', N'MajorInfo', N'M0295', N'生物资源科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'301', N'MajorInfo', N'M0296', N'生物工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'302', N'MajorInfo', N'M0297', N'生物技术及应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'303', N'MajorInfo', N'M0298', N'生物实验技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'304', N'MajorInfo', N'M0299', N'生物化工工艺', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'305', N'MajorInfo', N'M0300', N'微生物技术及应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'306', N'MajorInfo', N'M0301', N'天文学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'307', N'MajorInfo', N'M0302', N'大气科学技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'308', N'MajorInfo', N'M0303', N'大气探测技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'309', N'MajorInfo', N'M0304', N'应用气象技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'310', N'MajorInfo', N'M0305', N'防雷技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'311', N'MajorInfo', N'M0306', N'地理科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'312', N'MajorInfo', N'M0307', N'资源环境与城乡规划管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'313', N'MajorInfo', N'M0308', N'地理信息系统', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'314', N'MajorInfo', N'M0309', N'地理信息科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'315', N'MajorInfo', N'M0310', N'地球物理学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'316', N'MajorInfo', N'M0311', N'地球与空间科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'317', N'MajorInfo', N'M0312', N'空间科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'318', N'MajorInfo', N'M0313', N'大气科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'319', N'MajorInfo', N'M0314', N'应用气象学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'320', N'MajorInfo', N'M0315', N'海洋科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'321', N'MajorInfo', N'M0316', N'海洋技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'322', N'MajorInfo', N'M0317', N'海洋管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'323', N'MajorInfo', N'M0318', N'军事海洋学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'324', N'MajorInfo', N'M0319', N'海洋生物资源与环境', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'325', N'MajorInfo', N'M0320', N'地质学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'326', N'MajorInfo', N'M0321', N'地球化学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'327', N'MajorInfo', N'M0322', N'环境科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'328', N'MajorInfo', N'M0323', N'生态学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'329', N'MajorInfo', N'M0324', N'资源环境科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'330', N'MajorInfo', N'M0325', N'环境工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'331', N'MajorInfo', N'M0326', N'安全工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'332', N'MajorInfo', N'M0327', N'水质科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'333', N'MajorInfo', N'M0328', N'灾害防治工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'334', N'MajorInfo', N'M0329', N'环境科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'335', N'MajorInfo', N'M0330', N'环境监察', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'336', N'MajorInfo', N'M0331', N'园林', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'337', N'MajorInfo', N'M0332', N'水土保持与荒漠化防治', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'338', N'MajorInfo', N'M0333', N'农业资源与环境', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'339', N'MajorInfo', N'M0334', N'水土保持', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'340', N'MajorInfo', N'M0335', N'水环境监测与分析', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'341', N'MajorInfo', N'M0336', N'环境监测与治理技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'342', N'MajorInfo', N'M0337', N'环境监测与评价', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'343', N'MajorInfo', N'M0338', N'农业环境保护技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'344', N'MajorInfo', N'M0339', N'资源环境与城市管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'345', N'MajorInfo', N'M0340', N'城市检测与工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'346', N'MajorInfo', N'M0341', N'水环境监测与保护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'347', N'MajorInfo', N'M0342', N'城市水净化技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'348', N'MajorInfo', N'M0343', N'室内检测与控制技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'349', N'MajorInfo', N'M0344', N'工业环保与安全技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'350', N'MajorInfo', N'M0345', N'救援技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'351', N'MajorInfo', N'M0346', N'安全技术管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'352', N'MajorInfo', N'M0347', N'环境生态', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'353', N'MajorInfo', N'M0348', N'地质灾害防治', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'354', N'MajorInfo', N'M0349', N'统计学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'355', N'MajorInfo', N'M0350', N'统计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'356', N'MajorInfo', N'M0351', N'统计实务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'357', N'MajorInfo', N'M0352', N'调查与分析', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'358', N'MajorInfo', N'M0353', N'系统理论', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'359', N'MajorInfo', N'M0354', N'系统科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'360', N'MajorInfo', N'M0355', N'采矿工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'361', N'MajorInfo', N'M0356', N'石油工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'362', N'MajorInfo', N'M0357', N'矿物加工工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'363', N'MajorInfo', N'M0358', N'勘查技术与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'364', N'MajorInfo', N'M0359', N'资源勘查工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'365', N'MajorInfo', N'M0360', N'地质工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'366', N'MajorInfo', N'M0361', N'矿物资源工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'367', N'MajorInfo', N'M0362', N'煤矿开采技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'368', N'MajorInfo', N'M0363', N'金属矿开采技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'369', N'MajorInfo', N'M0364', N'非金属矿开采技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'370', N'MajorInfo', N'M0365', N'固体矿床露天开采技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'371', N'MajorInfo', N'M0366', N'沙矿床开采技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'372', N'MajorInfo', N'M0367', N'矿井建设', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'373', N'MajorInfo', N'M0368', N'矿山机电', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'374', N'MajorInfo', N'M0369', N'矿井通风与安全', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'375', N'MajorInfo', N'M0370', N'矿井运输与提升', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'376', N'MajorInfo', N'M0371', N'钻井技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'377', N'MajorInfo', N'M0372', N'油气开采技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'378', N'MajorInfo', N'M0373', N'油气储运技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'379', N'MajorInfo', N'M0374', N'油气藏分析技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'380', N'MajorInfo', N'M0375', N'油田化学应用技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'381', N'MajorInfo', N'M0376', N'石油与天然气地质勘探技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'382', N'MajorInfo', N'M0377', N'矿物加工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'383', N'MajorInfo', N'M0378', N'选矿技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'384', N'MajorInfo', N'M0379', N'选煤技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'385', N'MajorInfo', N'M0380', N'煤炭深加工与利用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'386', N'MajorInfo', N'M0381', N'煤质分析技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'387', N'MajorInfo', N'M0382', N'选矿机电技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'388', N'MajorInfo', N'M0383', N'国土资源调查', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'389', N'MajorInfo', N'M0384', N'区域地质调查及矿产普查', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'390', N'MajorInfo', N'M0385', N'煤田地质与勘查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'391', N'MajorInfo', N'M0386', N'油气地质与勘查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'392', N'MajorInfo', N'M0387', N'水文地质与勘查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'393', N'MajorInfo', N'M0388', N'金属矿产地质与勘查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'394', N'MajorInfo', N'M0389', N'铀矿地质与勘查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'395', N'MajorInfo', N'M0390', N'非金属矿产地质与勘查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'396', N'MajorInfo', N'M0391', N'岩矿分析与鉴定技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'397', N'MajorInfo', N'M0392', N'宝玉石鉴定与加工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'398', N'MajorInfo', N'M0393', N'矿山地质', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'399', N'MajorInfo', N'M0394', N'工程地质勘查', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'400', N'MajorInfo', N'M0395', N'水文与工程地质', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'401', N'MajorInfo', N'M0396', N'钻探技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'402', N'MajorInfo', N'M0397', N'地球物理勘查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'403', N'MajorInfo', N'M0398', N'地球物理测井技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'404', N'MajorInfo', N'M0399', N'地球化学勘查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'405', N'MajorInfo', N'M0400', N'宝石鉴定与营销', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'406', N'MajorInfo', N'M0401', N'冶金工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'407', N'MajorInfo', N'M0402', N'金属材料工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'408', N'MajorInfo', N'M0403', N'无机非金属材料工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'409', N'MajorInfo', N'M0404', N'高分子材料与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'410', N'MajorInfo', N'M0405', N'材料科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'411', N'MajorInfo', N'M0406', N'复合材料与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'412', N'MajorInfo', N'M0407', N'焊接技术与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'413', N'MajorInfo', N'M0408', N'宝石与材料工艺学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'414', N'MajorInfo', N'M0409', N'粉体材料科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'415', N'MajorInfo', N'M0410', N'再生资源科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'416', N'MajorInfo', N'M0411', N'稀土工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'417', N'MajorInfo', N'M0412', N'高分子材料加工工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'418', N'MajorInfo', N'M0413', N'生物功能材料', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'419', N'MajorInfo', N'M0414', N'材料物理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'420', N'MajorInfo', N'M0415', N'材料化学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'421', N'MajorInfo', N'M0416', N'金属材料与热处理技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'422', N'MajorInfo', N'M0417', N'冶金技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'423', N'MajorInfo', N'M0418', N'高分子材料应用技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'424', N'MajorInfo', N'M0419', N'复合材料加工与应用技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'425', N'MajorInfo', N'M0420', N'材料工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'426', N'MajorInfo', N'M0421', N'建筑装饰材料及检测', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'427', N'MajorInfo', N'M0422', N'机械设计制造及其自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'428', N'MajorInfo', N'M0423', N'材料成型及控制工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'429', N'MajorInfo', N'M0424', N'工业设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'430', N'MajorInfo', N'M0425', N'过程装备与控制工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'431', N'MajorInfo', N'M0426', N'机械工程及自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'432', N'MajorInfo', N'M0427', N'车辆工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'433', N'MajorInfo', N'M0428', N'机械电子工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'434', N'MajorInfo', N'M0429', N'汽车服务工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'435', N'MajorInfo', N'M0430', N'制造自动化与测控技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'436', N'MajorInfo', N'M0431', N'微机电系统工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'437', N'MajorInfo', N'M0432', N'制造工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'438', N'MajorInfo', N'M0433', N'测控技术与仪器', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'439', N'MajorInfo', N'M0434', N'电子信息技术及仪器', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'440', N'MajorInfo', N'M0435', N'机械设计与制造', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'441', N'MajorInfo', N'M0436', N'机械制造与自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'442', N'MajorInfo', N'M0437', N'数控技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'443', N'MajorInfo', N'M0438', N'电机与电器', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'444', N'MajorInfo', N'M0439', N'玩具设计与制造', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'445', N'MajorInfo', N'M0440', N'模具设计与制造', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'446', N'MajorInfo', N'M0441', N'材料成型与控制技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'447', N'MajorInfo', N'M0442', N'焊接技术及自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'448', N'MajorInfo', N'M0443', N'工业设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'449', N'MajorInfo', N'M0444', N'计算机辅助设计与制造', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'450', N'MajorInfo', N'M0445', N'精密机械技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'451', N'MajorInfo', N'M0446', N'医疗器械制造与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'452', N'MajorInfo', N'M0447', N'热能与动力工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'453', N'MajorInfo', N'M0448', N'核工程与核技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'454', N'MajorInfo', N'M0449', N'工程物理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'455', N'MajorInfo', N'M0450', N'能源环境工程及自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'456', N'MajorInfo', N'M0451', N'能源工程及自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'457', N'MajorInfo', N'M0452', N'能源动力系统及自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'458', N'MajorInfo', N'M0453', N'热能动力设备与应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'459', N'MajorInfo', N'M0454', N'城市热能应用技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'460', N'MajorInfo', N'M0455', N'农村能源与环境技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'461', N'MajorInfo', N'M0456', N'制冷与冷藏技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'462', N'MajorInfo', N'M0457', N'建筑学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'463', N'MajorInfo', N'M0458', N'城市规划', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'464', N'MajorInfo', N'M0459', N'土木工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'465', N'MajorInfo', N'M0460', N'建筑环境与设备工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'466', N'MajorInfo', N'M0461', N'给水排水工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'467', N'MajorInfo', N'M0462', N'城市地下空间工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'468', N'MajorInfo', N'M0463', N'历史建筑保护工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'469', N'MajorInfo', N'M0464', N'景观建筑设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'470', N'MajorInfo', N'M0465', N'水务工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'471', N'MajorInfo', N'M0466', N'建筑设施智能技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'472', N'MajorInfo', N'M0467', N'道路桥梁与渡河工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'473', N'MajorInfo', N'M0468', N'道路与桥梁工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'474', N'MajorInfo', N'M0469', N'道路与桥梁', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'475', N'MajorInfo', N'M0470', N'公路桥梁', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'476', N'MajorInfo', N'M0471', N'工业与民用建筑', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'477', N'MajorInfo', N'M0472', N'建筑工程结构检测', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'478', N'MajorInfo', N'M0473', N'工业与民用建筑工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'479', N'MajorInfo', N'M0474', N'房屋建筑工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'480', N'MajorInfo', N'M0475', N'建筑工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'481', N'MajorInfo', N'M0476', N'水利水电工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'482', N'MajorInfo', N'M0477', N'水文与水资源工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'483', N'MajorInfo', N'M0478', N'港口航道与海岸工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'484', N'MajorInfo', N'M0479', N'港口海岸及治河工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'485', N'MajorInfo', N'M0480', N'水资源与海洋工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'486', N'MajorInfo', N'M0481', N'水利工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'487', N'MajorInfo', N'M0482', N'水利工程施工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'488', N'MajorInfo', N'M0483', N'水利水电建筑工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'489', N'MajorInfo', N'M0484', N'灌溉与排水技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'490', N'MajorInfo', N'M0485', N'港口航道与治河工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'491', N'MajorInfo', N'M0486', N'河务工程与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'492', N'MajorInfo', N'M0487', N'城市水利', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'493', N'MajorInfo', N'M0488', N'水利水电工程管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'494', N'MajorInfo', N'M0489', N'水务管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'495', N'MajorInfo', N'M0490', N'水利工程监理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'496', N'MajorInfo', N'M0491', N'水电站动力设备与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'497', N'MajorInfo', N'M0492', N'机电设备运行与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'498', N'MajorInfo', N'M0493', N'机电排灌设备与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'499', N'MajorInfo', N'M0494', N'水利工程管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'500', N'MajorInfo', N'M0495', N'水利水电工程监理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'501', N'MajorInfo', N'M0496', N'测绘工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'502', N'MajorInfo', N'M0497', N'遥感科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'503', N'MajorInfo', N'M0498', N'空间信息与数字技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'504', N'MajorInfo', N'M0499', N'工程测量技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'505', N'MajorInfo', N'M0500', N'工程测量与监理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'506', N'MajorInfo', N'M0501', N'摄影测量与遥感技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'507', N'MajorInfo', N'M0502', N'大地测量与卫星定位技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'508', N'MajorInfo', N'M0503', N'地理信息系统与地图制图技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'509', N'MajorInfo', N'M0504', N'地籍测绘与土地管理信息技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'510', N'MajorInfo', N'M0505', N'矿山测量', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'511', N'MajorInfo', N'M0506', N'工程测量', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'512', N'MajorInfo', N'M0507', N'船舶与海洋工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'513', N'MajorInfo', N'M0508', N'食品科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'514', N'MajorInfo', N'M0509', N'轻化工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'515', N'MajorInfo', N'M0510', N'包装工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'516', N'MajorInfo', N'M0511', N'印刷工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'517', N'MajorInfo', N'M0512', N'纺织工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'518', N'MajorInfo', N'M0513', N'服装设计与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'519', N'MajorInfo', N'M0514', N'食品质量与安全', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'520', N'MajorInfo', N'M0515', N'酿酒工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'521', N'MajorInfo', N'M0516', N'葡萄与葡萄酒工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'522', N'MajorInfo', N'M0517', N'轻工生物技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'523', N'MajorInfo', N'M0518', N'农产品质量与安全', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'524', N'MajorInfo', N'M0519', N'染整技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'525', N'MajorInfo', N'M0520', N'高分子材料加工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'526', N'MajorInfo', N'M0521', N'制浆造纸技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'527', N'MajorInfo', N'M0522', N'香料香精工艺', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'528', N'MajorInfo', N'M0523', N'表面精饰工艺', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'529', N'MajorInfo', N'M0524', N'现代纺织技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'530', N'MajorInfo', N'M0525', N'针织技术与针织服装', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'531', N'MajorInfo', N'M0526', N'丝绸技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'532', N'MajorInfo', N'M0527', N'服装设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'533', N'MajorInfo', N'M0528', N'染织艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'534', N'MajorInfo', N'M0529', N'纺织品装饰艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'535', N'MajorInfo', N'M0530', N'新型纺织机电技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'536', N'MajorInfo', N'M0531', N'纺织品检验与贸易', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'537', N'MajorInfo', N'M0532', N'食品加工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'538', N'MajorInfo', N'M0533', N'食品营养与检测', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'539', N'MajorInfo', N'M0534', N'食品贮运与营销', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'540', N'MajorInfo', N'M0535', N'食品机械与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'541', N'MajorInfo', N'M0536', N'食品生物技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'542', N'MajorInfo', N'M0537', N'农畜特产品加工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'543', N'MajorInfo', N'M0538', N'粮食工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'544', N'MajorInfo', N'M0539', N'包装技术与设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'545', N'MajorInfo', N'M0540', N'印刷技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'546', N'MajorInfo', N'M0541', N'印刷图文信息处理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'547', N'MajorInfo', N'M0542', N'印刷设备及工艺', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'548', N'MajorInfo', N'M0543', N'出版与发行', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'549', N'MajorInfo', N'M0544', N'飞行器设计与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'550', N'MajorInfo', N'M0545', N'飞行器动力工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'551', N'MajorInfo', N'M0546', N'飞行器制造工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'552', N'MajorInfo', N'M0547', N'飞行器环境与生命保障工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'553', N'MajorInfo', N'M0548', N'航空航天工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'554', N'MajorInfo', N'M0549', N'工程力学与航天航空工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'555', N'MajorInfo', N'M0550', N'武器系统与发射工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'556', N'MajorInfo', N'M0551', N'探测制导与控制技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'557', N'MajorInfo', N'M0552', N'弹药工程与爆炸技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'558', N'MajorInfo', N'M0553', N'特种能源工程与烟火技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'559', N'MajorInfo', N'M0554', N'地面武器机动工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'560', N'MajorInfo', N'M0555', N'信息对抗技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'561', N'MajorInfo', N'M0556', N'武器系统与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'562', N'MajorInfo', N'M0557', N'工程力学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'563', N'MajorInfo', N'M0558', N'工程结构分析', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'564', N'MajorInfo', N'M0559', N'农业机械化及其自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'565', N'MajorInfo', N'M0560', N'农业电气化与自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'566', N'MajorInfo', N'M0561', N'农业建筑环境与能源工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'567', N'MajorInfo', N'M0562', N'农业水利工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'568', N'MajorInfo', N'M0563', N'农业工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'569', N'MajorInfo', N'M0564', N'生物系统工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'570', N'MajorInfo', N'M0565', N'作物生产技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'571', N'MajorInfo', N'M0566', N'种子生产与经营', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'572', N'MajorInfo', N'M0567', N'设施农业技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'573', N'MajorInfo', N'M0568', N'观光农业', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'574', N'MajorInfo', N'M0569', N'园艺技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'575', N'MajorInfo', N'M0570', N'茶叶生产加工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'576', N'MajorInfo', N'M0571', N'中草药栽培技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'577', N'MajorInfo', N'M0572', N'烟草栽培技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'578', N'MajorInfo', N'M0573', N'植物保护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'579', N'MajorInfo', N'M0574', N'植物检疫', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'580', N'MajorInfo', N'M0575', N'农产品质量检测', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'581', N'MajorInfo', N'M0576', N'森林工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'582', N'MajorInfo', N'M0577', N'木材科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'583', N'MajorInfo', N'M0578', N'林产化工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'584', N'MajorInfo', N'M0579', N'林业技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'585', N'MajorInfo', N'M0580', N'园林技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'586', N'MajorInfo', N'M0581', N'森林资源保护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'587', N'MajorInfo', N'M0582', N'野生植物资源开发与利用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'588', N'MajorInfo', N'M0583', N'野生动物保护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'589', N'MajorInfo', N'M0584', N'自然保护区建设与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'590', N'MajorInfo', N'M0585', N'森林生态旅游', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'591', N'MajorInfo', N'M0586', N'林产化工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'592', N'MajorInfo', N'M0587', N'木材加工技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'593', N'MajorInfo', N'M0588', N'森林采运工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'594', N'MajorInfo', N'M0589', N'生物资源开发与利用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'595', N'MajorInfo', N'M0590', N'农业推广', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'596', N'MajorInfo', N'M0591', N'农学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'597', N'MajorInfo', N'M0592', N'园艺', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'598', N'MajorInfo', N'M0593', N'植物保护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'599', N'MajorInfo', N'M0594', N'茶学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'600', N'MajorInfo', N'M0595', N'烟草', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'601', N'MajorInfo', N'M0596', N'植物科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'602', N'MajorInfo', N'M0597', N'种子科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'603', N'MajorInfo', N'M0598', N'应用生物科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'604', N'MajorInfo', N'M0599', N'设施农业科学与工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'605', N'MajorInfo', N'M0600', N'草业科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'606', N'MajorInfo', N'M0601', N'林学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'607', N'MajorInfo', N'M0602', N'森林资源保护与游憩', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'608', N'MajorInfo', N'M0603', N'野生动物与自然保护区管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'609', N'MajorInfo', N'M0604', N'动物科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'610', N'MajorInfo', N'M0605', N'蚕学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'611', N'MajorInfo', N'M0606', N'蜂学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'612', N'MajorInfo', N'M0607', N'动物医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'613', N'MajorInfo', N'M0608', N'动物药学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'614', N'MajorInfo', N'M0609', N'畜牧兽医', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'615', N'MajorInfo', N'M0610', N'畜牧', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'616', N'MajorInfo', N'M0611', N'饲料与动物营养', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'617', N'MajorInfo', N'M0612', N'特种动物养殖', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'618', N'MajorInfo', N'M0613', N'兽医', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'619', N'MajorInfo', N'M0614', N'兽医医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'620', N'MajorInfo', N'M0615', N'动物防疫与检疫', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'621', N'MajorInfo', N'M0616', N'兽药生产与营销', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'622', N'MajorInfo', N'M0617', N'水产养殖学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'623', N'MajorInfo', N'M0618', N'海洋渔业科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'624', N'MajorInfo', N'M0619', N'水族科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'625', N'MajorInfo', N'M0620', N'水产养殖技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'626', N'MajorInfo', N'M0621', N'水生动植物保护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'627', N'MajorInfo', N'M0622', N'海洋捕捞技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'628', N'MajorInfo', N'M0623', N'渔业综合技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'629', N'MajorInfo', N'M0624', N'管理科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'630', N'MajorInfo', N'M0625', N'信息管理与信息系统', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'631', N'MajorInfo', N'M0626', N'工业工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'632', N'MajorInfo', N'M0627', N'工程管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'633', N'MajorInfo', N'M0628', N'工程造价', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'634', N'MajorInfo', N'M0629', N'房地产经营管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'635', N'MajorInfo', N'M0630', N'产品质量工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'636', N'MajorInfo', N'M0631', N'项目管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'637', N'MajorInfo', N'M0632', N'标准计量与质量管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'638', N'MajorInfo', N'M0633', N'工程项目管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'639', N'MajorInfo', N'M0634', N'建筑工程管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'640', N'MajorInfo', N'M0635', N'建筑经济管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'641', N'MajorInfo', N'M0636', N'工程监理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'642', N'MajorInfo', N'M0637', N'工程造价管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'643', N'MajorInfo', N'M0638', N'公路工程管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'644', N'MajorInfo', N'M0639', N'建筑工程项目管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'645', N'MajorInfo', N'M0640', N'农业经济管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'646', N'MajorInfo', N'M0641', N'农村区域发展', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'647', N'MajorInfo', N'M0642', N'农村行政管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'648', N'MajorInfo', N'M0643', N'乡镇企业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'649', N'MajorInfo', N'M0644', N'林业经济信息管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'650', N'MajorInfo', N'M0645', N'渔业资源与渔政管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'651', N'MajorInfo', N'M0646', N'经济林', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'652', N'MajorInfo', N'M0647', N'经济林木', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'653', N'MajorInfo', N'M0648', N'农林经济管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'654', N'MajorInfo', N'M0649', N'农村经济管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'655', N'MajorInfo', N'M0650', N'航海技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'656', N'MajorInfo', N'M0651', N'水运管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'657', N'MajorInfo', N'M0652', N'国际航运业务管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'658', N'MajorInfo', N'M0653', N'海事管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'659', N'MajorInfo', N'M0654', N'轮机工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'660', N'MajorInfo', N'M0655', N'船舶工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'661', N'MajorInfo', N'M0656', N'船舶检验', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'662', N'MajorInfo', N'M0657', N'航道工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'663', N'MajorInfo', N'M0658', N'民航运输', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'664', N'MajorInfo', N'M0659', N'飞行技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'665', N'MajorInfo', N'M0660', N'空中乘务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'666', N'MajorInfo', N'M0661', N'航空服务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'667', N'MajorInfo', N'M0662', N'民航商务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'668', N'MajorInfo', N'M0663', N'航空机电设备维修', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'669', N'MajorInfo', N'M0664', N'航空电子设备维修', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'670', N'MajorInfo', N'M0665', N'民航特种车辆维修', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'671', N'MajorInfo', N'M0666', N'航空通信技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'672', N'MajorInfo', N'M0667', N'空中交通管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'673', N'MajorInfo', N'M0668', N'民航安全技术管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'674', N'MajorInfo', N'M0669', N'航空油料管理和应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'675', N'MajorInfo', N'M0670', N'飞机制造技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'676', N'MajorInfo', N'M0671', N'港口业务管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'677', N'MajorInfo', N'M0672', N'港口物流设备与自动控制', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'678', N'MajorInfo', N'M0673', N'集装箱运输管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'679', N'MajorInfo', N'M0674', N'港口工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'680', N'MajorInfo', N'M0675', N'报关与国际货运', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'681', N'MajorInfo', N'M0676', N'高速铁道技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'682', N'MajorInfo', N'M0677', N'电气化铁道技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'683', N'MajorInfo', N'M0678', N'铁道车辆', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'684', N'MajorInfo', N'M0679', N'铁道机车车辆', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'685', N'MajorInfo', N'M0680', N'铁道通信信号', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'686', N'MajorInfo', N'M0681', N'铁道交通运营管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'687', N'MajorInfo', N'M0682', N'铁道运输经济', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'688', N'MajorInfo', N'M0683', N'铁道工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'689', N'MajorInfo', N'M0684', N'公路运输与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'690', N'MajorInfo', N'M0685', N'高等级公路维护与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'691', N'MajorInfo', N'M0686', N'路政管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'692', N'MajorInfo', N'M0687', N'汽车运用技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'693', N'MajorInfo', N'M0688', N'交通安全与智能控制', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'694', N'MajorInfo', N'M0689', N'城市交通运输', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'695', N'MajorInfo', N'M0690', N'公路监理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'696', N'MajorInfo', N'M0691', N'道路桥梁工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'697', N'MajorInfo', N'M0692', N'工程机械控制技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'698', N'MajorInfo', N'M0693', N'工程机械运用与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'699', N'MajorInfo', N'M0694', N'城市轨道交通车辆', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'700', N'MajorInfo', N'M0695', N'城市轨道交通控制', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'701', N'MajorInfo', N'M0696', N'城市轨道交通工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'702', N'MajorInfo', N'M0697', N'城市轨道交通运营管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'703', N'MajorInfo', N'M0698', N'管道工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'704', N'MajorInfo', N'M0699', N'管道工程施工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'705', N'MajorInfo', N'M0700', N'管道运输管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'706', N'MajorInfo', N'M0701', N'交通运输', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'707', N'MajorInfo', N'M0702', N'交通工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'708', N'MajorInfo', N'M0703', N'油气储运工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'709', N'MajorInfo', N'M0704', N'飞行技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'710', N'MajorInfo', N'M0705', N'航海技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'711', N'MajorInfo', N'M0706', N'轮机工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'712', N'MajorInfo', N'M0707', N'物流工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'713', N'MajorInfo', N'M0708', N'海事管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'714', N'MajorInfo', N'M0709', N'交通设备信息工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'715', N'MajorInfo', N'M0710', N'发电厂及电力系统', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'716', N'MajorInfo', N'M0711', N'电厂设备运行与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'717', N'MajorInfo', N'M0712', N'电厂热能动力装置', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'718', N'MajorInfo', N'M0713', N'火电厂集控运行', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'719', N'MajorInfo', N'M0714', N'小型水电站及电力网', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'720', N'MajorInfo', N'M0715', N'供用电技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'721', N'MajorInfo', N'M0716', N'电网监控技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'722', N'MajorInfo', N'M0717', N'电力系统继电保护与自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'723', N'MajorInfo', N'M0718', N'高压输配电线路施工运行与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'724', N'MajorInfo', N'M0719', N'农村电气化技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'725', N'MajorInfo', N'M0720', N'电厂化学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'726', N'MajorInfo', N'M0721', N'建筑设计技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'727', N'MajorInfo', N'M0722', N'建筑装饰工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'728', N'MajorInfo', N'M0723', N'中国古建筑工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'729', N'MajorInfo', N'M0724', N'室内设计技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'730', N'MajorInfo', N'M0725', N'环境艺术设计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'731', N'MajorInfo', N'M0726', N'园林工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'732', N'MajorInfo', N'M0727', N'建筑工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'733', N'MajorInfo', N'M0728', N'地下工程与隧道工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'734', N'MajorInfo', N'M0729', N'基础工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'735', N'MajorInfo', N'M0730', N'建筑设备工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'736', N'MajorInfo', N'M0731', N'供热通风与空调工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'737', N'MajorInfo', N'M0732', N'建筑电气工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'738', N'MajorInfo', N'M0733', N'楼宇智能化工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'739', N'MajorInfo', N'M0734', N'楼宇电器', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'740', N'MajorInfo', N'M0735', N'城镇规划', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'741', N'MajorInfo', N'M0736', N'城市管理与监察', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'742', N'MajorInfo', N'M0737', N'村镇建设', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'743', N'MajorInfo', N'M0738', N'村镇建设规划', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'744', N'MajorInfo', N'M0739', N'城镇建设', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'745', N'MajorInfo', N'M0740', N'城市规划与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'746', N'MajorInfo', N'M0741', N'土地管理与城镇规划', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'747', N'MajorInfo', N'M0742', N'市政工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'748', N'MajorInfo', N'M0743', N'城市燃气工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'749', N'MajorInfo', N'M0744', N'给排水工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'750', N'MajorInfo', N'M0745', N'水工业技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'751', N'MajorInfo', N'M0746', N'消防工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'752', N'MajorInfo', N'M0747', N'房地产经营与估价', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'753', N'MajorInfo', N'M0748', N'物业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'754', N'MajorInfo', N'M0749', N'物业设施管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'755', N'MajorInfo', N'M0750', N'水文与水资源', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'756', N'MajorInfo', N'M0751', N'水文自动化测报技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'757', N'MajorInfo', N'M0752', N'水信息技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'758', N'MajorInfo', N'M0753', N'水政水资源管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'759', N'MajorInfo', N'M0754', N'机电设备维修与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'760', N'MajorInfo', N'M0755', N'数控设备应用与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'761', N'MajorInfo', N'M0756', N'自动化生产设备应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'762', N'MajorInfo', N'M0757', N'医用电子仪器与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'763', N'MajorInfo', N'M0758', N'医学影像设备管理与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'764', N'MajorInfo', N'M0759', N'机电一体化技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'765', N'MajorInfo', N'M0760', N'电气自动化技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'766', N'MajorInfo', N'M0761', N'生产过程自动化技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'767', N'MajorInfo', N'M0762', N'电力系统自动化技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'768', N'MajorInfo', N'M0763', N'计算机控制技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'769', N'MajorInfo', N'M0764', N'工业网络技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'770', N'MajorInfo', N'M0765', N'检测技术及应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'771', N'MajorInfo', N'M0766', N'理化测试及质检技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'772', N'MajorInfo', N'M0767', N'液压与气动技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'773', N'MajorInfo', N'M0768', N'机电技术应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'774', N'MajorInfo', N'M0769', N'汽车制造与装配技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'775', N'MajorInfo', N'M0770', N'汽车检测与维修技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'776', N'MajorInfo', N'M0771', N'汽车电子技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'777', N'MajorInfo', N'M0772', N'汽车改装技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'778', N'MajorInfo', N'M0773', N'汽车技术服务与营销', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'779', N'MajorInfo', N'M0774', N'汽车整形技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'780', N'MajorInfo', N'M0775', N'汽车运用与维修', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'781', N'MajorInfo', N'M0776', N'计算机应用技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'782', N'MajorInfo', N'M0777', N'计算机网络技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'783', N'MajorInfo', N'M0778', N'计算机多媒体技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'784', N'MajorInfo', N'M0779', N'计算机系统维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'785', N'MajorInfo', N'M0780', N'计算机硬件与外设', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'786', N'MajorInfo', N'M0781', N'计算机信息管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'787', N'MajorInfo', N'M0782', N'网络系统管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'788', N'MajorInfo', N'M0783', N'软件技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'789', N'MajorInfo', N'M0784', N'图形图像制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'790', N'MajorInfo', N'M0785', N'动漫设计与制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'791', N'MajorInfo', N'M0786', N'电子信息工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'792', N'MajorInfo', N'M0787', N'应用电子技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'793', N'MajorInfo', N'M0788', N'电子测量技术与仪器', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'794', N'MajorInfo', N'M0789', N'电子仪器仪表与维修', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'795', N'MajorInfo', N'M0790', N'电子设备与运行管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'796', N'MajorInfo', N'M0791', N'电子声像技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'797', N'MajorInfo', N'M0792', N'电子工艺与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'798', N'MajorInfo', N'M0793', N'信息安全技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'799', N'MajorInfo', N'M0794', N'图文信息技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'800', N'MajorInfo', N'M0795', N'微电子技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'801', N'MajorInfo', N'M0796', N'无线电技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'802', N'MajorInfo', N'M0797', N'广播电视网络技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'803', N'MajorInfo', N'M0798', N'有线电视工程技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'804', N'MajorInfo', N'M0799', N'通信技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'805', N'MajorInfo', N'M0800', N'移动通信技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'806', N'MajorInfo', N'M0801', N'计算机通信', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'807', N'MajorInfo', N'M0802', N'程控交换技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'808', N'MajorInfo', N'M0803', N'通信网络与设备', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'809', N'MajorInfo', N'M0804', N'通信系统运行管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'810', N'MajorInfo', N'M0805', N'电子信息科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'811', N'MajorInfo', N'M0806', N'微电子学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'812', N'MajorInfo', N'M0807', N'光信息科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'813', N'MajorInfo', N'M0808', N'科技防卫', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'814', N'MajorInfo', N'M0809', N'信息安全', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'815', N'MajorInfo', N'M0810', N'信息科学技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'816', N'MajorInfo', N'M0811', N'光电子技术科学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'817', N'MajorInfo', N'M0812', N'电气工程及其自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'818', N'MajorInfo', N'M0813', N'自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'819', N'MajorInfo', N'M0814', N'电子信息工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'820', N'MajorInfo', N'M0815', N'通信工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'821', N'MajorInfo', N'M0816', N'计算机科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'822', N'MajorInfo', N'M0817', N'电子科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'823', N'MajorInfo', N'M0818', N'生物医学工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'824', N'MajorInfo', N'M0819', N'电气工程与自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'825', N'MajorInfo', N'M0820', N'信息工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'826', N'MajorInfo', N'M0821', N'光源与照明', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'827', N'MajorInfo', N'M0822', N'软件工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'828', N'MajorInfo', N'M0823', N'影视艺术技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'829', N'MajorInfo', N'M0824', N'网络工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'830', N'MajorInfo', N'M0825', N'信息显示与光电技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'831', N'MajorInfo', N'M0826', N'集成电路设计与集成系统', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'832', N'MajorInfo', N'M0827', N'光电信息工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'833', N'MajorInfo', N'M0828', N'广播电视工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'834', N'MajorInfo', N'M0829', N'电气信息工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'835', N'MajorInfo', N'M0830', N'计算机软件', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'836', N'MajorInfo', N'M0831', N'电力工程与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'837', N'MajorInfo', N'M0832', N'微电子制造工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'838', N'MajorInfo', N'M0833', N'假肢矫形工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'839', N'MajorInfo', N'M0834', N'数字媒体艺术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'840', N'MajorInfo', N'M0835', N'医学信息工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'841', N'MajorInfo', N'M0836', N'信息物理工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'842', N'MajorInfo', N'M0837', N'医疗器械工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'843', N'MajorInfo', N'M0838', N'智能科学与技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'844', N'MajorInfo', N'M0839', N'数字媒体技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'845', N'MajorInfo', N'M0840', N'计算机应用与维护', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'846', N'MajorInfo', N'M0841', N'计算机及应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'847', N'MajorInfo', N'M0842', N'办公自动化设备运行与维修', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'848', N'MajorInfo', N'M0843', N'计算机应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'849', N'MajorInfo', N'M0844', N'微型计算机及应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'850', N'MajorInfo', N'M0845', N'光电技术应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'851', N'MajorInfo', N'M0846', N'国土资源信息工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'852', N'MajorInfo', N'M0847', N'办公自动化与文秘', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'853', N'MajorInfo', N'M0848', N'文秘与办公自动化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'854', N'MajorInfo', N'M0849', N'计算机科学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'855', N'MajorInfo', N'M0850', N'经济信息管理及计算机应用', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'856', N'MajorInfo', N'M0851', N'财政', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'857', N'MajorInfo', N'M0852', N'税务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'858', N'MajorInfo', N'M0853', N'金融管理与实务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'859', N'MajorInfo', N'M0854', N'国际金融', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'860', N'MajorInfo', N'M0855', N'金融与证券', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'861', N'MajorInfo', N'M0856', N'金融保险', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'862', N'MajorInfo', N'M0857', N'保险实务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'863', N'MajorInfo', N'M0858', N'医疗保险实务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'864', N'MajorInfo', N'M0859', N'资产评估与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'865', N'MajorInfo', N'M0860', N'证券投资与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'866', N'MajorInfo', N'M0861', N'证券投资', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'867', N'MajorInfo', N'M0862', N'投资与理财', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'868', N'MajorInfo', N'M0863', N'证券与期货', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'869', N'MajorInfo', N'M0864', N'财税', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'870', N'MajorInfo', N'M0865', N'金融', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'871', N'MajorInfo', N'M0866', N'经济学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'872', N'MajorInfo', N'M0867', N'国际经济与贸易', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'873', N'MajorInfo', N'M0868', N'财政学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'874', N'MajorInfo', N'M0869', N'金融学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'875', N'MajorInfo', N'M0870', N'国民经济管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'876', N'MajorInfo', N'M0871', N'贸易经济', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'877', N'MajorInfo', N'M0872', N'保险', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'878', N'MajorInfo', N'M0873', N'金融工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'879', N'MajorInfo', N'M0874', N'税务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'880', N'MajorInfo', N'M0875', N'信用管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'881', N'MajorInfo', N'M0876', N'网络经济学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'882', N'MajorInfo', N'M0877', N'体育经济', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'883', N'MajorInfo', N'M0878', N'投资学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'884', N'MajorInfo', N'M0879', N'环境资源与发展经济学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'885', N'MajorInfo', N'M0880', N'海洋经济学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'886', N'MajorInfo', N'M0881', N'经济管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'887', N'MajorInfo', N'M0882', N'经济信息管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'888', N'MajorInfo', N'M0883', N'国际经济与贸易', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'889', N'MajorInfo', N'M0884', N'国际贸易实务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'890', N'MajorInfo', N'M0885', N'国际商务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'891', N'MajorInfo', N'M0886', N'商务经纪与代理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'892', N'MajorInfo', N'M0887', N'区域经济开发与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'893', N'MajorInfo', N'M0888', N'投资经济与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'894', N'MajorInfo', N'M0889', N'涉外经济与法律', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'895', N'MajorInfo', N'M0890', N'房地产经济管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'896', N'MajorInfo', N'M0891', N'国际贸易', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'897', N'MajorInfo', N'M0892', N'国际贸易与进出口代理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'898', N'MajorInfo', N'M0893', N'行政与经济管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'899', N'MajorInfo', N'M0894', N'国有资产管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'900', N'MajorInfo', N'M0895', N'社会保障', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'901', N'MajorInfo', N'M0896', N'财务管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'902', N'MajorInfo', N'M0897', N'财务信息管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'903', N'MajorInfo', N'M0898', N'会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'904', N'MajorInfo', N'M0899', N'会计学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'905', N'MajorInfo', N'M0900', N'会计电算化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'906', N'MajorInfo', N'M0901', N'会计与统计核算', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'907', N'MajorInfo', N'M0902', N'会计与审计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'908', N'MajorInfo', N'M0903', N'审计实务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'909', N'MajorInfo', N'M0904', N'统计实务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'910', N'MajorInfo', N'M0905', N'财务会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'911', N'MajorInfo', N'M0906', N'农业财务会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'912', N'MajorInfo', N'M0907', N'财务与审计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'913', N'MajorInfo', N'M0908', N'财会电算化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'914', N'MajorInfo', N'M0909', N'农业会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'915', N'MajorInfo', N'M0910', N'统计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'916', N'MajorInfo', N'M0911', N'涉外会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'917', N'MajorInfo', N'M0912', N'注册会计师', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'918', N'MajorInfo', N'M0913', N'电算会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'919', N'MajorInfo', N'M0914', N'商业财务会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'920', N'MajorInfo', N'M0915', N'电算化会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'921', N'MajorInfo', N'M0916', N'会计统计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'922', N'MajorInfo', N'M0917', N'建筑财务会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'923', N'MajorInfo', N'M0918', N'工商企业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'924', N'MajorInfo', N'M0919', N'工商行政管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'925', N'MajorInfo', N'M0920', N'商务管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'926', N'MajorInfo', N'M0921', N'连锁经营管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'927', N'MajorInfo', N'M0922', N'物流管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'928', N'MajorInfo', N'M0923', N'市场营销', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'929', N'MajorInfo', N'M0924', N'市场开发与营销', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'930', N'MajorInfo', N'M0925', N'营销与策划', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'931', N'MajorInfo', N'M0926', N'医药营销', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'932', N'MajorInfo', N'M0927', N'电子商务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'933', N'MajorInfo', N'M0928', N'工商管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'934', N'MajorInfo', N'M0929', N'会计学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'935', N'MajorInfo', N'M0930', N'财务管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'936', N'MajorInfo', N'M0931', N'人力资源管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'937', N'MajorInfo', N'M0932', N'旅游管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'938', N'MajorInfo', N'M0933', N'商品学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'939', N'MajorInfo', N'M0934', N'审计学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'940', N'MajorInfo', N'M0935', N'国际商务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'941', N'MajorInfo', N'M0936', N'物业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'942', N'MajorInfo', N'M0937', N'特许经营管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'943', N'MajorInfo', N'M0938', N'市场策划', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'944', N'MajorInfo', N'M0939', N'物资经营管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'945', N'MajorInfo', N'M0940', N'企业管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'946', N'MajorInfo', N'M0941', N'广播电视技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'947', N'MajorInfo', N'M0942', N'摄影摄像技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'948', N'MajorInfo', N'M0943', N'音像技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'949', N'MajorInfo', N'M0944', N'影视多媒体技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'950', N'MajorInfo', N'M0945', N'影视动画', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'951', N'MajorInfo', N'M0946', N'影视广告', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'952', N'MajorInfo', N'M0947', N'主持与播音', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'953', N'MajorInfo', N'M0948', N'新闻采编与制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'954', N'MajorInfo', N'M0949', N'电视节目制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'955', N'MajorInfo', N'M0950', N'电视制片管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'956', N'MajorInfo', N'M0951', N'影视节目制作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'957', N'MajorInfo', N'M0952', N'治安学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'958', N'MajorInfo', N'M0953', N'侦察学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'959', N'MajorInfo', N'M0954', N'边防管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'960', N'MajorInfo', N'M0955', N'火灾勘测', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'961', N'MajorInfo', N'M0956', N'禁毒学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'962', N'MajorInfo', N'M0957', N'警犬技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'963', N'MajorInfo', N'M0958', N'经济犯罪侦察', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'964', N'MajorInfo', N'M0959', N'边防指挥', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'965', N'MajorInfo', N'M0960', N'消防指挥', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'966', N'MajorInfo', N'M0961', N'警卫学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'967', N'MajorInfo', N'M0962', N'刑事技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'968', N'MajorInfo', N'M0963', N'警犬技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'969', N'MajorInfo', N'M0964', N'船艇动力管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'970', N'MajorInfo', N'M0965', N'船艇技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'971', N'MajorInfo', N'M0966', N'边防机要', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'972', N'MajorInfo', N'M0967', N'警察指挥与战术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'973', N'MajorInfo', N'M0968', N'边防指挥', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'974', N'MajorInfo', N'M0969', N'边防船艇指挥', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'975', N'MajorInfo', N'M0970', N'边防通信指挥', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'976', N'MajorInfo', N'M0971', N'消防指挥', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'977', N'MajorInfo', N'M0972', N'参谋业务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'978', N'MajorInfo', N'M0973', N'侦查', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'979', N'MajorInfo', N'M0974', N'经济犯罪侦查', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'980', N'MajorInfo', N'M0975', N'安全保卫', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'981', N'MajorInfo', N'M0976', N'警卫', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'982', N'MajorInfo', N'M0977', N'治安管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'983', N'MajorInfo', N'M0978', N'交通管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'984', N'MajorInfo', N'M0979', N'警察管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'985', N'MajorInfo', N'M0980', N'公共安全管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'986', N'MajorInfo', N'M0981', N'信息网络安全监察', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'987', N'MajorInfo', N'M0982', N'防火管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'988', N'MajorInfo', N'M0983', N'森林消防', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'989', N'MajorInfo', N'M0984', N'边防检查', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'990', N'MajorInfo', N'M0985', N'边境管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'991', N'MajorInfo', N'M0986', N'禁毒', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'992', N'MajorInfo', N'M0987', N'抢险救援', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'993', N'MajorInfo', N'M0988', N'刑事侦查技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'994', N'MajorInfo', N'M0989', N'司法鉴定技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'995', N'MajorInfo', N'M0990', N'安全防范技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'996', N'MajorInfo', N'M0991', N'司法信息技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'997', N'MajorInfo', N'M0992', N'司法信息安全', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'998', N'MajorInfo', N'M0993', N'刑事科学技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'999', N'MajorInfo', N'M0994', N'消防工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1000', N'MajorInfo', N'M0995', N'安全防范工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1001', N'MajorInfo', N'M0996', N'交通管理工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1002', N'MajorInfo', N'M0997', N'核生化消防', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1003', N'MajorInfo', N'M0998', N'侦查学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1004', N'MajorInfo', N'M0999', N'林业公安', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1005', N'MajorInfo', N'M1000', N'教育技术学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1006', N'MajorInfo', N'M1001', N'农艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1007', N'MajorInfo', N'M1002', N'园艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1008', N'MajorInfo', N'M1003', N'特用作物教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1009', N'MajorInfo', N'M1004', N'林木生产教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1010', N'MajorInfo', N'M1005', N'特用动物教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1011', N'MajorInfo', N'M1006', N'畜禽生产教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1012', N'MajorInfo', N'M1007', N'水产养殖教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1013', N'MajorInfo', N'M1008', N'应用生物教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1014', N'MajorInfo', N'M1009', N'农业机械教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1015', N'MajorInfo', N'M1010', N'农业建筑与环境控制教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1016', N'MajorInfo', N'M1011', N'农产品储运与加工教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1017', N'MajorInfo', N'M1012', N'农业经营管理教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1018', N'MajorInfo', N'M1013', N'机械制造工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1019', N'MajorInfo', N'M1014', N'机械维修及检测技术教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1020', N'MajorInfo', N'M1015', N'机电技术教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1021', N'MajorInfo', N'M1016', N'电气技术教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1022', N'MajorInfo', N'M1017', N'汽车维修工程教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1023', N'MajorInfo', N'M1018', N'应用电子技术教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1024', N'MajorInfo', N'M1019', N'制浆造纸工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1025', N'MajorInfo', N'M1020', N'印刷工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1026', N'MajorInfo', N'M1021', N'橡塑制品成型工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1027', N'MajorInfo', N'M1022', N'食品工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1028', N'MajorInfo', N'M1023', N'纺织工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1029', N'MajorInfo', N'M1024', N'染整工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1030', N'MajorInfo', N'M1025', N'化工工艺教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1031', N'MajorInfo', N'M1026', N'化工分析与检测技术教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1032', N'MajorInfo', N'M1027', N'建筑材料工程教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1033', N'MajorInfo', N'M1028', N'建筑工程教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1034', N'MajorInfo', N'M1029', N'财务会计教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1035', N'MajorInfo', N'M1030', N'物理教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1036', N'MajorInfo', N'M1031', N'化学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1037', N'MajorInfo', N'M1032', N'生物教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1038', N'MajorInfo', N'M1033', N'现代教育技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1039', N'MajorInfo', N'M1034', N'食品营养与检验教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1040', N'MajorInfo', N'M1035', N'市场营销教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1041', N'MajorInfo', N'M1036', N'职业技术教育管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1042', N'MajorInfo', N'M1037', N'计算机科学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1043', N'MajorInfo', N'M1038', N'数学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1044', N'MajorInfo', N'M1039', N'综合理科教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1045', N'MajorInfo', N'M1040', N'科学教育', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1046', N'MajorInfo', N'M1041', N'部队政治工作', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1047', N'MajorInfo', N'M1042', N'部队财务会计', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1048', N'MajorInfo', N'M1043', N'部队后勤管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1049', N'MajorInfo', N'M1044', N'预防医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1050', N'MajorInfo', N'M1045', N'卫生检验', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1051', N'MajorInfo', N'M1046', N'妇幼保健医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1052', N'MajorInfo', N'M1047', N'营养学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1053', N'MajorInfo', N'M1048', N'基础医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1054', N'MajorInfo', N'M1049', N'临床医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1055', N'MajorInfo', N'M1050', N'眼视光学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1056', N'MajorInfo', N'M1051', N'康复治疗学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1057', N'MajorInfo', N'M1052', N'精神医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1058', N'MajorInfo', N'M1053', N'全科医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1059', N'MajorInfo', N'M1054', N'口腔医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1060', N'MajorInfo', N'M1055', N'社区医疗', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1061', N'MajorInfo', N'M1056', N'社区医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1062', N'MajorInfo', N'M1057', N'法医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1063', N'MajorInfo', N'M1058', N'妇幼保健', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1064', N'MajorInfo', N'M1059', N'妇幼保健医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1065', N'MajorInfo', N'M1060', N'妇幼医士', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1066', N'MajorInfo', N'M1061', N'妇幼卫生', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1067', N'MajorInfo', N'M1062', N'卫生保健', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1068', N'MajorInfo', N'M1063', N'医士', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1069', N'MajorInfo', N'M1064', N'初级卫生保健', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1070', N'MajorInfo', N'M1065', N'民族医士', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1071', N'MajorInfo', N'M1066', N'计划生育医士', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1072', N'MajorInfo', N'M1067', N'麻醉学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1073', N'MajorInfo', N'M1068', N'医学影像学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1074', N'MajorInfo', N'M1069', N'医学检验', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1075', N'MajorInfo', N'M1070', N'放射医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1076', N'MajorInfo', N'M1071', N'医学技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1077', N'MajorInfo', N'M1072', N'听力学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1078', N'MajorInfo', N'M1073', N'医学实验学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1079', N'MajorInfo', N'M1074', N'口腔修复工艺学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1080', N'MajorInfo', N'M1075', N'医学检验技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1081', N'MajorInfo', N'M1076', N'医学生物技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1082', N'MajorInfo', N'M1077', N'医学影像技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1083', N'MajorInfo', N'M1078', N'眼视光技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1084', N'MajorInfo', N'M1079', N'康复治疗技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1085', N'MajorInfo', N'M1080', N'口腔医学技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1086', N'MajorInfo', N'M1081', N'医学营养', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1087', N'MajorInfo', N'M1082', N'医疗美容技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1088', N'MajorInfo', N'M1083', N'呼吸治疗技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1089', N'MajorInfo', N'M1084', N'卫生检验与检疫技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1090', N'MajorInfo', N'M1085', N'美容医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1091', N'MajorInfo', N'M1086', N'中医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1092', N'MajorInfo', N'M1087', N'针灸推拿学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1093', N'MajorInfo', N'M1088', N'蒙医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1094', N'MajorInfo', N'M1089', N'藏医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1095', N'MajorInfo', N'M1090', N'中西医临床医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1096', N'MajorInfo', N'M1091', N'针灸推拿', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1097', N'MajorInfo', N'M1092', N'中医骨伤', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1098', N'MajorInfo', N'M1093', N'中医医疗', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1099', N'MajorInfo', N'M1094', N'中西医结合', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1100', N'MajorInfo', N'M1095', N'中医士', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1101', N'MajorInfo', N'M1096', N'中医', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1102', N'MajorInfo', N'M1097', N'护理学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1103', N'MajorInfo', N'M1098', N'护理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1104', N'MajorInfo', N'M1099', N'助产', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1105', N'MajorInfo', N'M1100', N'高级护理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1106', N'MajorInfo', N'M1101', N'助产士', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1107', N'MajorInfo', N'M1102', N'护士', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1108', N'MajorInfo', N'M1103', N'中医护士', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1109', N'MajorInfo', N'M1104', N'药学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1110', N'MajorInfo', N'M1105', N'中药学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1111', N'MajorInfo', N'M1106', N'中药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1112', N'MajorInfo', N'M1107', N'药物制剂', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1113', N'MajorInfo', N'M1108', N'中草药栽培与鉴定', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1114', N'MajorInfo', N'M1109', N'藏药学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1115', N'MajorInfo', N'M1110', N'中药资源与开发', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1116', N'MajorInfo', N'M1111', N'应用药学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1117', N'MajorInfo', N'M1112', N'海洋药学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1118', N'MajorInfo', N'M1113', N'药事管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1119', N'MajorInfo', N'M1114', N'药剂', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1120', N'MajorInfo', N'M1115', N'生化制药技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1121', N'MajorInfo', N'M1116', N'生物制药技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1122', N'MajorInfo', N'M1117', N'化学制药技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1123', N'MajorInfo', N'M1118', N'中药制药技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1124', N'MajorInfo', N'M1119', N'药物制剂技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1125', N'MajorInfo', N'M1120', N'药物分析技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1126', N'MajorInfo', N'M1121', N'制药工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1127', N'MajorInfo', N'M1122', N'化工与制药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1128', N'MajorInfo', N'M1123', N'食品药品监督管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1129', N'MajorInfo', N'M1124', N'药品质量检测技术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1130', N'MajorInfo', N'M1125', N'药品经营与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1131', N'MajorInfo', N'M1126', N'保健品开发与管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1132', N'MajorInfo', N'M1127', N'卫生监督', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1133', N'MajorInfo', N'M1128', N'卫生信息管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1134', N'MajorInfo', N'M1129', N'公共卫生管理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1135', N'MajorInfo', N'M1130', N'医学文秘', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1136', N'UniversityInfo', N'University', N'University', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1137', N'UniversityInfo', N'U1132', N'清华大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1138', N'UniversityInfo', N'U1133', N'北京大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1139', N'UniversityInfo', N'U1134', N'中国人民大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1140', N'UniversityInfo', N'U1135', N'北京航空航天大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1141', N'UniversityInfo', N'U1136', N'北京邮电大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1142', N'UniversityInfo', N'U1137', N'北京师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1143', N'UniversityInfo', N'U1138', N'中国传媒大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1144', N'UniversityInfo', N'U1139', N'北京语言大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1145', N'UniversityInfo', N'U1140', N'北京科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1146', N'UniversityInfo', N'U1141', N'中国农业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1147', N'UniversityInfo', N'U1142', N'北京理工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1148', N'UniversityInfo', N'U1143', N'北京林业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1149', N'UniversityInfo', N'U1144', N'北京交通大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1150', N'UniversityInfo', N'U1145', N'中国矿业大学（北京）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1151', N'UniversityInfo', N'U1146', N'北京信息科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1152', N'UniversityInfo', N'U1147', N'北京工业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1153', N'UniversityInfo', N'U1148', N'北京化工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1154', N'UniversityInfo', N'U1149', N'中国政法大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1155', N'UniversityInfo', N'U1150', N'对外经贸大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1156', N'UniversityInfo', N'U1151', N'中央民族大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1157', N'UniversityInfo', N'U1152', N'中国地质大学（北京）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1158', N'UniversityInfo', N'U1153', N'中科院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1159', N'UniversityInfo', N'U1154', N'北京中医药大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1160', N'UniversityInfo', N'U1155', N'首都经济贸易大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1161', N'UniversityInfo', N'U1156', N'中央财经大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1162', N'UniversityInfo', N'U1157', N'北方工业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1163', N'UniversityInfo', N'U1158', N'中国石油大学（北京）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1164', N'UniversityInfo', N'U1159', N'外交学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1165', N'UniversityInfo', N'U1160', N'首都师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1166', N'UniversityInfo', N'U1161', N'中央戏剧学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1167', N'UniversityInfo', N'U1162', N'中国青年政治学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1168', N'UniversityInfo', N'U1163', N'北京外国语大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1169', N'UniversityInfo', N'U1164', N'华北电力大学（北京）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1170', N'UniversityInfo', N'U1165', N'中国人民公安大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1171', N'UniversityInfo', N'U1166', N'中国协和医科大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1172', N'UniversityInfo', N'U1167', N'北京体育大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1173', N'UniversityInfo', N'U1168', N'北京工商大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1174', N'UniversityInfo', N'U1169', N'北京联合大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1175', N'UniversityInfo', N'U1170', N'首都医科大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1176', N'UniversityInfo', N'U1171', N'国际关系学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1177', N'UniversityInfo', N'U1172', N'中央美术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1178', N'UniversityInfo', N'U1173', N'北京电子科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1179', N'UniversityInfo', N'U1174', N'中国劳动关系学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1180', N'UniversityInfo', N'U1175', N'中华女子学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1181', N'UniversityInfo', N'U1176', N'北京建筑工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1182', N'UniversityInfo', N'U1177', N'北京印刷学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1183', N'UniversityInfo', N'U1178', N'北京石油化工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1184', N'UniversityInfo', N'U1179', N'首钢工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1185', N'UniversityInfo', N'U1180', N'北京农学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1186', N'UniversityInfo', N'U1181', N'首都体育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1187', N'UniversityInfo', N'U1182', N'北京第二外国语学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1188', N'UniversityInfo', N'U1183', N'北京物资学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1189', N'UniversityInfo', N'U1184', N'北京警察学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1190', N'UniversityInfo', N'U1185', N'中央音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1191', N'UniversityInfo', N'U1186', N'中国戏曲学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1192', N'UniversityInfo', N'U1187', N'北京舞蹈学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1193', N'UniversityInfo', N'U1188', N'北京城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1194', N'UniversityInfo', N'U1189', N'北京电影学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1195', N'UniversityInfo', N'U1190', N'北京服装学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1196', N'UniversityInfo', N'U1191', N'北京工商大学嘉华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1197', N'UniversityInfo', N'U1192', N'首都师范大学科德学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1198', N'UniversityInfo', N'U1193', N'北京工业大学耿丹学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1199', N'UniversityInfo', N'U1194', N'北京化工大学北方学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1200', N'UniversityInfo', N'U1195', N'北京联合大学广告学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1201', N'UniversityInfo', N'U1196', N'北京邮电大学世纪学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1202', N'UniversityInfo', N'U1197', N'北京大学医学部', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1203', N'UniversityInfo', N'U1198', N'北京政法职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1204', N'UniversityInfo', N'U1199', N'北京信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1205', N'UniversityInfo', N'U1200', N'北京现代职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1206', N'UniversityInfo', N'U1201', N'北京现代音乐研修学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1207', N'UniversityInfo', N'U1202', N'北京戏曲艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1208', N'UniversityInfo', N'U1203', N'北京锡华国际经贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1209', N'UniversityInfo', N'U1204', N'北京盛基艺术学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1210', N'UniversityInfo', N'U1205', N'北京培黎职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1211', N'UniversityInfo', N'U1206', N'北京农业职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1212', N'UniversityInfo', N'U1207', N'北京科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1213', N'UniversityInfo', N'U1208', N'北京科技经营管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1214', N'UniversityInfo', N'U1209', N'北京经贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1215', N'UniversityInfo', N'U1210', N'北京经济技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1216', N'UniversityInfo', N'U1211', N'北京京北职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1217', N'UniversityInfo', N'U1212', N'北京交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1218', N'UniversityInfo', N'U1213', N'北京吉利大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1219', N'UniversityInfo', N'U1214', N'北京汇佳职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1220', N'UniversityInfo', N'U1215', N'北京工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1221', N'UniversityInfo', N'U1216', N'北京工商管理专修学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1222', N'UniversityInfo', N'U1217', N'北京电子科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1223', N'UniversityInfo', N'U1218', N'北京财贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1224', N'UniversityInfo', N'U1219', N'北京北大方正软件技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1225', N'UniversityInfo', N'U1220', N'北大资源美术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1226', N'UniversityInfo', N'U1221', N'北京人文大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1227', N'UniversityInfo', N'U1222', N'北京高等秘书学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1228', N'UniversityInfo', N'U1223', N'北京应用技术大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1229', N'UniversityInfo', N'U1224', N'中国防卫科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1230', N'UniversityInfo', N'U1225', N'中国音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1231', N'UniversityInfo', N'U1226', N'中国信息大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1232', N'UniversityInfo', N'U1227', N'北京青年政治学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1233', N'UniversityInfo', N'U1228', N'北京财经专修学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1234', N'UniversityInfo', N'U1229', N'北京经济管理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1235', N'UniversityInfo', N'U1230', N'北京美国英语语言学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1236', N'UniversityInfo', N'U1231', N'中国管理软件学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1237', N'UniversityInfo', N'U1232', N'财政部财政科学研究所', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1238', N'UniversityInfo', N'U1233', N'北大资源学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1239', N'UniversityInfo', N'U1234', N'北京现代管理大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1240', N'UniversityInfo', N'U1235', N'网络销售大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1241', N'UniversityInfo', N'U1236', N'朝阳二外', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1242', N'UniversityInfo', N'U1237', N'复旦大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1243', N'UniversityInfo', N'U1238', N'上海交通大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1244', N'UniversityInfo', N'U1239', N'同济大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1245', N'UniversityInfo', N'U1240', N'华东师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1246', N'UniversityInfo', N'U1241', N'上海财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1247', N'UniversityInfo', N'U1242', N'华东理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1248', N'UniversityInfo', N'U1243', N'上海商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1249', N'UniversityInfo', N'U1244', N'东华大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1250', N'UniversityInfo', N'U1245', N'上海理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1251', N'UniversityInfo', N'U1246', N'上海大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1252', N'UniversityInfo', N'U1247', N'上外', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1253', N'UniversityInfo', N'U1248', N'上海海事', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1254', N'UniversityInfo', N'U1249', N'上海工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1255', N'UniversityInfo', N'U1250', N'上海水产', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1256', N'UniversityInfo', N'U1251', N'上海中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1257', N'UniversityInfo', N'U1252', N'上海师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1258', N'UniversityInfo', N'U1253', N'建桥学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1259', N'UniversityInfo', N'U1254', N'上海政法', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1260', N'UniversityInfo', N'U1255', N'上海电机', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1261', N'UniversityInfo', N'U1256', N'上海二工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1262', N'UniversityInfo', N'U1257', N'上海应用技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1263', N'UniversityInfo', N'U1258', N'上海电力', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1264', N'UniversityInfo', N'U1259', N'上海外贸', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1265', N'UniversityInfo', N'U1260', N'上海金融', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1266', N'UniversityInfo', N'U1261', N'上海立信会计学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1267', N'UniversityInfo', N'U1262', N'上海体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1268', N'UniversityInfo', N'U1263', N'上海音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1269', N'UniversityInfo', N'U1264', N'上戏', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1270', N'UniversityInfo', N'U1265', N'杉达学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1271', N'UniversityInfo', N'U1266', N'华东政法大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1272', N'UniversityInfo', N'U1267', N'上外贤达经济人文学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1273', N'UniversityInfo', N'U1268', N'同济大学同科学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1274', N'UniversityInfo', N'U1269', N'上海师范大学天华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1275', N'UniversityInfo', N'U1270', N'上海东方文化职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1276', N'UniversityInfo', N'U1271', N'上海工商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1277', N'UniversityInfo', N'U1272', N'复旦大学上海视觉艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1278', N'UniversityInfo', N'U1273', N'复旦大学上海医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1279', N'UniversityInfo', N'U1274', N'复旦大学太平洋金融学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1280', N'UniversityInfo', N'U1275', N'上海邦德职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1281', N'UniversityInfo', N'U1276', N'上海诚信学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1282', N'UniversityInfo', N'U1277', N'上海城市管理职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1283', N'UniversityInfo', N'U1278', N'上海出版印刷高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1284', N'UniversityInfo', N'U1279', N'上海电影艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1285', N'UniversityInfo', N'U1280', N'上海电子信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1286', N'UniversityInfo', N'U1281', N'上海东海职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1287', N'UniversityInfo', N'U1282', N'上海工会管理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1288', N'UniversityInfo', N'U1283', N'上海工商外国语学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1289', N'UniversityInfo', N'U1284', N'上海工艺美术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1290', N'UniversityInfo', N'U1285', N'上海公安高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1291', N'UniversityInfo', N'U1286', N'上海海关学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1292', N'UniversityInfo', N'U1287', N'上海海事职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1293', N'UniversityInfo', N'U1288', N'上海济光职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1294', N'UniversityInfo', N'U1289', N'上海建峰职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1295', N'UniversityInfo', N'U1290', N'上海交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1296', N'UniversityInfo', N'U1291', N'上海科学技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1297', N'UniversityInfo', N'U1292', N'上海立达职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1298', N'UniversityInfo', N'U1293', N'上海旅游高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1299', N'UniversityInfo', N'U1294', N'上海民远职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1300', N'UniversityInfo', N'U1295', N'上海农林职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1301', N'UniversityInfo', N'U1296', N'上海欧华职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1302', N'UniversityInfo', N'U1297', N'上海思博职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1303', N'UniversityInfo', N'U1298', N'上海托普信息技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1304', N'UniversityInfo', N'U1299', N'上海新侨职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1305', N'UniversityInfo', N'U1300', N'上海行健职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1306', N'UniversityInfo', N'U1301', N'上海医疗器械高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1307', N'UniversityInfo', N'U1302', N'上海医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1308', N'UniversityInfo', N'U1303', N'上海震旦职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1309', N'UniversityInfo', N'U1304', N'上海中华职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1310', N'UniversityInfo', N'U1305', N'上海中侨职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1311', N'UniversityInfo', N'U1306', N'上海纺织工业职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1312', N'UniversityInfo', N'U1307', N'南开大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1313', N'UniversityInfo', N'U1308', N'天津大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1314', N'UniversityInfo', N'U1309', N'河北工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1315', N'UniversityInfo', N'U1310', N'天津师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1316', N'UniversityInfo', N'U1311', N'天津工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1317', N'UniversityInfo', N'U1312', N'天津科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1318', N'UniversityInfo', N'U1313', N'天津理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1319', N'UniversityInfo', N'U1314', N'天津医大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1320', N'UniversityInfo', N'U1315', N'天津中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1321', N'UniversityInfo', N'U1316', N'天津财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1322', N'UniversityInfo', N'U1317', N'中国民航大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1323', N'UniversityInfo', N'U1318', N'天津城市建设学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1324', N'UniversityInfo', N'U1319', N'天津农院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1325', N'UniversityInfo', N'U1320', N'天津工程师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1326', N'UniversityInfo', N'U1321', N'天外', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1327', N'UniversityInfo', N'U1322', N'天津商业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1328', N'UniversityInfo', N'U1323', N'天津体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1329', N'UniversityInfo', N'U1324', N'天津音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1330', N'UniversityInfo', N'U1325', N'天津美院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1331', N'UniversityInfo', N'U1326', N'民办天狮职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1332', N'UniversityInfo', N'U1327', N'天津滨海职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1333', N'UniversityInfo', N'U1328', N'天津渤海职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1334', N'UniversityInfo', N'U1329', N'天津城市建设管理职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1335', N'UniversityInfo', N'U1330', N'天津城市职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1336', N'UniversityInfo', N'U1331', N'天津电子信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1337', N'UniversityInfo', N'U1332', N'天津对外经济贸易职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1338', N'UniversityInfo', N'U1333', N'天津工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1339', N'UniversityInfo', N'U1334', N'天津工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1340', N'UniversityInfo', N'U1335', N'天津工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1341', N'UniversityInfo', N'U1336', N'天津工艺美术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1342', N'UniversityInfo', N'U1337', N'天津公安警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1343', N'UniversityInfo', N'U1338', N'天津海运职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1344', N'UniversityInfo', N'U1339', N'天津机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1345', N'UniversityInfo', N'U1340', N'天津交通职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1346', N'UniversityInfo', N'U1341', N'天津开发区职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1347', N'UniversityInfo', N'U1342', N'天津青年职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1348', N'UniversityInfo', N'U1343', N'天津轻工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1349', N'UniversityInfo', N'U1344', N'天津生物工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1350', N'UniversityInfo', N'U1345', N'天津石油职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1351', N'UniversityInfo', N'U1346', N'天津铁道职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1352', N'UniversityInfo', N'U1347', N'天津现代职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1353', N'UniversityInfo', N'U1348', N'天津冶金职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1354', N'UniversityInfo', N'U1349', N'天津医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1355', N'UniversityInfo', N'U1350', N'天津艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1356', N'UniversityInfo', N'U1351', N'天津职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1357', N'UniversityInfo', N'U1352', N'天津中德职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1358', N'UniversityInfo', N'U1353', N'天津市工会管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1359', N'UniversityInfo', N'U1354', N'天津外国语学院滨海外事学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1360', N'UniversityInfo', N'U1355', N'天津体育学院运动与文化艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1361', N'UniversityInfo', N'U1356', N'天津商学院宝德学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1362', N'UniversityInfo', N'U1357', N'天津医科大学临床医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1363', N'UniversityInfo', N'U1358', N'北京科技大学天津学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1364', N'UniversityInfo', N'U1359', N'天津师范大学津沽学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1365', N'UniversityInfo', N'U1360', N'天津理工大学中环信息学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1366', N'UniversityInfo', N'U1361', N'天津大学仁爱学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1367', N'UniversityInfo', N'U1362', N'天津财经大学珠江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1368', N'UniversityInfo', N'U1363', N'南开大学滨海学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1369', N'UniversityInfo', N'U1364', N'重庆大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1370', N'UniversityInfo', N'U1365', N'西南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1371', N'UniversityInfo', N'U1366', N'重庆师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1372', N'UniversityInfo', N'U1367', N'西南政法', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1373', N'UniversityInfo', N'U1368', N'重庆交大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1374', N'UniversityInfo', N'U1369', N'重庆邮电大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1375', N'UniversityInfo', N'U1370', N'重庆医大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1376', N'UniversityInfo', N'U1371', N'重庆工商', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1377', N'UniversityInfo', N'U1372', N'重庆科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1378', N'UniversityInfo', N'U1373', N'重庆工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1379', N'UniversityInfo', N'U1374', N'长江师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1380', N'UniversityInfo', N'U1375', N'四川外国语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1381', N'UniversityInfo', N'U1376', N'四川美院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1382', N'UniversityInfo', N'U1377', N'重庆三峡学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1383', N'UniversityInfo', N'U1378', N'重庆文理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1384', N'UniversityInfo', N'U1379', N'重庆巴渝职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1385', N'UniversityInfo', N'U1380', N'重庆城市职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1386', N'UniversityInfo', N'U1381', N'重庆电力高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1387', N'UniversityInfo', N'U1382', N'重庆电子科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1388', N'UniversityInfo', N'U1383', N'重庆电子职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1389', N'UniversityInfo', N'U1384', N'重庆工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1390', N'UniversityInfo', N'U1385', N'重庆工商职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1391', N'UniversityInfo', N'U1386', N'重庆工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1392', N'UniversityInfo', N'U1387', N'重庆光彩职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1393', N'UniversityInfo', N'U1388', N'重庆海联职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1394', N'UniversityInfo', N'U1389', N'重庆机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1395', N'UniversityInfo', N'U1390', N'重庆警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1396', N'UniversityInfo', N'U1391', N'重庆民生职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1397', N'UniversityInfo', N'U1392', N'重庆三峡医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1398', N'UniversityInfo', N'U1393', N'重庆三峡职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1399', N'UniversityInfo', N'U1394', N'重庆水利电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1400', N'UniversityInfo', N'U1395', N'重庆信息技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1401', N'UniversityInfo', N'U1396', N'重庆医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1402', N'UniversityInfo', N'U1397', N'重庆正大软件职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1403', N'UniversityInfo', N'U1398', N'重庆职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1404', N'UniversityInfo', N'U1399', N'重庆教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1405', N'UniversityInfo', N'U1400', N'重庆应用外国语专修学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1406', N'UniversityInfo', N'U1401', N'重庆大学城市科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1407', N'UniversityInfo', N'U1402', N'西南大学育才学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1408', N'UniversityInfo', N'U1403', N'四川外语学院重庆南方翻译学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1409', N'UniversityInfo', N'U1404', N'重庆师范大学涉外商贸学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1410', N'UniversityInfo', N'U1405', N'重庆工商大学融智学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1411', N'UniversityInfo', N'U1406', N'重庆工商大学派斯学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1412', N'UniversityInfo', N'U1407', N'重庆邮电大学移通学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1413', N'UniversityInfo', N'U1408', N'重庆工贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1414', N'UniversityInfo', N'U1409', N'重庆青年职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1415', N'UniversityInfo', N'U1410', N'重庆城市管理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1416', N'UniversityInfo', N'U1411', N'哈工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1417', N'UniversityInfo', N'U1412', N'哈工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1418', N'UniversityInfo', N'U1413', N'东北林大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1419', N'UniversityInfo', N'U1414', N'东北农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1420', N'UniversityInfo', N'U1415', N'哈尔滨医科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1421', N'UniversityInfo', N'U1416', N'黑龙江中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1422', N'UniversityInfo', N'U1417', N'黑工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1423', N'UniversityInfo', N'U1418', N'黑龙江科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1424', N'UniversityInfo', N'U1419', N'哈尔滨学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1425', N'UniversityInfo', N'U1420', N'哈尔滨体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1426', N'UniversityInfo', N'U1421', N'东方学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1427', N'UniversityInfo', N'U1422', N'黑龙江大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1428', N'UniversityInfo', N'U1423', N'哈尔滨商业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1429', N'UniversityInfo', N'U1424', N'哈师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1430', N'UniversityInfo', N'U1425', N'哈理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1431', N'UniversityInfo', N'U1426', N'佳木斯大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1432', N'UniversityInfo', N'U1427', N'齐齐哈尔大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1433', N'UniversityInfo', N'U1428', N'齐齐哈尔医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1434', N'UniversityInfo', N'U1429', N'黑龙江八一农垦大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1435', N'UniversityInfo', N'U1430', N'大庆石油', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1436', N'UniversityInfo', N'U1431', N'大庆师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1437', N'UniversityInfo', N'U1432', N'牡丹江医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1438', N'UniversityInfo', N'U1433', N'牡丹江师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1439', N'UniversityInfo', N'U1434', N'绥化学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1440', N'UniversityInfo', N'U1435', N'黑河学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1441', N'UniversityInfo', N'U1436', N'大庆医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1442', N'UniversityInfo', N'U1437', N'大庆职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1443', N'UniversityInfo', N'U1438', N'大兴安岭职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1444', N'UniversityInfo', N'U1439', N'哈尔滨电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1445', N'UniversityInfo', N'U1440', N'哈尔滨华夏计算机职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1446', N'UniversityInfo', N'U1441', N'哈尔滨金融高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1447', N'UniversityInfo', N'U1442', N'哈尔滨铁道职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1448', N'UniversityInfo', N'U1443', N'哈尔滨现代公共关系职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1449', N'UniversityInfo', N'U1444', N'哈尔滨职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1450', N'UniversityInfo', N'U1445', N'鹤岗师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1451', N'UniversityInfo', N'U1446', N'黑龙江北开职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1452', N'UniversityInfo', N'U1447', N'黑龙江工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1453', N'UniversityInfo', N'U1448', N'黑龙江公安警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1454', N'UniversityInfo', N'U1449', N'黑龙江建筑职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1455', N'UniversityInfo', N'U1450', N'黑龙江林业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1456', N'UniversityInfo', N'U1451', N'黑龙江旅游职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1457', N'UniversityInfo', N'U1452', N'黑龙江煤炭职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1458', N'UniversityInfo', N'U1453', N'黑龙江民族职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1459', N'UniversityInfo', N'U1454', N'黑龙江农垦林业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1460', N'UniversityInfo', N'U1455', N'黑龙江农垦农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1461', N'UniversityInfo', N'U1456', N'黑龙江农垦职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1462', N'UniversityInfo', N'U1457', N'黑龙江农业工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1463', N'UniversityInfo', N'U1458', N'黑龙江农业经济职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1464', N'UniversityInfo', N'U1459', N'黑龙江农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1465', N'UniversityInfo', N'U1460', N'黑龙江三江美术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1466', N'UniversityInfo', N'U1461', N'黑龙江商业职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1467', N'UniversityInfo', N'U1462', N'黑龙江生态工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1468', N'UniversityInfo', N'U1463', N'黑龙江生物科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1469', N'UniversityInfo', N'U1464', N'黑龙江司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1470', N'UniversityInfo', N'U1465', N'黑龙江信息技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1471', N'UniversityInfo', N'U1466', N'黑龙江畜牧兽医职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1472', N'UniversityInfo', N'U1467', N'黑龙江艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1473', N'UniversityInfo', N'U1468', N'鸡西大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1474', N'UniversityInfo', N'U1469', N'牡丹江大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1475', N'UniversityInfo', N'U1470', N'七台河职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1476', N'UniversityInfo', N'U1471', N'齐齐哈尔高等师范专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1477', N'UniversityInfo', N'U1472', N'齐齐哈尔职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1478', N'UniversityInfo', N'U1473', N'伊春职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1479', N'UniversityInfo', N'U1474', N'哈尔滨师范大学阿城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1480', N'UniversityInfo', N'U1475', N'黑龙江工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1481', N'UniversityInfo', N'U1476', N'黑龙江省政法管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1482', N'UniversityInfo', N'U1477', N'黑龙江交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1483', N'UniversityInfo', N'U1478', N'哈尔滨应用职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1484', N'UniversityInfo', N'U1479', N'黑龙江省教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1485', N'UniversityInfo', N'U1480', N'哈尔滨理工大学远东学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1486', N'UniversityInfo', N'U1481', N'哈尔滨师范大学呼兰学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1487', N'UniversityInfo', N'U1482', N'哈尔滨师范大学恒星学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1488', N'UniversityInfo', N'U1483', N'哈尔滨商业大学德强商务学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1489', N'UniversityInfo', N'U1484', N'大庆石油学院华瑞学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1490', N'UniversityInfo', N'U1485', N'东北农业大学成栋学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1491', N'UniversityInfo', N'U1486', N'黑龙江大学剑桥学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1492', N'UniversityInfo', N'U1487', N'哈尔滨商业大学广厦学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1493', N'UniversityInfo', N'U1488', N'哈尔滨工业大学华德应用技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1494', N'UniversityInfo', N'U1489', N'鹤岗矿务局职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1495', N'UniversityInfo', N'U1490', N'哈尔滨市职工医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1496', N'UniversityInfo', N'U1491', N'佳木斯教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1497', N'UniversityInfo', N'U1492', N'黑龙江幼儿师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1498', N'UniversityInfo', N'U1493', N'哈尔滨外国语学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1499', N'UniversityInfo', N'U1494', N'吉林大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1500', N'UniversityInfo', N'U1495', N'东北师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1501', N'UniversityInfo', N'U1496', N'长春大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1502', N'UniversityInfo', N'U1497', N'吉林农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1503', N'UniversityInfo', N'U1498', N'长春中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1504', N'UniversityInfo', N'U1499', N'东北电力大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1505', N'UniversityInfo', N'U1500', N'吉林化工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1506', N'UniversityInfo', N'U1501', N'吉林建筑', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1507', N'UniversityInfo', N'U1502', N'长春工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1508', N'UniversityInfo', N'U1503', N'长春师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1509', N'UniversityInfo', N'U1504', N'吉林工程师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1510', N'UniversityInfo', N'U1505', N'吉林华桥外语', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1511', N'UniversityInfo', N'U1506', N'长春税务', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1512', N'UniversityInfo', N'U1507', N'吉林体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1513', N'UniversityInfo', N'U1508', N'吉林艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1514', N'UniversityInfo', N'U1509', N'长春工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1515', N'UniversityInfo', N'U1510', N'长春理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1516', N'UniversityInfo', N'U1511', N'延边大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1517', N'UniversityInfo', N'U1512', N'北华大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1518', N'UniversityInfo', N'U1513', N'吉林农业科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1519', N'UniversityInfo', N'U1514', N'吉林医药学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1520', N'UniversityInfo', N'U1515', N'吉林师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1521', N'UniversityInfo', N'U1516', N'白城师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1522', N'UniversityInfo', N'U1517', N'通化师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1523', N'UniversityInfo', N'U1518', N'白城医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1524', N'UniversityInfo', N'U1519', N'长春东方职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1525', N'UniversityInfo', N'U1520', N'长春金融高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1526', N'UniversityInfo', N'U1521', N'长春汽车工业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1527', N'UniversityInfo', N'U1522', N'长春信息技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1528', N'UniversityInfo', N'U1523', N'长春医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1529', N'UniversityInfo', N'U1524', N'长春职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1530', N'UniversityInfo', N'U1525', N'东北师范大学人文学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1531', N'UniversityInfo', N'U1526', N'吉林工商学院—财经校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1532', N'UniversityInfo', N'U1527', N'吉林大学—莱姆顿学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1533', N'UniversityInfo', N'U1528', N'吉林电子信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1534', N'UniversityInfo', N'U1529', N'吉林对外经贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1535', N'UniversityInfo', N'U1530', N'吉林工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1536', N'UniversityInfo', N'U1531', N'吉林公安高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1537', N'UniversityInfo', N'U1532', N'吉林交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1538', N'UniversityInfo', N'U1533', N'吉林工商学院—工程校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1539', N'UniversityInfo', N'U1534', N'吉林农业工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1540', N'UniversityInfo', N'U1535', N'吉林工商学院—商贸校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1541', N'UniversityInfo', N'U1536', N'吉林司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1542', N'UniversityInfo', N'U1537', N'辽源职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1543', N'UniversityInfo', N'U1538', N'四平职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1544', N'UniversityInfo', N'U1539', N'松原职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1545', N'UniversityInfo', N'U1540', N'吉林省教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1546', N'UniversityInfo', N'U1541', N'吉林经济管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1547', N'UniversityInfo', N'U1542', N'长春大学光华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1548', N'UniversityInfo', N'U1543', N'长春大学旅游学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1549', N'UniversityInfo', N'U1544', N'长春工业大学人文信息学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1550', N'UniversityInfo', N'U1545', N'吉林艺术学院动画学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1551', N'UniversityInfo', N'U1546', N'长春理工大学光电信息学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1552', N'UniversityInfo', N'U1547', N'长春税务学院信息经济学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1553', N'UniversityInfo', N'U1548', N'吉林农业大学发展学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1554', N'UniversityInfo', N'U1549', N'吉林师范大学博达学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1555', N'UniversityInfo', N'U1550', N'吉林铁道职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1556', N'UniversityInfo', N'U1551', N'白城职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1557', N'UniversityInfo', N'U1552', N'吉林建筑工程学院建筑装饰学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1558', N'UniversityInfo', N'U1553', N'吉林建筑工程学院城建学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1559', N'UniversityInfo', N'U1554', N'大连理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1560', N'UniversityInfo', N'U1555', N'东北大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1561', N'UniversityInfo', N'U1556', N'辽宁大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1562', N'UniversityInfo', N'U1557', N'大连海事', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1563', N'UniversityInfo', N'U1558', N'东北财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1564', N'UniversityInfo', N'U1559', N'大连大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1565', N'UniversityInfo', N'U1560', N'大连交大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1566', N'UniversityInfo', N'U1561', N'大连医大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1567', N'UniversityInfo', N'U1562', N'辽宁师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1568', N'UniversityInfo', N'U1563', N'大连民族', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1569', N'UniversityInfo', N'U1564', N'大连工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1570', N'UniversityInfo', N'U1565', N'大连水产', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1571', N'UniversityInfo', N'U1566', N'大连外国语学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1572', N'UniversityInfo', N'U1567', N'辽宁外经贸', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1573', N'UniversityInfo', N'U1568', N'沈阳大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1574', N'UniversityInfo', N'U1569', N'沈阳理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1575', N'UniversityInfo', N'U1570', N'沈阳工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1576', N'UniversityInfo', N'U1571', N'沈阳建筑', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1577', N'UniversityInfo', N'U1572', N'沈阳农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1578', N'UniversityInfo', N'U1573', N'辽宁中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1579', N'UniversityInfo', N'U1574', N'沈阳药科', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1580', N'UniversityInfo', N'U1575', N'沈阳师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1581', N'UniversityInfo', N'U1576', N'中国刑警学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1582', N'UniversityInfo', N'U1577', N'沈阳化工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1583', N'UniversityInfo', N'U1578', N'沈阳航空工业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1584', N'UniversityInfo', N'U1579', N'沈阳工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1585', N'UniversityInfo', N'U1580', N'沈阳医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1586', N'UniversityInfo', N'U1581', N'沈阳体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1587', N'UniversityInfo', N'U1582', N'鲁迅美院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1588', N'UniversityInfo', N'U1583', N'沈阳音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1589', N'UniversityInfo', N'U1584', N'中国医科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1590', N'UniversityInfo', N'U1585', N'辽宁工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1591', N'UniversityInfo', N'U1586', N'辽宁石化', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1592', N'UniversityInfo', N'U1587', N'鞍山科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1593', N'UniversityInfo', N'U1588', N'鞍山师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1594', N'UniversityInfo', N'U1589', N'渤海大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1595', N'UniversityInfo', N'U1590', N'辽宁工业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1596', N'UniversityInfo', N'U1591', N'辽宁医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1597', N'UniversityInfo', N'U1592', N'辽宁科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1598', N'UniversityInfo', N'U1593', N'辽东学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1599', N'UniversityInfo', N'U1594', N'鞍山市高等职业专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1600', N'UniversityInfo', N'U1595', N'渤海船舶职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1601', N'UniversityInfo', N'U1596', N'渤海大学文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1602', N'UniversityInfo', N'U1597', N'朝阳师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1603', N'UniversityInfo', N'U1598', N'大连东软信息学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1604', N'UniversityInfo', N'U1599', N'大连翻译职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1605', N'UniversityInfo', N'U1600', N'大连枫叶职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1606', N'UniversityInfo', N'U1601', N'大连软件职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1607', N'UniversityInfo', N'U1602', N'大连商务职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1608', N'UniversityInfo', N'U1603', N'大连艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1609', N'UniversityInfo', N'U1604', N'大连职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1610', N'UniversityInfo', N'U1605', N'抚顺师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1611', N'UniversityInfo', N'U1606', N'抚顺职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1612', N'UniversityInfo', N'U1607', N'阜新高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1613', N'UniversityInfo', N'U1608', N'锦州商务职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1614', N'UniversityInfo', N'U1609', N'锦州师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1615', N'UniversityInfo', N'U1610', N'辽宁广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1616', N'UniversityInfo', N'U1611', N'辽宁广告职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1617', N'UniversityInfo', N'U1612', N'辽宁机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1618', N'UniversityInfo', N'U1613', N'辽宁交通高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1619', N'UniversityInfo', N'U1614', N'沈阳大学师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1620', N'UniversityInfo', N'U1615', N'辽宁金融职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1621', N'UniversityInfo', N'U1616', N'辽宁经济职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1622', N'UniversityInfo', N'U1617', N'辽宁警官高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1623', N'UniversityInfo', N'U1618', N'辽宁科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1624', N'UniversityInfo', N'U1619', N'辽宁林业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1625', N'UniversityInfo', N'U1620', N'辽宁美术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1626', N'UniversityInfo', N'U1621', N'辽宁农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1627', N'UniversityInfo', N'U1622', N'辽宁商贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1628', N'UniversityInfo', N'U1623', N'辽宁石化职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1629', N'UniversityInfo', N'U1624', N'大连广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1630', N'UniversityInfo', N'U1625', N'辽宁体育运动职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1631', N'UniversityInfo', N'U1626', N'辽宁信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1632', N'UniversityInfo', N'U1627', N'辽阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1633', N'UniversityInfo', N'U1628', N'盘锦职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1634', N'UniversityInfo', N'U1629', N'沈阳航空职业��术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1635', N'UniversityInfo', N'U1630', N'沈阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1636', N'UniversityInfo', N'U1631', N'辽宁职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1637', N'UniversityInfo', N'U1632', N'铁岭师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1638', N'UniversityInfo', N'U1633', N'营口职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1639', N'UniversityInfo', N'U1634', N'沈阳广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1640', N'UniversityInfo', N'U1635', N'青岛峻通科技专修学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1641', N'UniversityInfo', N'U1636', N'辽河石油职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1642', N'UniversityInfo', N'U1637', N'青岛广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1643', N'UniversityInfo', N'U1638', N'沈阳航空工业学院北方科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1644', N'UniversityInfo', N'U1639', N'沈阳理工大学应用技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1645', N'UniversityInfo', N'U1640', N'大连工业大学艺术与信息工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1646', N'UniversityInfo', N'U1641', N'大连交通大学信息工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1647', N'UniversityInfo', N'U1642', N'沈阳建筑大学城市建设学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1648', N'UniversityInfo', N'U1643', N'辽宁科技大学信息技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1649', N'UniversityInfo', N'U1644', N'辽宁石油化工大学顺华能源学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1650', N'UniversityInfo', N'U1645', N'沈阳化工学院科亚学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1651', N'UniversityInfo', N'U1646', N'沈阳农业大学科学技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1652', N'UniversityInfo', N'U1647', N'中国医科大学临床医药学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1653', N'UniversityInfo', N'U1648', N'大连医科大学中山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1654', N'UniversityInfo', N'U1649', N'辽宁医学院医疗学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1655', N'UniversityInfo', N'U1650', N'辽宁中医药大学杏林学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1656', N'UniversityInfo', N'U1651', N'沈阳医学院何氏视觉科学学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1657', N'UniversityInfo', N'U1652', N'辽宁师范大学海华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1658', N'UniversityInfo', N'U1653', N'东北财经大学津桥商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1659', N'UniversityInfo', N'U1654', N'沈阳师范大学渤海学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1660', N'UniversityInfo', N'U1655', N'大连理工大学城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1661', N'UniversityInfo', N'U1656', N'沈阳大学科技工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1662', N'UniversityInfo', N'U1657', N'辽宁装备制造职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1663', N'UniversityInfo', N'U1658', N'辽宁文化艺术职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1664', N'UniversityInfo', N'U1659', N'辽宁公安司法管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1665', N'UniversityInfo', N'U1660', N'沈阳工业大学工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1666', N'UniversityInfo', N'U1661', N'山东大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1667', N'UniversityInfo', N'U1662', N'中国海洋大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1668', N'UniversityInfo', N'U1663', N'济南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1669', N'UniversityInfo', N'U1664', N'山东建筑大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1670', N'UniversityInfo', N'U1665', N'山东师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1671', N'UniversityInfo', N'U1666', N'山东经济学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1672', N'UniversityInfo', N'U1667', N'山东中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1673', N'UniversityInfo', N'U1668', N'山东轻工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1674', N'UniversityInfo', N'U1669', N'山东交通学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1675', N'UniversityInfo', N'U1670', N'山东警院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1676', N'UniversityInfo', N'U1671', N'山东体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1677', N'UniversityInfo', N'U1672', N'山东艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1678', N'UniversityInfo', N'U1673', N'山东工美', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1679', N'UniversityInfo', N'U1674', N'曲阜师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1680', N'UniversityInfo', N'U1675', N'烟台大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1681', N'UniversityInfo', N'U1676', N'鲁东大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1682', N'UniversityInfo', N'U1677', N'山东工商', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1683', N'UniversityInfo', N'U1678', N'南山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1684', N'UniversityInfo', N'U1679', N'青岛大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1685', N'UniversityInfo', N'U1680', N'山东科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1686', N'UniversityInfo', N'U1681', N'青岛科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1687', N'UniversityInfo', N'U1682', N'青岛理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1688', N'UniversityInfo', N'U1683', N'青岛农业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1689', N'UniversityInfo', N'U1684', N'滨海学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1690', N'UniversityInfo', N'U1685', N'中国石油大学华东', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1691', N'UniversityInfo', N'U1686', N'聊城大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1692', N'UniversityInfo', N'U1687', N'山东理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1693', N'UniversityInfo', N'U1688', N'潍坊医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1694', N'UniversityInfo', N'U1689', N'潍坊学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1695', N'UniversityInfo', N'U1690', N'泰山医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1696', N'UniversityInfo', N'U1691', N'山东财政', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1697', N'UniversityInfo', N'U1692', N'泰山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1698', N'UniversityInfo', N'U1693', N'山东农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1699', N'UniversityInfo', N'U1694', N'滨州医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1700', N'UniversityInfo', N'U1695', N'滨州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1701', N'UniversityInfo', N'U1696', N'济宁医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1702', N'UniversityInfo', N'U1697', N'临沂师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1703', N'UniversityInfo', N'U1698', N'德州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1704', N'UniversityInfo', N'U1699', N'枣庄学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1705', N'UniversityInfo', N'U1700', N'菏泽学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1706', N'UniversityInfo', N'U1701', N'滨州职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1707', N'UniversityInfo', N'U1702', N'德州教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1708', N'UniversityInfo', N'U1703', N'德州科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1709', N'UniversityInfo', N'U1704', N'东营职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1710', N'UniversityInfo', N'U1705', N'哈工大(威海)', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1711', N'UniversityInfo', N'U1706', N'菏泽医学专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1712', N'UniversityInfo', N'U1707', N'济南工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1713', N'UniversityInfo', N'U1708', N'济南铁道职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1714', N'UniversityInfo', N'U1709', N'济南职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1715', N'UniversityInfo', N'U1710', N'济宁学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1716', N'UniversityInfo', N'U1711', N'济宁职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1717', N'UniversityInfo', N'U1712', N'莱芜职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1718', N'UniversityInfo', N'U1713', N'聊城职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1719', N'UniversityInfo', N'U1714', N'青岛飞洋职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1720', N'UniversityInfo', N'U1715', N'青岛港湾职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1721', N'UniversityInfo', N'U1716', N'青岛恒星职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1722', N'UniversityInfo', N'U1717', N'青岛黄海职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1723', N'UniversityInfo', N'U1718', N'青岛求实学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1724', N'UniversityInfo', N'U1719', N'青岛求实职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1725', N'UniversityInfo', N'U1720', N'青岛远洋船员学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1726', N'UniversityInfo', N'U1721', N'青岛职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1727', N'UniversityInfo', N'U1722', N'曲阜远东职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1728', N'UniversityInfo', N'U1723', N'日照职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1729', N'UniversityInfo', N'U1724', N'山东大王职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1730', N'UniversityInfo', N'U1725', N'山东大学威海分校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1731', N'UniversityInfo', N'U1726', N'山东电力高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1732', N'UniversityInfo', N'U1727', N'山东电子职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1733', N'UniversityInfo', N'U1728', N'山东纺织职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1734', N'UniversityInfo', N'U1729', N'山东服装职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1735', N'UniversityInfo', N'U1730', N'山东工业职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1736', N'UniversityInfo', N'U1731', N'山东华宇职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1737', N'UniversityInfo', N'U1732', N'山东化工职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1738', N'UniversityInfo', N'U1733', N'山东交通职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1739', N'UniversityInfo', N'U1734', N'山东经贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1740', N'UniversityInfo', N'U1735', N'山东军星职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1741', N'UniversityInfo', N'U1736', N'山东凯文科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1742', N'UniversityInfo', N'U1737', N'山东科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1743', N'UniversityInfo', N'U1738', N'山东劳动职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1744', N'UniversityInfo', N'U1739', N'山东力明科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1745', N'UniversityInfo', N'U1740', N'山东旅游职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1746', N'UniversityInfo', N'U1741', N'山东铝业职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1747', N'UniversityInfo', N'U1742', N'山东商业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1748', N'UniversityInfo', N'U1743', N'山东胜利职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1749', N'UniversityInfo', N'U1744', N'山东省青岛酒店管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1750', N'UniversityInfo', N'U1745', N'山东水利职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1751', N'UniversityInfo', N'U1746', N'山东省潍坊艺术学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1752', N'UniversityInfo', N'U1747', N'山东圣翰财贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1753', N'UniversityInfo', N'U1748', N'山东水利职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1754', N'UniversityInfo', N'U1749', N'山东水利专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1755', N'UniversityInfo', N'U1750', N'山东丝绸纺织职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1756', N'UniversityInfo', N'U1751', N'山东外国语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1757', N'UniversityInfo', N'U1752', N'山东外贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1758', N'UniversityInfo', N'U1753', N'山东外事翻译学院威海分校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1759', N'UniversityInfo', N'U1754', N'山东外事翻译职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1760', N'UniversityInfo', N'U1755', N'山东万杰医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1761', N'UniversityInfo', N'U1756', N'山东威海财经专修学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1762', N'UniversityInfo', N'U1757', N'山东威海外国语进修学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1763', N'UniversityInfo', N'U1758', N'山东现代职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1764', N'UniversityInfo', N'U1759', N'山东协和职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1765', N'UniversityInfo', N'U1760', N'山东信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1766', N'UniversityInfo', N'U1761', N'山东行政学院(山东经济管理干部学院)', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1767', N'UniversityInfo', N'U1762', N'山东杏林科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1768', N'UniversityInfo', N'U1763', N'山东畜牧兽医职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1769', N'UniversityInfo', N'U1764', N'山东药品食品职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1770', N'UniversityInfo', N'U1765', N'山东医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1771', N'UniversityInfo', N'U1766', N'山东英才职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1772', N'UniversityInfo', N'U1767', N'山东政法学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1773', N'UniversityInfo', N'U1768', N'山东中医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1774', N'UniversityInfo', N'U1769', N'泰山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1775', N'UniversityInfo', N'U1770', N'万杰科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1776', N'UniversityInfo', N'U1771', N'威海市广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1777', N'UniversityInfo', N'U1772', N'威海市交通学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1778', N'UniversityInfo', N'U1773', N'威海职业(技术)学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1779', N'UniversityInfo', N'U1774', N'威海中加国际工商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1780', N'UniversityInfo', N'U1775', N'潍坊工商职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1781', N'UniversityInfo', N'U1776', N'潍坊教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1782', N'UniversityInfo', N'U1777', N'潍坊科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1783', N'UniversityInfo', N'U1778', N'潍坊职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1784', N'UniversityInfo', N'U1779', N'文登师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1785', N'UniversityInfo', N'U1780', N'烟台职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1786', N'UniversityInfo', N'U1781', N'枣庄科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1787', N'UniversityInfo', N'U1782', N'中国石油大学(华东)东营校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1788', N'UniversityInfo', N'U1783', N'淄博广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1789', N'UniversityInfo', N'U1784', N'淄博恒星外国语学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1790', N'UniversityInfo', N'U1785', N'淄博科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1791', N'UniversityInfo', N'U1786', N'淄博师专', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1792', N'UniversityInfo', N'U1787', N'淄博职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1793', N'UniversityInfo', N'U1788', N'山东省教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1794', N'UniversityInfo', N'U1789', N'山东技师学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1795', N'UniversityInfo', N'U1790', N'日照广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1796', N'UniversityInfo', N'U1791', N'中华女子学院山东分院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1797', N'UniversityInfo', N'U1792', N'山东城市建设职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1798', N'UniversityInfo', N'U1793', N'烟台工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1799', N'UniversityInfo', N'U1794', N'山东商务职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1800', N'UniversityInfo', N'U1795', N'烟台汽车工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1801', N'UniversityInfo', N'U1796', N'山东省农业管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1802', N'UniversityInfo', N'U1797', N'山东省青年管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1803', N'UniversityInfo', N'U1798', N'山东省工会管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1804', N'UniversityInfo', N'U1799', N'山东广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1805', N'UniversityInfo', N'U1800', N'德州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1806', N'UniversityInfo', N'U1801', N'中国石油大学胜利学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1807', N'UniversityInfo', N'U1802', N'烟台大学文经学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1808', N'UniversityInfo', N'U1803', N'青岛理工大学琴岛学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1809', N'UniversityInfo', N'U1804', N'山东科技大学泰山科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1810', N'UniversityInfo', N'U1805', N'中国海洋大学青岛学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1811', N'UniversityInfo', N'U1806', N'山东经济学院燕山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1812', N'UniversityInfo', N'U1807', N'青岛农业大学海都学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1813', N'UniversityInfo', N'U1808', N'曲阜师范大学杏坛学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1814', N'UniversityInfo', N'U1809', N'山东财政学院东方学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1815', N'UniversityInfo', N'U1810', N'山东师范大学历山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1816', N'UniversityInfo', N'U1811', N'聊城大学东昌学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1817', N'UniversityInfo', N'U1812', N'济南大学泉城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1818', N'UniversityInfo', N'U1813', N'中国农业大学（烟台校区）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1819', N'UniversityInfo', N'U1814', N'日照师范学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1820', N'UniversityInfo', N'U1815', N'山东艺术设计学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1821', N'UniversityInfo', N'U1816', N'滨州技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1822', N'UniversityInfo', N'U1817', N'山东省贸易职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1823', N'UniversityInfo', N'U1818', N'山东冶金技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1824', N'UniversityInfo', N'U1819', N'山东省济宁市技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1825', N'UniversityInfo', N'U1820', N'济南广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1826', N'UniversityInfo', N'U1821', N'山西大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1827', N'UniversityInfo', N'U1822', N'太原理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1828', N'UniversityInfo', N'U1823', N'中北大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1829', N'UniversityInfo', N'U1824', N'山西医大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1830', N'UniversityInfo', N'U1825', N'山西中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1831', N'UniversityInfo', N'U1826', N'太原师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1832', N'UniversityInfo', N'U1827', N'太原科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1833', N'UniversityInfo', N'U1828', N'山西财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1834', N'UniversityInfo', N'U1829', N'山西师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1835', N'UniversityInfo', N'U1830', N'山西农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1836', N'UniversityInfo', N'U1831', N'大同大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1837', N'UniversityInfo', N'U1832', N'长治医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1838', N'UniversityInfo', N'U1833', N'长治学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1839', N'UniversityInfo', N'U1834', N'运城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1840', N'UniversityInfo', N'U1835', N'晋中学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1841', N'UniversityInfo', N'U1836', N'忻州师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1842', N'UniversityInfo', N'U1837', N'北岳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1843', N'UniversityInfo', N'U1838', N'长治职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1844', N'UniversityInfo', N'U1839', N'晋城职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1845', N'UniversityInfo', N'U1840', N'晋中职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1846', N'UniversityInfo', N'U1841', N'临汾职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1847', N'UniversityInfo', N'U1842', N'潞安职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1848', N'UniversityInfo', N'U1843', N'吕梁高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1849', N'UniversityInfo', N'U1844', N'山西财贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1850', N'UniversityInfo', N'U1845', N'山西财政税务专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1851', N'UniversityInfo', N'U1846', N'山西电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1852', N'UniversityInfo', N'U1847', N'山西工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1853', N'UniversityInfo', N'U1848', N'山西工商职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1854', N'UniversityInfo', N'U1849', N'山西管理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1855', N'UniversityInfo', N'U1850', N'山西国际商务职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1856', N'UniversityInfo', N'U1851', N'山西华澳商贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1857', N'UniversityInfo', N'U1852', N'山西机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1858', N'UniversityInfo', N'U1853', N'山西建筑职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1859', N'UniversityInfo', N'U1854', N'山西交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1860', N'UniversityInfo', N'U1855', N'山西金融职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1861', N'UniversityInfo', N'U1856', N'山西警官高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1862', N'UniversityInfo', N'U1857', N'山西警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1863', N'UniversityInfo', N'U1858', N'山西林业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1864', N'UniversityInfo', N'U1859', N'山西旅游职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1865', N'UniversityInfo', N'U1860', N'山西煤炭职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1866', N'UniversityInfo', N'U1861', N'山西生物应用职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1867', N'UniversityInfo', N'U1862', N'山西水利职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1868', N'UniversityInfo', N'U1863', N'山西体育职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1869', N'UniversityInfo', N'U1864', N'山西同文外语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1870', N'UniversityInfo', N'U1865', N'山西戏剧职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1871', N'UniversityInfo', N'U1866', N'山西信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1872', N'UniversityInfo', N'U1867', N'山西兴华职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1873', N'UniversityInfo', N'U1868', N'山西艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1874', N'UniversityInfo', N'U1869', N'山西运城农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1875', N'UniversityInfo', N'U1870', N'山西运城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1876', N'UniversityInfo', N'U1871', N'山西综合职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1877', N'UniversityInfo', N'U1872', N'太原城市职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1878', N'UniversityInfo', N'U1873', N'太原大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1879', N'UniversityInfo', N'U1874', N'太原电力高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1880', N'UniversityInfo', N'U1875', N'太原旅游职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1881', N'UniversityInfo', N'U1876', N'忻州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1882', N'UniversityInfo', N'U1877', N'阳泉职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1883', N'UniversityInfo', N'U1878', N'山西广播电影电视管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1884', N'UniversityInfo', N'U1879', N'山西城市职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1885', N'UniversityInfo', N'U1880', N'运城农业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1886', N'UniversityInfo', N'U1881', N'山西广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1887', N'UniversityInfo', N'U1882', N'晋中学院师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1888', N'UniversityInfo', N'U1883', N'朔州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1889', N'UniversityInfo', N'U1884', N'山西农业大学平遥机电学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1890', N'UniversityInfo', N'U1885', N'山西农业大学信息学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1891', N'UniversityInfo', N'U1886', N'山西农业大学太原畜牧兽医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1892', N'UniversityInfo', N'U1887', N'山西农业大学太原园艺学院（太原农业学校）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1893', N'UniversityInfo', N'U1888', N'山西农业大学原平农学院（原平农业学校）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1894', N'UniversityInfo', N'U1889', N'太原科技大学运城工学院（运城工学院）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1895', N'UniversityInfo', N'U1890', N'山西财经大学运城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1896', N'UniversityInfo', N'U1891', N'山西医科大学汾阳分院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1897', N'UniversityInfo', N'U1892', N'山西医科大学晋祠学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1898', N'UniversityInfo', N'U1893', N'太原科技大学华科学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1899', N'UniversityInfo', N'U1894', N'山西财经大学华商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1900', N'UniversityInfo', N'U1895', N'中北大学信息商务学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1901', N'UniversityInfo', N'U1896', N'山西师范大学现代文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1902', N'UniversityInfo', N'U1897', N'忻州师范学院五寨分院（五寨师范学院）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1903', N'UniversityInfo', N'U1898', N'山西大学商务学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1904', N'UniversityInfo', N'U1899', N'太原工业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1905', N'UniversityInfo', N'U1900', N'山西经济管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1906', N'UniversityInfo', N'U1901', N'西安交大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1907', N'UniversityInfo', N'U1902', N'长安大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1908', N'UniversityInfo', N'U1903', N'西北工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1909', N'UniversityInfo', N'U1904', N'西北大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1910', N'UniversityInfo', N'U1905', N'陕西师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1911', N'UniversityInfo', N'U1906', N'西安电子科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1912', N'UniversityInfo', N'U1907', N'西安理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1913', N'UniversityInfo', N'U1908', N'西安科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1914', N'UniversityInfo', N'U1909', N'西安工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1915', N'UniversityInfo', N'U1910', N'西外', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1916', N'UniversityInfo', N'U1911', N'西邮', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1917', N'UniversityInfo', N'U1912', N'西安医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1918', N'UniversityInfo', N'U1913', N'西安财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1919', N'UniversityInfo', N'U1914', N'西北政法', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1920', N'UniversityInfo', N'U1915', N'西安体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1921', N'UniversityInfo', N'U1916', N'西安美院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1922', N'UniversityInfo', N'U1917', N'西安音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1923', N'UniversityInfo', N'U1918', N'西安文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1924', N'UniversityInfo', N'U1919', N'西京学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1925', N'UniversityInfo', N'U1920', N'西安翻译学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1926', N'UniversityInfo', N'U1921', N'培华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1927', N'UniversityInfo', N'U1922', N'欧亚学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1928', N'UniversityInfo', N'U1923', N'西安外事', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1929', N'UniversityInfo', N'U1924', N'西安石油', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1930', N'UniversityInfo', N'U1925', N'西安建筑科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1931', N'UniversityInfo', N'U1926', N'第四军医大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1932', N'UniversityInfo', N'U1927', N'西安电子科技大学高等职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1933', N'UniversityInfo', N'U1928', N'西北工业大学明德学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1934', N'UniversityInfo', N'U1929', N'陕西师范大学高等职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1935', N'UniversityInfo', N'U1930', N'长安大学兴华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1936', N'UniversityInfo', N'U1931', N'延安大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1937', N'UniversityInfo', N'U1932', N'陕西中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1938', N'UniversityInfo', N'U1933', N'咸阳师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1939', N'UniversityInfo', N'U1934', N'陕西科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1940', N'UniversityInfo', N'U1935', N'宝鸡文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1941', N'UniversityInfo', N'U1936', N'渭南师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1942', N'UniversityInfo', N'U1937', N'陕西理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1943', N'UniversityInfo', N'U1938', N'榆林学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1944', N'UniversityInfo', N'U1939', N'商洛学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1945', N'UniversityInfo', N'U1940', N'安康学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1946', N'UniversityInfo', N'U1941', N'西北农林科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1947', N'UniversityInfo', N'U1942', N'安康职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1948', N'UniversityInfo', N'U1943', N'宝鸡职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1949', N'UniversityInfo', N'U1944', N'汉中职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1950', N'UniversityInfo', N'U1945', N'陕西财经职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1951', N'UniversityInfo', N'U1946', N'陕西电子科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1952', N'UniversityInfo', N'U1947', N'陕西电子信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1953', N'UniversityInfo', N'U1948', N'陕西纺织服装职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1954', N'UniversityInfo', N'U1949', N'陕西服装艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1955', N'UniversityInfo', N'U1950', N'陕西工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1956', N'UniversityInfo', N'U1951', N'陕西国防工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1957', N'UniversityInfo', N'U1952', N'陕西国际商贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1958', N'UniversityInfo', N'U1953', N'陕西航空职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1959', N'UniversityInfo', N'U1954', N'陕西交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1960', N'UniversityInfo', N'U1955', N'陕西经济管理职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1961', N'UniversityInfo', N'U1956', N'陕西警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1962', N'UniversityInfo', N'U1957', N'陕西旅游烹饪职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1963', N'UniversityInfo', N'U1958', N'陕西能源职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1964', N'UniversityInfo', N'U1959', N'陕西青年职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1965', N'UniversityInfo', N'U1960', N'陕西铁路工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1966', N'UniversityInfo', N'U1961', N'陕西邮电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1967', N'UniversityInfo', N'U1962', N'陕西职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1968', N'UniversityInfo', N'U1963', N'商洛职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1969', N'UniversityInfo', N'U1964', N'铜川职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1970', N'UniversityInfo', N'U1965', N'渭南职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1971', N'UniversityInfo', N'U1966', N'西安电力高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1972', N'UniversityInfo', N'U1967', N'西安东方亚太职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1973', N'UniversityInfo', N'U1968', N'西安高新科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1974', N'UniversityInfo', N'U1969', N'西安工程大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1975', N'UniversityInfo', N'U1970', N'西安海棠职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1976', N'UniversityInfo', N'U1971', N'西安航空技术高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1977', N'UniversityInfo', N'U1972', N'西安航空职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1978', N'UniversityInfo', N'U1973', N'西安科技商贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1979', N'UniversityInfo', N'U1974', N'西安汽车科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1980', N'UniversityInfo', N'U1975', N'西安三资职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1981', N'UniversityInfo', N'U1976', N'西安思源学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1982', N'UniversityInfo', N'U1977', N'西安铁路职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1983', N'UniversityInfo', N'U1978', N'西安职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1984', N'UniversityInfo', N'U1979', N'咸阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1985', N'UniversityInfo', N'U1980', N'延安职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1986', N'UniversityInfo', N'U1981', N'杨凌职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1987', N'UniversityInfo', N'U1982', N'陕西银行学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1988', N'UniversityInfo', N'U1983', N'西安机电信息技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1989', N'UniversityInfo', N'U1984', N'陕西教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1990', N'UniversityInfo', N'U1985', N'陕西省旅游学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1991', N'UniversityInfo', N'U1986', N'西安铁路工程职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1992', N'UniversityInfo', N'U1987', N'西安华西专修大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1993', N'UniversityInfo', N'U1988', N'西安航空职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1994', N'UniversityInfo', N'U1989', N'西安建筑科技大学华清学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1995', N'UniversityInfo', N'U1990', N'西安财经学院行知学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1996', N'UniversityInfo', N'U1991', N'陕西科技大学镐京学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1997', N'UniversityInfo', N'U1992', N'西安工业大学北方信息工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1998', N'UniversityInfo', N'U1993', N'延安大学西安创新学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'1999', N'UniversityInfo', N'U1994', N'西安电子科技大学长安学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2000', N'UniversityInfo', N'U1995', N'西安理工大学高科学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2001', N'UniversityInfo', N'U1996', N'西安科技大学高新学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2002', N'UniversityInfo', N'U1997', N'西安交通大学城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2003', N'UniversityInfo', N'U1998', N'西北大学现代学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2004', N'UniversityInfo', N'U1999', N'河北大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2005', N'UniversityInfo', N'U2000', N'河北农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2006', N'UniversityInfo', N'U2001', N'中央司法警官学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2007', N'UniversityInfo', N'U2002', N'石家庄铁院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2008', N'UniversityInfo', N'U2003', N'石家庄经院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2009', N'UniversityInfo', N'U2004', N'河北师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2010', N'UniversityInfo', N'U2005', N'河北科技', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2011', N'UniversityInfo', N'U2006', N'河北医科', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2012', N'UniversityInfo', N'U2007', N'河北经贸', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2013', N'UniversityInfo', N'U2008', N'河北体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2014', N'UniversityInfo', N'U2009', N'石家庄学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2015', N'UniversityInfo', N'U2010', N'燕山大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2016', N'UniversityInfo', N'U2011', N'河北科师', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2017', N'UniversityInfo', N'U2012', N'河北理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2018', N'UniversityInfo', N'U2013', N'华北煤炭医学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2019', N'UniversityInfo', N'U2014', N'唐山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2020', N'UniversityInfo', N'U2015', N'唐山师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2021', N'UniversityInfo', N'U2016', N'华北航工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2022', N'UniversityInfo', N'U2017', N'廊坊师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2023', N'UniversityInfo', N'U2018', N'防灾科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2024', N'UniversityInfo', N'U2019', N'华北科技', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2025', N'UniversityInfo', N'U2020', N'河北建工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2026', N'UniversityInfo', N'U2021', N'北方学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2027', N'UniversityInfo', N'U2022', N'承德医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2028', N'UniversityInfo', N'U2023', N'邢台学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2029', N'UniversityInfo', N'U2024', N'河北工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2030', N'UniversityInfo', N'U2025', N'邯郸学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2031', N'UniversityInfo', N'U2026', N'衡水学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2032', N'UniversityInfo', N'U2027', N'保定电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2033', N'UniversityInfo', N'U2028', N'保定科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2034', N'UniversityInfo', N'U2029', N'河北金融学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2035', N'UniversityInfo', N'U2030', N'保定学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2036', N'UniversityInfo', N'U2031', N'保定职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2037', N'UniversityInfo', N'U2032', N'渤海石油职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2038', N'UniversityInfo', N'U2033', N'沧州师范专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2039', N'UniversityInfo', N'U2034', N'沧州医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2040', N'UniversityInfo', N'U2035', N'沧州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2041', N'UniversityInfo', N'U2036', N'河北旅游职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2042', N'UniversityInfo', N'U2037', N'承德民族师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2043', N'UniversityInfo', N'U2038', N'承德石油高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2044', N'UniversityInfo', N'U2039', N'大庆石油学院秦皇岛分院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2045', N'UniversityInfo', N'U2040', N'东北大学秦皇岛校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2046', N'UniversityInfo', N'U2041', N'邯郸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2047', N'UniversityInfo', N'U2042', N'河北大学医学部', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2048', N'UniversityInfo', N'U2043', N'河北工程技术高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2049', N'UniversityInfo', N'U2044', N'河北工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2050', N'UniversityInfo', N'U2045', N'河北公安警察职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2051', N'UniversityInfo', N'U2046', N'河北化工医药职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2052', N'UniversityInfo', N'U2047', N'河北机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2053', N'UniversityInfo', N'U2048', N'河北建材职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2054', N'UniversityInfo', N'U2049', N'河北交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2055', N'UniversityInfo', N'U2050', N'河北京都高尔夫职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2056', N'UniversityInfo', N'U2051', N'河北农业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2057', N'UniversityInfo', N'U2052', N'河北农业大学海洋学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2058', N'UniversityInfo', N'U2053', N'河北女子职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2059', N'UniversityInfo', N'U2054', N'河北软件职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2060', N'UniversityInfo', N'U2055', N'河北省艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2061', N'UniversityInfo', N'U2056', N'河北石油职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2062', N'UniversityInfo', N'U2057', N'河北司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2063', N'UniversityInfo', N'U2058', N'河北通信职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2064', N'UniversityInfo', N'U2059', N'河北远东职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2065', N'UniversityInfo', N'U2060', N'河北政法管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2066', N'UniversityInfo', N'U2061', N'河北职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2067', N'UniversityInfo', N'U2062', N'衡水职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2068', N'UniversityInfo', N'U2063', N'华北电力大学(保定)', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2069', N'UniversityInfo', N'U2064', N'监督管理局', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2070', N'UniversityInfo', N'U2065', N'廊坊大学城北大方正软件学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2071', N'UniversityInfo', N'U2066', N'廊坊东方大学城北京澳际联邦英语学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2072', N'UniversityInfo', N'U2067', N'廊坊东方大学城北京财经学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2073', N'UniversityInfo', N'U2068', N'廊坊东方大学城北京城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2074', N'UniversityInfo', N'U2069', N'廊坊东方大学城北京传媒学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2075', N'UniversityInfo', N'U2070', N'廊坊东方大学城北京经济技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2076', N'UniversityInfo', N'U2071', N'廊坊东方大学城北京经贸职业学院航空服务学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2077', N'UniversityInfo', N'U2072', N'廊坊东方大学城北京联合大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2078', N'UniversityInfo', N'U2073', N'廊坊东方大学城北京中医药大学中专部', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2079', N'UniversityInfo', N'U2074', N'廊坊东方大学城河北体育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2080', N'UniversityInfo', N'U2075', N'廊坊东方大学城廊坊职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2081', N'UniversityInfo', N'U2076', N'秦皇岛教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2082', N'UniversityInfo', N'U2077', N'秦皇岛外国语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2083', N'UniversityInfo', N'U2078', N'秦皇岛职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2084', N'UniversityInfo', N'U2079', N'石家庄东方美术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2085', N'UniversityInfo', N'U2080', N'石家庄法商职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2086', N'UniversityInfo', N'U2081', N'石家庄工商职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2087', N'UniversityInfo', N'U2082', N'石家庄计算机职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2088', N'UniversityInfo', N'U2083', N'石家庄科技信息职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2089', N'UniversityInfo', N'U2084', N'石家庄联合技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2090', N'UniversityInfo', N'U2085', N'石家庄铁路职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2091', N'UniversityInfo', N'U2086', N'石家庄外国语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2092', N'UniversityInfo', N'U2087', N'石家庄外经贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2093', N'UniversityInfo', N'U2088', N'石家庄外语翻译职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2094', N'UniversityInfo', N'U2089', N'石家庄信息工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2095', N'UniversityInfo', N'U2090', N'石家庄医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2096', N'UniversityInfo', N'U2091', N'河北传媒学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2097', N'UniversityInfo', N'U2092', N'石家庄邮电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2098', N'UniversityInfo', N'U2093', N'石家庄职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2099', N'UniversityInfo', N'U2094', N'唐山工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2100', N'UniversityInfo', N'U2095', N'唐山广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2101', N'UniversityInfo', N'U2096', N'唐山科技职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2102', N'UniversityInfo', N'U2097', N'唐山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2103', N'UniversityInfo', N'U2098', N'邢台医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2104', N'UniversityInfo', N'U2099', N'邢台职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2105', N'UniversityInfo', N'U2100', N'张家口职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2106', N'UniversityInfo', N'U2101', N'中国地质大学长城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2107', N'UniversityInfo', N'U2102', N'中国环境管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2108', N'UniversityInfo', N'U2103', N'中国民航管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2109', N'UniversityInfo', N'U2104', N'张家口教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2110', N'UniversityInfo', N'U2105', N'河北能源职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2111', N'UniversityInfo', N'U2106', N'承德卫生学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2112', N'UniversityInfo', N'U2107', N'邯郸中原外国语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2113', N'UniversityInfo', N'U2108', N'河北师范大学汇华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2114', N'UniversityInfo', N'U2109', N'华北煤炭医学院冀唐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2115', N'UniversityInfo', N'U2110', N'河北医科大学临床学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2116', N'UniversityInfo', N'U2111', N'河北农业大学现代科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2117', N'UniversityInfo', N'U2112', N'石家庄铁道学院四方学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2118', N'UniversityInfo', N'U2113', N'燕山大学里仁学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2119', N'UniversityInfo', N'U2114', N'河北工程大学科信学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2120', N'UniversityInfo', N'U2115', N'河北理工大学轻工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2121', N'UniversityInfo', N'U2116', N'河北大学工商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2122', N'UniversityInfo', N'U2117', N'河北经贸大学经济管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2123', N'UniversityInfo', N'U2118', N'郑州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2124', N'UniversityInfo', N'U2119', N'河南工业', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2125', N'UniversityInfo', N'U2120', N'河南农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2126', N'UniversityInfo', N'U2121', N'华北水利水电', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2127', N'UniversityInfo', N'U2122', N'郑州轻工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2128', N'UniversityInfo', N'U2123', N'郑州航空工业', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2129', N'UniversityInfo', N'U2124', N'黄河科技', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2130', N'UniversityInfo', N'U2125', N'中原工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2131', N'UniversityInfo', N'U2126', N'河南中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2132', N'UniversityInfo', N'U2127', N'河南财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2133', N'UniversityInfo', N'U2128', N'河南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2134', N'UniversityInfo', N'U2129', N'河南科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2135', N'UniversityInfo', N'U2130', N'洛阳师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2136', N'UniversityInfo', N'U2131', N'安阳工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2137', N'UniversityInfo', N'U2132', N'安阳师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2138', N'UniversityInfo', N'U2133', N'南阳理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2139', N'UniversityInfo', N'U2134', N'南阳师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2140', N'UniversityInfo', N'U2135', N'平顶山工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2141', N'UniversityInfo', N'U2136', N'平顶山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2142', N'UniversityInfo', N'U2137', N'新乡医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2143', N'UniversityInfo', N'U2138', N'河南科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2144', N'UniversityInfo', N'U2139', N'河南师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2145', N'UniversityInfo', N'U2140', N'信阳师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2146', N'UniversityInfo', N'U2141', N'商丘师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2147', N'UniversityInfo', N'U2142', N'周口师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2148', N'UniversityInfo', N'U2143', N'黄淮学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2149', N'UniversityInfo', N'U2144', N'许昌学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2150', N'UniversityInfo', N'U2145', N'河南理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2151', N'UniversityInfo', N'U2146', N'河南财政税务高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2152', N'UniversityInfo', N'U2147', N'河南工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2153', N'UniversityInfo', N'U2148', N'河南工业贸易职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2154', N'UniversityInfo', N'U2149', N'河南工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2155', N'UniversityInfo', N'U2150', N'河南公安高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2156', N'UniversityInfo', N'U2151', N'河南广播影视学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2157', N'UniversityInfo', N'U2152', N'河南机电高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2158', N'UniversityInfo', N'U2153', N'河南检察职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2159', N'UniversityInfo', N'U2154', N'河南交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2160', N'UniversityInfo', N'U2155', N'河南教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2161', N'UniversityInfo', N'U2156', N'河南经贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2162', N'UniversityInfo', N'U2157', N'河南农业职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2163', N'UniversityInfo', N'U2158', N'河南商业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2164', N'UniversityInfo', N'U2159', N'河南省工商行政管理广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2165', N'UniversityInfo', N'U2160', N'河南省政法管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2166', N'UniversityInfo', N'U2161', N'河南司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2167', N'UniversityInfo', N'U2162', N'河南新华电脑学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2168', N'UniversityInfo', N'U2163', N'河南职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2169', N'UniversityInfo', N'U2164', N'河南质量工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2170', N'UniversityInfo', N'U2165', N'鹤壁职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2171', N'UniversityInfo', N'U2166', N'黄河水利职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2172', N'UniversityInfo', N'U2167', N'济源职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2173', N'UniversityInfo', N'U2168', N'焦作大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2174', N'UniversityInfo', N'U2169', N'焦作师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2175', N'UniversityInfo', N'U2170', N'开封大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2176', N'UniversityInfo', N'U2171', N'开封市电子科技专修学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2177', N'UniversityInfo', N'U2172', N'洛阳大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2178', N'UniversityInfo', N'U2173', N'洛阳理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2179', N'UniversityInfo', N'U2174', N'漯河医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2180', N'UniversityInfo', N'U2175', N'漯河职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2181', N'UniversityInfo', N'U2176', N'南阳医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2182', N'UniversityInfo', N'U2177', N'平顶山教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2183', N'UniversityInfo', N'U2178', N'平顶山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2184', N'UniversityInfo', N'U2179', N'平原大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2185', N'UniversityInfo', N'U2180', N'濮阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2186', N'UniversityInfo', N'U2181', N'三门峡职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2187', N'UniversityInfo', N'U2182', N'商丘科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2188', N'UniversityInfo', N'U2183', N'商丘医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2189', N'UniversityInfo', N'U2184', N'商丘职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2190', N'UniversityInfo', N'U2185', N'嵩山少林武术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2191', N'UniversityInfo', N'U2186', N'铁道警官高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2192', N'UniversityInfo', N'U2187', N'新乡师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2193', N'UniversityInfo', N'U2188', N'新乡市教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2194', N'UniversityInfo', N'U2189', N'信阳农业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2195', N'UniversityInfo', N'U2190', N'信阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2196', N'UniversityInfo', N'U2191', N'许昌职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2197', N'UniversityInfo', N'U2192', N'永城职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2198', N'UniversityInfo', N'U2193', N'郑州大学西亚斯国际学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2199', N'UniversityInfo', N'U2194', N'郑州电力高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2200', N'UniversityInfo', N'U2195', N'郑州电子信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2201', N'UniversityInfo', N'U2196', N'郑州工业安全职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2202', N'UniversityInfo', N'U2197', N'郑州华信职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2203', N'UniversityInfo', N'U2198', N'郑州交通学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2204', N'UniversityInfo', N'U2199', N'郑州经贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2205', N'UniversityInfo', N'U2200', N'郑州科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2206', N'UniversityInfo', N'U2201', N'郑州旅游职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2207', N'UniversityInfo', N'U2202', N'郑州牧业工程高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2208', N'UniversityInfo', N'U2203', N'郑州师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2209', N'UniversityInfo', N'U2204', N'郑州澍青医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2210', N'UniversityInfo', N'U2205', N'郑州铁路职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2211', N'UniversityInfo', N'U2206', N'郑州信息科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2212', N'UniversityInfo', N'U2207', N'郑州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2213', N'UniversityInfo', N'U2208', N'中州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2214', N'UniversityInfo', N'U2209', N'周口职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2215', N'UniversityInfo', N'U2210', N'郑州大学升达经贸管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2216', N'UniversityInfo', N'U2211', N'河南建筑职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2217', N'UniversityInfo', N'U2212', N'洛阳工业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2218', N'UniversityInfo', N'U2213', N'河南职工医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2219', N'UniversityInfo', N'U2214', N'河南科技学院新科学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2220', N'UniversityInfo', N'U2215', N'河南理工大学万方科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2221', N'UniversityInfo', N'U2216', N'中原工学院信息商务学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2222', N'UniversityInfo', N'U2217', N'安阳师范学院人文管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2223', N'UniversityInfo', N'U2218', N'河南农业大学华豫学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2224', N'UniversityInfo', N'U2219', N'河南财经学院成功学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2225', N'UniversityInfo', N'U2220', N'开封教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2226', N'UniversityInfo', N'U2221', N'河南政法管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2227', N'UniversityInfo', N'U2222', N'河南卫生职工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2228', N'UniversityInfo', N'U2223', N'河南省建筑职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2229', N'UniversityInfo', N'U2224', N'河南大学民生学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2230', N'UniversityInfo', N'U2225', N'河南师范大学新联学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2231', N'UniversityInfo', N'U2226', N'新乡医学院三全学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2232', N'UniversityInfo', N'U2227', N'信阳师范学院华锐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2233', N'UniversityInfo', N'U2228', N'武汉大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2234', N'UniversityInfo', N'U2229', N'华中科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2235', N'UniversityInfo', N'U2230', N'华中农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2236', N'UniversityInfo', N'U2231', N'武汉理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2237', N'UniversityInfo', N'U2232', N'中国地质大学（武汉）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2238', N'UniversityInfo', N'U2233', N'中南财经政法', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2239', N'UniversityInfo', N'U2234', N'中南民族大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2240', N'UniversityInfo', N'U2235', N'华中师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2241', N'UniversityInfo', N'U2236', N'武汉工业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2242', N'UniversityInfo', N'U2237', N'武汉科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2243', N'UniversityInfo', N'U2238', N'湖北中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2244', N'UniversityInfo', N'U2239', N'湖北经济学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2245', N'UniversityInfo', N'U2240', N'湖北警官学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2246', N'UniversityInfo', N'U2241', N'武汉体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2247', N'UniversityInfo', N'U2242', N'湖北美院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2248', N'UniversityInfo', N'U2243', N'武汉音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2249', N'UniversityInfo', N'U2244', N'武汉生物工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2250', N'UniversityInfo', N'U2245', N'湖北工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2251', N'UniversityInfo', N'U2246', N'湖北大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2252', N'UniversityInfo', N'U2247', N'江汉大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2253', N'UniversityInfo', N'U2248', N'武汉工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2254', N'UniversityInfo', N'U2249', N'武汉科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2255', N'UniversityInfo', N'U2250', N'长江大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2256', N'UniversityInfo', N'U2251', N'三峡大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2257', N'UniversityInfo', N'U2252', N'湖北汽院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2258', N'UniversityInfo', N'U2253', N'郧阳医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2259', N'UniversityInfo', N'U2254', N'孝感学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2260', N'UniversityInfo', N'U2255', N'湖北师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2261', N'UniversityInfo', N'U2256', N'黄石理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2262', N'UniversityInfo', N'U2257', N'黄冈师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2263', N'UniversityInfo', N'U2258', N'湖北民族学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2264', N'UniversityInfo', N'U2259', N'襄樊学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2265', N'UniversityInfo', N'U2260', N'咸宁学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2266', N'UniversityInfo', N'U2261', N'长江工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2267', N'UniversityInfo', N'U2262', N'长江职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2268', N'UniversityInfo', N'U2263', N'鄂东职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2269', N'UniversityInfo', N'U2264', N'鄂州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2270', N'UniversityInfo', N'U2265', N'恩施职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2271', N'UniversityInfo', N'U2266', N'湖北财经高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2272', N'UniversityInfo', N'U2267', N'湖北财税职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2273', N'UniversityInfo', N'U2268', N'湖北城市建设职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2274', N'UniversityInfo', N'U2269', N'湖北工业大学商贸学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2275', N'UniversityInfo', N'U2270', N'湖北国土资源职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2276', N'UniversityInfo', N'U2271', N'湖北黄石机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2277', N'UniversityInfo', N'U2272', N'湖北交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2278', N'UniversityInfo', N'U2273', N'湖北第二师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2279', N'UniversityInfo', N'U2274', N'湖北经济管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2280', N'UniversityInfo', N'U2275', N'湖北开放职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2281', N'UniversityInfo', N'U2276', N'湖北民族学院科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2282', N'UniversityInfo', N'U2277', N'湖北轻工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2283', N'UniversityInfo', N'U2278', N'湖北三峡职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2284', N'UniversityInfo', N'U2279', N'湖北生态工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2285', N'UniversityInfo', N'U2280', N'湖北生物科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2286', N'UniversityInfo', N'U2281', N'湖北省水利水电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2287', N'UniversityInfo', N'U2282', N'湖北师范学院文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2288', N'UniversityInfo', N'U2283', N'湖北艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2289', N'UniversityInfo', N'U2284', N'湖北职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2290', N'UniversityInfo', N'U2285', N'湖北中医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2291', N'UniversityInfo', N'U2286', N'黄冈科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2292', N'UniversityInfo', N'U2287', N'黄冈职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2293', N'UniversityInfo', N'U2288', N'江汉艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2294', N'UniversityInfo', N'U2289', N'荆楚理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2295', N'UniversityInfo', N'U2290', N'荆州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2296', N'UniversityInfo', N'U2291', N'沙市职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2297', N'UniversityInfo', N'U2292', N'沙洋师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2298', N'UniversityInfo', N'U2293', N'十堰职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2299', N'UniversityInfo', N'U2294', N'随州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2300', N'UniversityInfo', N'U2295', N'武汉船舶职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2301', N'UniversityInfo', N'U2296', N'武汉电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2302', N'UniversityInfo', N'U2297', N'武汉工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2303', N'UniversityInfo', N'U2298', N'武汉工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2304', N'UniversityInfo', N'U2299', N'武汉航海职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2305', N'UniversityInfo', N'U2300', N'武汉交通职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2306', N'UniversityInfo', N'U2301', N'武汉警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2307', N'UniversityInfo', N'U2302', N'武汉科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2308', N'UniversityInfo', N'U2303', N'武汉理工大学华夏学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2309', N'UniversityInfo', N'U2304', N'武汉民政职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2310', N'UniversityInfo', N'U2305', N'武汉软件工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2311', N'UniversityInfo', N'U2306', N'武汉商贸学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2312', N'UniversityInfo', N'U2307', N'武汉商业服务学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2313', N'UniversityInfo', N'U2308', N'武汉时代职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2314', N'UniversityInfo', N'U2309', N'武汉铁路职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2315', N'UniversityInfo', N'U2310', N'武汉外语外事职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2316', N'UniversityInfo', N'U2311', N'武汉信息传播职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2317', N'UniversityInfo', N'U2312', N'武汉职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2318', N'UniversityInfo', N'U2313', N'仙桃职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2319', N'UniversityInfo', N'U2314', N'咸宁职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2320', N'UniversityInfo', N'U2315', N'襄樊职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2321', N'UniversityInfo', N'U2316', N'孝感学院新技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2322', N'UniversityInfo', N'U2317', N'郧阳师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2323', N'UniversityInfo', N'U2318', N'中南民族大学工商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2324', N'UniversityInfo', N'U2319', N'黄冈广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2325', N'UniversityInfo', N'U2320', N'华中科技大学文华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2326', N'UniversityInfo', N'U2321', N'华中师范大学汉口分校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2327', N'UniversityInfo', N'U2322', N'湖北大学知行学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2328', N'UniversityInfo', N'U2323', N'三峡大学科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2329', N'UniversityInfo', N'U2324', N'武汉科技大学中南分校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2330', N'UniversityInfo', N'U2325', N'湖北工业大学工程技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2331', N'UniversityInfo', N'U2326', N'武汉工业学院工商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2332', N'UniversityInfo', N'U2327', N'武汉工程大学邮电与信息工程学院　', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2333', N'UniversityInfo', N'U2328', N'武汉科技学院外经贸学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2334', N'UniversityInfo', N'U2329', N'江汉大学文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2335', N'UniversityInfo', N'U2330', N'湖北汽车工业学院科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2336', N'UniversityInfo', N'U2331', N'湖北经济学院法商学院　', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2337', N'UniversityInfo', N'U2332', N'武汉体育学院体育科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2338', N'UniversityInfo', N'U2333', N'郧阳医学院药护学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2339', N'UniversityInfo', N'U2334', N'襄樊学院理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2340', N'UniversityInfo', N'U2335', N'中国地质大学江城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2341', N'UniversityInfo', N'U2336', N'长江大学文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2342', N'UniversityInfo', N'U2337', N'长江大学工程技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2343', N'UniversityInfo', N'U2338', N'华中师范大学武汉影视工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2344', N'UniversityInfo', N'U2339', N'武汉大学东湖分校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2345', N'UniversityInfo', N'U2340', N'中南财经政法武汉学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2346', N'UniversityInfo', N'U2341', N'华中科技大学武昌分校　', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2347', N'UniversityInfo', N'U2342', N'湖南师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2348', N'UniversityInfo', N'U2343', N'中南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2349', N'UniversityInfo', N'U2344', N'湖南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2350', N'UniversityInfo', N'U2345', N'长沙理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2351', N'UniversityInfo', N'U2346', N'湖南农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2352', N'UniversityInfo', N'U2347', N'湖南中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2353', N'UniversityInfo', N'U2348', N'中南林业科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2354', N'UniversityInfo', N'U2349', N'长沙学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2355', N'UniversityInfo', N'U2350', N'长沙医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2356', N'UniversityInfo', N'U2351', N'湖南涉外经济', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2357', N'UniversityInfo', N'U2352', N'湖南商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2358', N'UniversityInfo', N'U2353', N'湖南人文科技', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2359', N'UniversityInfo', N'U2354', N'湘潭大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2360', N'UniversityInfo', N'U2355', N'湖南科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2361', N'UniversityInfo', N'U2356', N'湖南工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2362', N'UniversityInfo', N'U2357', N'南华大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2363', N'UniversityInfo', N'U2358', N'吉首大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2364', N'UniversityInfo', N'U2359', N'湖南工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2365', N'UniversityInfo', N'U2360', N'湖南城市', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2366', N'UniversityInfo', N'U2361', N'湖南理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2367', N'UniversityInfo', N'U2362', N'湘南学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2368', N'UniversityInfo', N'U2363', N'衡阳师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2369', N'UniversityInfo', N'U2364', N'湖南文理', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2370', N'UniversityInfo', N'U2365', N'怀化学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2371', N'UniversityInfo', N'U2366', N'湖南科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2372', N'UniversityInfo', N'U2367', N'邵阳学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2373', N'UniversityInfo', N'U2368', N'保险职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2374', N'UniversityInfo', N'U2369', N'长沙电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2375', N'UniversityInfo', N'U2370', N'长沙航空职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2376', N'UniversityInfo', N'U2371', N'长沙环境保护职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2377', N'UniversityInfo', N'U2372', N'长沙民政职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2378', N'UniversityInfo', N'U2373', N'长沙南方职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2379', N'UniversityInfo', N'U2374', N'长沙商贸旅游职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2380', N'UniversityInfo', N'U2375', N'长沙师范专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2381', N'UniversityInfo', N'U2376', N'长沙通信职业技术学���', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2382', N'UniversityInfo', N'U2377', N'长沙职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2383', N'UniversityInfo', N'U2378', N'长沙职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2384', N'UniversityInfo', N'U2379', N'常德职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2385', N'UniversityInfo', N'U2380', N'郴州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2386', N'UniversityInfo', N'U2381', N'衡阳财经工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2387', N'UniversityInfo', N'U2382', N'湖南安全技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2388', N'UniversityInfo', N'U2383', N'湖南财经高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2389', N'UniversityInfo', N'U2384', N'湖南城建职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2390', N'UniversityInfo', N'U2385', N'湖南大众传媒学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2391', N'UniversityInfo', N'U2386', N'湖南第一师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2392', N'UniversityInfo', N'U2387', N'湖南对外经济贸易职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2393', N'UniversityInfo', N'U2388', N'湖南工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2394', N'UniversityInfo', N'U2389', N'湖南工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2395', N'UniversityInfo', N'U2390', N'湖南工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2396', N'UniversityInfo', N'U2391', N'湖南工艺美术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2397', N'UniversityInfo', N'U2392', N'湖南公安高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2398', N'UniversityInfo', N'U2393', N'湖南广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2399', N'UniversityInfo', N'U2394', N'湖南化工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2400', N'UniversityInfo', N'U2395', N'湖南环境生物职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2401', N'UniversityInfo', N'U2396', N'湖南机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2402', N'UniversityInfo', N'U2397', N'湖南建材高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2403', N'UniversityInfo', N'U2398', N'湖南交通工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2404', N'UniversityInfo', N'U2399', N'湖南交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2405', N'UniversityInfo', N'U2400', N'湖南经济干部管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2406', N'UniversityInfo', N'U2401', N'湖南九嶷职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2407', N'UniversityInfo', N'U2402', N'湖南科技经贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2408', N'UniversityInfo', N'U2403', N'湖南科技职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2409', N'UniversityInfo', N'U2404', N'湖南理工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2410', N'UniversityInfo', N'U2405', N'湖南娄底远东职业学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2411', N'UniversityInfo', N'U2406', N'湖南民族职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2412', N'UniversityInfo', N'U2407', N'湖南农业大学国际学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2413', N'UniversityInfo', N'U2408', N'湖南女子大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2414', N'UniversityInfo', N'U2409', N'湖南软件职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2415', N'UniversityInfo', N'U2410', N'湖南商务职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2416', N'UniversityInfo', N'U2411', N'湖南生物环境职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2417', N'UniversityInfo', N'U2412', N'湖南生物机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2418', N'UniversityInfo', N'U2413', N'湖南省水利水电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2419', N'UniversityInfo', N'U2414', N'湖南石油化工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2420', N'UniversityInfo', N'U2415', N'湖南税务高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2421', N'UniversityInfo', N'U2416', N'湖南司法警官职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2422', N'UniversityInfo', N'U2417', N'湖南体育职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2423', N'UniversityInfo', N'U2418', N'湖南铁道职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2424', N'UniversityInfo', N'U2419', N'湖南铁路科技职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2425', N'UniversityInfo', N'U2420', N'湖南同德职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2426', N'UniversityInfo', N'U2421', N'湖南网络工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2427', N'UniversityInfo', N'U2422', N'湖南现代物流职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2428', N'UniversityInfo', N'U2423', N'湖南信息科学职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2429', N'UniversityInfo', N'U2424', N'湖南信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2430', N'UniversityInfo', N'U2425', N'湖南行政学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2431', N'UniversityInfo', N'U2426', N'湖南冶金职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2432', N'UniversityInfo', N'U2427', N'湖南艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2433', N'UniversityInfo', N'U2428', N'湖南中医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2434', N'UniversityInfo', N'U2429', N'怀化医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2435', N'UniversityInfo', N'U2430', N'怀化职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2436', N'UniversityInfo', N'U2431', N'娄底理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2437', N'UniversityInfo', N'U2432', N'娄底市卫生学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2438', N'UniversityInfo', N'U2433', N'娄底职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2439', N'UniversityInfo', N'U2434', N'邵阳医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2440', N'UniversityInfo', N'U2435', N'邵阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2441', N'UniversityInfo', N'U2436', N'湘潭职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2442', N'UniversityInfo', N'U2437', N'湘西民族职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2443', N'UniversityInfo', N'U2438', N'潇湘职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2444', N'UniversityInfo', N'U2439', N'益阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2445', N'UniversityInfo', N'U2440', N'永州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2446', N'UniversityInfo', N'U2441', N'岳阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2447', N'UniversityInfo', N'U2442', N'张家界航空工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2448', N'UniversityInfo', N'U2443', N'株洲师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2449', N'UniversityInfo', N'U2444', N'株洲职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2450', N'UniversityInfo', N'U2445', N'湘潭大学兴湘学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2451', N'UniversityInfo', N'U2446', N'湖南工业大学科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2452', N'UniversityInfo', N'U2447', N'湖南科技大学潇湘学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2453', N'UniversityInfo', N'U2448', N'南华大学船山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2454', N'UniversityInfo', N'U2449', N'湖南商学院北津学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2455', N'UniversityInfo', N'U2450', N'湖南师范大学树达学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2456', N'UniversityInfo', N'U2451', N'湖南农业大学东方科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2457', N'UniversityInfo', N'U2452', N'中南林业科技大学涉外学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2458', N'UniversityInfo', N'U2453', N'湖南文理学院芙蓉学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2459', N'UniversityInfo', N'U2454', N'湖南理工学院南湖学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2460', N'UniversityInfo', N'U2455', N'衡阳师范学院南岳学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2461', N'UniversityInfo', N'U2456', N'湖南工程学院应用技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2462', N'UniversityInfo', N'U2457', N'湖南中医药大学湘杏学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2463', N'UniversityInfo', N'U2458', N'吉首大学张家界学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2464', N'UniversityInfo', N'U2459', N'长沙理工大学城南学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2465', N'UniversityInfo', N'U2460', N'湖南都市职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2466', N'UniversityInfo', N'U2461', N'湖南电子科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2467', N'UniversityInfo', N'U2462', N'湖南外国语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2468', N'UniversityInfo', N'U2463', N'海南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2469', N'UniversityInfo', N'U2464', N'海南医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2470', N'UniversityInfo', N'U2465', N'海南师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2471', N'UniversityInfo', N'U2466', N'华南热带农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2472', N'UniversityInfo', N'U2467', N'琼州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2473', N'UniversityInfo', N'U2468', N'海口经济职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2474', N'UniversityInfo', N'U2469', N'海南经贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2475', N'UniversityInfo', N'U2470', N'海南软件职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2476', N'UniversityInfo', N'U2471', N'海南外国语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2477', N'UniversityInfo', N'U2472', N'海南万和信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2478', N'UniversityInfo', N'U2473', N'海南政法职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2479', N'UniversityInfo', N'U2474', N'海南职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2480', N'UniversityInfo', N'U2475', N'琼台师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2481', N'UniversityInfo', N'U2476', N'三亚航空旅游职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2482', N'UniversityInfo', N'U2477', N'三亚卓达旅游职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2483', N'UniversityInfo', N'U2478', N'海南大学三亚学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2484', N'UniversityInfo', N'U2479', N'南京大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2485', N'UniversityInfo', N'U2480', N'河海大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2486', N'UniversityInfo', N'U2481', N'南京师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2487', N'UniversityInfo', N'U2482', N'南京理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2488', N'UniversityInfo', N'U2483', N'东南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2489', N'UniversityInfo', N'U2484', N'南航', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2490', N'UniversityInfo', N'U2485', N'南京财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2491', N'UniversityInfo', N'U2486', N'南京医科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2492', N'UniversityInfo', N'U2487', N'南京工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2493', N'UniversityInfo', N'U2488', N'南京农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2494', N'UniversityInfo', N'U2489', N'南京林大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2495', N'UniversityInfo', N'U2490', N'南邮', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2496', N'UniversityInfo', N'U2491', N'南京信息工程大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2497', N'UniversityInfo', N'U2492', N'南京中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2498', N'UniversityInfo', N'U2493', N'南京工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2499', N'UniversityInfo', N'U2494', N'金陵科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2500', N'UniversityInfo', N'U2495', N'晓庄学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2501', N'UniversityInfo', N'U2496', N'南京审计学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2502', N'UniversityInfo', N'U2497', N'江苏警官学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2503', N'UniversityInfo', N'U2498', N'南京体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2504', N'UniversityInfo', N'U2499', N'南京艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2505', N'UniversityInfo', N'U2500', N'三江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2506', N'UniversityInfo', N'U2501', N'中国药科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2507', N'UniversityInfo', N'U2502', N'苏州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2508', N'UniversityInfo', N'U2503', N'江南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2509', N'UniversityInfo', N'U2504', N'中国矿大（徐州）', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2510', N'UniversityInfo', N'U2505', N'徐州师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2511', N'UniversityInfo', N'U2506', N'徐州工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2512', N'UniversityInfo', N'U2507', N'徐州医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2513', N'UniversityInfo', N'U2508', N'扬州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2514', N'UniversityInfo', N'U2509', N'江苏大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2515', N'UniversityInfo', N'U2510', N'江苏科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2516', N'UniversityInfo', N'U2511', N'南通大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2517', N'UniversityInfo', N'U2512', N'江苏工业', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2518', N'UniversityInfo', N'U2513', N'常州工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2519', N'UniversityInfo', N'U2514', N'江苏技术师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2520', N'UniversityInfo', N'U2515', N'淮阴工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2521', N'UniversityInfo', N'U2516', N'淮阴师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2522', N'UniversityInfo', N'U2517', N'淮海工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2523', N'UniversityInfo', N'U2518', N'盐城工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2524', N'UniversityInfo', N'U2519', N'盐城师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2525', N'UniversityInfo', N'U2520', N'常熟理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2526', N'UniversityInfo', N'U2521', N'常州纺织服装职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2527', N'UniversityInfo', N'U2522', N'常州工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2528', N'UniversityInfo', N'U2523', N'常州机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2529', N'UniversityInfo', N'U2524', N'常州轻工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2530', N'UniversityInfo', N'U2525', N'常州信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2531', N'UniversityInfo', N'U2526', N'硅湖职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2532', N'UniversityInfo', N'U2527', N'河海大学常州校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2533', N'UniversityInfo', N'U2528', N'淮安信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2534', N'UniversityInfo', N'U2529', N'建东职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2535', N'UniversityInfo', N'U2530', N'健雄职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2536', N'UniversityInfo', N'U2531', N'江海职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2537', N'UniversityInfo', N'U2532', N'江南影视艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2538', N'UniversityInfo', N'U2533', N'江苏财经职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2539', N'UniversityInfo', N'U2534', N'江苏海事职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2540', N'UniversityInfo', N'U2535', N'江苏经贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2541', N'UniversityInfo', N'U2536', N'江苏联合职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2542', N'UniversityInfo', N'U2537', N'江苏农林职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2543', N'UniversityInfo', N'U2538', N'江苏食品职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2544', N'UniversityInfo', N'U2539', N'江苏信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2545', N'UniversityInfo', N'U2540', N'江苏畜牧兽医职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2546', N'UniversityInfo', N'U2541', N'江阴职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2547', N'UniversityInfo', N'U2542', N'金肯职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2548', N'UniversityInfo', N'U2543', N'金山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2549', N'UniversityInfo', N'U2544', N'九州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2550', N'UniversityInfo', N'U2545', N'昆山登云科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2551', N'UniversityInfo', N'U2546', N'连云港师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2552', N'UniversityInfo', N'U2547', N'连云港职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2553', N'UniversityInfo', N'U2548', N'民办明达职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2554', N'UniversityInfo', N'U2549', N'南京动力高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2555', N'UniversityInfo', N'U2550', N'南京工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2556', N'UniversityInfo', N'U2551', N'南京化工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2557', N'UniversityInfo', N'U2552', N'南京交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2558', N'UniversityInfo', N'U2553', N'南京人口管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2559', N'UniversityInfo', N'U2554', N'南京森林公安高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2560', N'UniversityInfo', N'U2555', N'南京视觉艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2561', N'UniversityInfo', N'U2556', N'南京特殊教育职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2562', N'UniversityInfo', N'U2557', N'南京铁道职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2563', N'UniversityInfo', N'U2558', N'南京信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2564', N'UniversityInfo', N'U2559', N'南通纺织职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2565', N'UniversityInfo', N'U2560', N'南通航运职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2566', N'UniversityInfo', N'U2561', N'南通农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2567', N'UniversityInfo', N'U2562', N'南通职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2568', N'UniversityInfo', N'U2563', N'培尔职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2569', N'UniversityInfo', N'U2564', N'沙洲职业工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2570', N'UniversityInfo', N'U2565', N'苏州港大思培科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2571', N'UniversityInfo', N'U2566', N'苏州工业园区职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2572', N'UniversityInfo', N'U2567', N'苏州工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2573', N'UniversityInfo', N'U2568', N'苏州工艺美术职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2574', N'UniversityInfo', N'U2569', N'苏州经贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2575', N'UniversityInfo', N'U2570', N'苏州科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2576', N'UniversityInfo', N'U2571', N'苏州农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2577', N'UniversityInfo', N'U2572', N'苏州托普信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2578', N'UniversityInfo', N'U2573', N'苏州职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2579', N'UniversityInfo', N'U2574', N'宿迁学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2580', N'UniversityInfo', N'U2575', N'泰州师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2581', N'UniversityInfo', N'U2576', N'泰州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2582', N'UniversityInfo', N'U2577', N'无锡城市职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2583', N'UniversityInfo', N'U2578', N'无锡工艺职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2584', N'UniversityInfo', N'U2579', N'无锡科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2585', N'UniversityInfo', N'U2580', N'无锡南洋职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2586', N'UniversityInfo', N'U2581', N'无锡轻工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2587', N'UniversityInfo', N'U2582', N'无锡商业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2588', N'UniversityInfo', N'U2583', N'无锡职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2589', N'UniversityInfo', N'U2584', N'徐州工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2590', N'UniversityInfo', N'U2585', N'徐州广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2591', N'UniversityInfo', N'U2586', N'徐州建筑职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2592', N'UniversityInfo', N'U2587', N'徐州教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2593', N'UniversityInfo', N'U2588', N'徐州工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2594', N'UniversityInfo', N'U2589', N'炎黄职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2595', N'UniversityInfo', N'U2590', N'盐城纺织职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2596', N'UniversityInfo', N'U2591', N'扬州工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2597', N'UniversityInfo', N'U2592', N'扬州环境资源管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2598', N'UniversityInfo', N'U2593', N'扬州环境资源职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2599', N'UniversityInfo', N'U2594', N'扬州教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2600', N'UniversityInfo', N'U2595', N'扬州职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2601', N'UniversityInfo', N'U2596', N'应天职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2602', N'UniversityInfo', N'U2597', N'镇江市高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2603', N'UniversityInfo', N'U2598', N'正德职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2604', N'UniversityInfo', N'U2599', N'中国传媒大学南广学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2605', N'UniversityInfo', N'U2600', N'钟山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2606', N'UniversityInfo', N'U2601', N'紫琅职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2607', N'UniversityInfo', N'U2602', N'江苏广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2608', N'UniversityInfo', N'U2603', N'江苏教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2609', N'UniversityInfo', N'U2604', N'徐州师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2610', N'UniversityInfo', N'U2605', N'江苏省省级机关管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2611', N'UniversityInfo', N'U2606', N'江苏职工医科大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2612', N'UniversityInfo', N'U2607', N'苏州卫生职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2613', N'UniversityInfo', N'U2608', N'盐城卫生职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2614', N'UniversityInfo', N'U2609', N'金陵旅馆管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2615', N'UniversityInfo', N'U2610', N'南京市广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2616', N'UniversityInfo', N'U2611', N'江西财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2617', N'UniversityInfo', N'U2612', N'南昌大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2618', N'UniversityInfo', N'U2613', N'华东交通大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2619', N'UniversityInfo', N'U2614', N'南昌航空大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2620', N'UniversityInfo', N'U2615', N'南昌工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2621', N'UniversityInfo', N'U2616', N'南昌理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2622', N'UniversityInfo', N'U2617', N'江西中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2623', N'UniversityInfo', N'U2618', N'江西科技师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2624', N'UniversityInfo', N'U2619', N'蓝天学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2625', N'UniversityInfo', N'U2620', N'江西农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2626', N'UniversityInfo', N'U2621', N'江西师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2627', N'UniversityInfo', N'U2622', N'东华理工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2628', N'UniversityInfo', N'U2623', N'景德镇陶瓷学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2629', N'UniversityInfo', N'U2624', N'赣南医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2630', N'UniversityInfo', N'U2625', N'赣南师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2631', N'UniversityInfo', N'U2626', N'江西理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2632', N'UniversityInfo', N'U2627', N'上饶师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2633', N'UniversityInfo', N'U2628', N'井冈山大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2634', N'UniversityInfo', N'U2629', N'宜春学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2635', N'UniversityInfo', N'U2630', N'九江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2636', N'UniversityInfo', N'U2631', N'抚州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2637', N'UniversityInfo', N'U2632', N'赣南教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2638', N'UniversityInfo', N'U2633', N'赣西科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2639', N'UniversityInfo', N'U2634', N'江西财经职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2640', N'UniversityInfo', N'U2635', N'江西城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2641', N'UniversityInfo', N'U2636', N'江西大宇学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2642', N'UniversityInfo', N'U2637', N'江西电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2643', N'UniversityInfo', N'U2638', N'江西服装职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2644', N'UniversityInfo', N'U2639', N'江西赣江职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2645', N'UniversityInfo', N'U2640', N'江西工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2646', N'UniversityInfo', N'U2641', N'江西工业工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2647', N'UniversityInfo', N'U2642', N'江西工业贸易职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2648', N'UniversityInfo', N'U2643', N'江西工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2649', N'UniversityInfo', N'U2644', N'江西公安专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2650', N'UniversityInfo', N'U2645', N'江西航空职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2651', N'UniversityInfo', N'U2646', N'江西护理职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2652', N'UniversityInfo', N'U2647', N'江西环境工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2653', N'UniversityInfo', N'U2648', N'江西机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2654', N'UniversityInfo', N'U2649', N'江西建设职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2655', N'UniversityInfo', N'U2650', N'江西交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2656', N'UniversityInfo', N'U2651', N'江西教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2657', N'UniversityInfo', N'U2652', N'江西经济管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2658', N'UniversityInfo', N'U2653', N'江西经济管理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2659', N'UniversityInfo', N'U2654', N'江西科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2660', N'UniversityInfo', N'U2655', N'江西旅游商贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2661', N'UniversityInfo', N'U2656', N'江西南昌教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2662', N'UniversityInfo', N'U2657', N'江西农业工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2663', N'UniversityInfo', N'U2658', N'江西青年职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2664', N'UniversityInfo', N'U2659', N'江西轻工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2665', N'UniversityInfo', N'U2660', N'江西生物科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2666', N'UniversityInfo', N'U2661', N'江西省广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2667', N'UniversityInfo', N'U2662', N'江西司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2668', N'UniversityInfo', N'U2663', N'江西陶瓷工艺美术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2669', N'UniversityInfo', N'U2664', N'江西外语外贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2670', N'UniversityInfo', N'U2665', N'江西先锋软件职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2671', N'UniversityInfo', N'U2666', N'江西现代职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2672', N'UniversityInfo', N'U2667', N'江西信息应用职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2673', N'UniversityInfo', N'U2668', N'江西行政管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2674', N'UniversityInfo', N'U2669', N'江西艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2675', N'UniversityInfo', N'U2670', N'江西应用技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2676', N'UniversityInfo', N'U2671', N'江西渝州科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2677', N'UniversityInfo', N'U2672', N'江西制造职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2678', N'UniversityInfo', N'U2673', N'江西中医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2679', N'UniversityInfo', N'U2674', N'景德镇高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2680', N'UniversityInfo', N'U2675', N'九江职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2681', N'UniversityInfo', N'U2676', N'九江职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2682', N'UniversityInfo', N'U2677', N'南昌钢铁职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2683', N'UniversityInfo', N'U2678', N'南昌师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2684', N'UniversityInfo', N'U2679', N'南昌市业余大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2685', N'UniversityInfo', N'U2680', N'南昌市职工科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2686', N'UniversityInfo', N'U2681', N'萍乡高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2687', N'UniversityInfo', N'U2682', N'上饶职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2688', N'UniversityInfo', N'U2683', N'新余钢铁有限责任公司职工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2689', N'UniversityInfo', N'U2684', N'新余高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2690', N'UniversityInfo', N'U2685', N'宜春职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2691', N'UniversityInfo', N'U2686', N'鹰潭职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2692', N'UniversityInfo', N'U2687', N'江西应用工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2693', N'UniversityInfo', N'U2688', N'江西农业大学南昌商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2694', N'UniversityInfo', N'U2689', N'江西师范大学科学技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2695', N'UniversityInfo', N'U2690', N'华东交通大学理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2696', N'UniversityInfo', N'U2691', N'江西理工大学应用科学学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2697', N'UniversityInfo', N'U2692', N'东华理工大学长江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2698', N'UniversityInfo', N'U2693', N'南昌航空大学科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2699', N'UniversityInfo', N'U2694', N'江西中医学院科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2700', N'UniversityInfo', N'U2695', N'江西财经大学现代经济管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2701', N'UniversityInfo', N'U2696', N'赣南师范学院科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2702', N'UniversityInfo', N'U2697', N'景德镇陶瓷学院科技艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2703', N'UniversityInfo', N'U2698', N'江西科技师范学院理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2704', N'UniversityInfo', N'U2699', N'南昌大学共青学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2705', N'UniversityInfo', N'U2700', N'南昌大学科学技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2706', N'UniversityInfo', N'U2701', N'华南理工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2707', N'UniversityInfo', N'U2702', N'中山大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2708', N'UniversityInfo', N'U2703', N'暨南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2709', N'UniversityInfo', N'U2704', N'华南师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2710', N'UniversityInfo', N'U2705', N'广东工业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2711', N'UniversityInfo', N'U2706', N'华南农业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2712', N'UniversityInfo', N'U2707', N'广州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2713', N'UniversityInfo', N'U2708', N'广东外语外贸大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2714', N'UniversityInfo', N'U2709', N'广州中医药大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2715', N'UniversityInfo', N'U2710', N'南方医科大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2716', N'UniversityInfo', N'U2711', N'仲恺农业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2717', N'UniversityInfo', N'U2712', N'广州医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2718', N'UniversityInfo', N'U2713', N'广东药学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2719', N'UniversityInfo', N'U2714', N'广东金融学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2720', N'UniversityInfo', N'U2715', N'广东商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2721', N'UniversityInfo', N'U2716', N'广东警官学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2722', N'UniversityInfo', N'U2717', N'广州体育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2723', N'UniversityInfo', N'U2718', N'广州美术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2724', N'UniversityInfo', N'U2719', N'星海音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2725', N'UniversityInfo', N'U2720', N'广东技术师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2726', N'UniversityInfo', N'U2721', N'广东培正学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2727', N'UniversityInfo', N'U2722', N'广东白云学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2728', N'UniversityInfo', N'U2723', N'深圳大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2729', N'UniversityInfo', N'U2724', N'汕头大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2730', N'UniversityInfo', N'U2725', N'五邑大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2731', N'UniversityInfo', N'U2726', N'肇庆学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2732', N'UniversityInfo', N'U2727', N'茂名学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2733', N'UniversityInfo', N'U2728', N'东莞理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2734', N'UniversityInfo', N'U2729', N'广东医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2735', N'UniversityInfo', N'U2730', N'湛江师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2736', N'UniversityInfo', N'U2731', N'广东海洋', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2737', N'UniversityInfo', N'U2732', N'韶关学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2738', N'UniversityInfo', N'U2733', N'韩山师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2739', N'UniversityInfo', N'U2734', N'嘉应学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2740', N'UniversityInfo', N'U2735', N'惠州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2741', N'UniversityInfo', N'U2736', N'佛山科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2742', N'UniversityInfo', N'U2737', N'中山大学南方学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2743', N'UniversityInfo', N'U2738', N'广东外语外贸大学南国商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2744', N'UniversityInfo', N'U2739', N'华南理工大学广州汽车学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2745', N'UniversityInfo', N'U2740', N'北京理工大学珠海学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2746', N'UniversityInfo', N'U2741', N'北京师范大学珠海分校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2747', N'UniversityInfo', N'U2742', N'电子科技大学中山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2748', N'UniversityInfo', N'U2743', N'东莞理工学院城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2749', N'UniversityInfo', N'U2744', N'东莞南博职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2750', N'UniversityInfo', N'U2745', N'番禺职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2751', N'UniversityInfo', N'U2746', N'佛山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2752', N'UniversityInfo', N'U2747', N'广东财经职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2753', N'UniversityInfo', N'U2748', N'广东潮��职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2754', N'UniversityInfo', N'U2749', N'广东纺织职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2755', N'UniversityInfo', N'U2750', N'广东工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2756', N'UniversityInfo', N'U2751', N'广东工贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2757', N'UniversityInfo', N'U2752', N'广东工业大学华立学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2758', N'UniversityInfo', N'U2753', N'广东海洋大学寸金学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2759', N'UniversityInfo', N'U2754', N'广东海洋大学海滨学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2760', N'UniversityInfo', N'U2755', N'广东化工制药职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2761', N'UniversityInfo', N'U2756', N'广东机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2762', N'UniversityInfo', N'U2757', N'广东技术师范学院北校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2763', N'UniversityInfo', N'U2758', N'广东建华职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2764', N'UniversityInfo', N'U2759', N'广东建设职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2765', N'UniversityInfo', N'U2760', N'广东交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2766', N'UniversityInfo', N'U2761', N'广东教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2767', N'UniversityInfo', N'U2762', N'广东科学技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2768', N'UniversityInfo', N'U2763', N'广东理工职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2769', N'UniversityInfo', N'U2764', N'广东岭南职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2770', N'UniversityInfo', N'U2765', N'广东农工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2771', N'UniversityInfo', N'U2766', N'广东女子职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2772', N'UniversityInfo', N'U2767', N'广东轻工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2773', N'UniversityInfo', N'U2768', N'广东省新闻出版技师学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2774', N'UniversityInfo', N'U2769', N'广东水利电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2775', N'UniversityInfo', N'U2770', N'广东司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2776', N'UniversityInfo', N'U2771', N'广东松山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2777', N'UniversityInfo', N'U2772', N'广东体育职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2778', N'UniversityInfo', N'U2773', N'广东外语外贸大学公开学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2779', N'UniversityInfo', N'U2774', N'广东外语艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2780', N'UniversityInfo', N'U2775', N'广东文艺职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2781', N'UniversityInfo', N'U2776', N'广东新安职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2782', N'UniversityInfo', N'U2777', N'广东行政职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2783', N'UniversityInfo', N'U2778', N'广东亚视演艺职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2784', N'UniversityInfo', N'U2779', N'广东邮电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2785', N'UniversityInfo', N'U2780', N'广州城市职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2786', N'UniversityInfo', N'U2781', N'广州大学城建学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2787', N'UniversityInfo', N'U2782', N'广州大学华软软件学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2788', N'UniversityInfo', N'U2783', N'广州大学市政技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2789', N'UniversityInfo', N'U2784', N'广州大学松田学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2790', N'UniversityInfo', N'U2785', N'广州工程技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2791', N'UniversityInfo', N'U2786', N'广州工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2792', N'UniversityInfo', N'U2787', N'广州航海高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2793', N'UniversityInfo', N'U2788', N'广州华立科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2794', N'UniversityInfo', N'U2789', N'广州华南商贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2795', N'UniversityInfo', N'U2790', N'广州康大职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2796', N'UniversityInfo', N'U2791', N'广州科技贸易职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2797', N'UniversityInfo', N'U2792', N'广州科技职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2798', N'UniversityInfo', N'U2793', N'广州民航职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2799', N'UniversityInfo', N'U2794', N'广州南洋理工职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2800', N'UniversityInfo', N'U2795', N'广州涉外经济职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2801', N'UniversityInfo', N'U2796', N'广州体育职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2802', N'UniversityInfo', N'U2797', N'广州铁路职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2803', N'UniversityInfo', N'U2798', N'广州现代信息工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2804', N'UniversityInfo', N'U2799', N'河源职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2805', N'UniversityInfo', N'U2800', N'华澳国际会计学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2806', N'UniversityInfo', N'U2801', N'华南农业大学珠江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2807', N'UniversityInfo', N'U2802', N'华南师范大学增城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2808', N'UniversityInfo', N'U2803', N'惠州经济职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2809', N'UniversityInfo', N'U2804', N'吉林大学珠海学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2810', N'UniversityInfo', N'U2805', N'江门职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2811', N'UniversityInfo', N'U2806', N'揭阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2812', N'UniversityInfo', N'U2807', N'罗定职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2813', N'UniversityInfo', N'U2808', N'茂名职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2814', N'UniversityInfo', N'U2809', N'南华工商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2815', N'UniversityInfo', N'U2810', N'南海东软信息技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2816', N'UniversityInfo', N'U2811', N'清远职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2817', N'UniversityInfo', N'U2812', N'汕头职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2818', N'UniversityInfo', N'U2813', N'汕尾职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2819', N'UniversityInfo', N'U2814', N'深圳信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2820', N'UniversityInfo', N'U2815', N'深圳振西科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2821', N'UniversityInfo', N'U2816', N'深圳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2822', N'UniversityInfo', N'U2817', N'顺德职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2823', N'UniversityInfo', N'U2818', N'私立华联学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2824', N'UniversityInfo', N'U2819', N'阳江职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2825', N'UniversityInfo', N'U2820', N'湛江技师学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2826', N'UniversityInfo', N'U2821', N'湛江教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2827', N'UniversityInfo', N'U2822', N'湛师基础教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2828', N'UniversityInfo', N'U2823', N'肇庆工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2829', N'UniversityInfo', N'U2824', N'肇庆科技职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2830', N'UniversityInfo', N'U2825', N'肇庆医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2831', N'UniversityInfo', N'U2826', N'中山火炬职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2832', N'UniversityInfo', N'U2827', N'珠海城市职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2833', N'UniversityInfo', N'U2828', N'珠海艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2834', N'UniversityInfo', N'U2829', N'遵义医学院珠海校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2835', N'UniversityInfo', N'U2830', N'广东技术师范天河分院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2836', N'UniversityInfo', N'U2831', N'广东科学技术职业学院国防工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2837', N'UniversityInfo', N'U2832', N'茂名广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2838', N'UniversityInfo', N'U2833', N'广东石油化工职业技术学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2839', N'UniversityInfo', N'U2834', N'中山大学新华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2840', N'UniversityInfo', N'U2835', N'广东商学院华商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2841', N'UniversityInfo', N'U2836', N'南开大学深圳金融工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2842', N'UniversityInfo', N'U2837', N'北京师范大学－香港浸会大学联合国际学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2843', N'UniversityInfo', N'U2838', N'广州金桥管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2844', N'UniversityInfo', N'U2839', N'广州大学纺织服装学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2845', N'UniversityInfo', N'U2840', N'华南师范大学南海校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2846', N'UniversityInfo', N'U2841', N'暨南大学深圳旅游学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2847', N'UniversityInfo', N'U2842', N'暨南大学珠海学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2848', N'UniversityInfo', N'U2843', N'广西大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2849', N'UniversityInfo', N'U2844', N'广西医科大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2850', N'UniversityInfo', N'U2845', N'广西民族大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2851', N'UniversityInfo', N'U2846', N'广西中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2852', N'UniversityInfo', N'U2847', N'广西师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2853', N'UniversityInfo', N'U2848', N'广西财经学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2854', N'UniversityInfo', N'U2849', N'广西艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2855', N'UniversityInfo', N'U2850', N'桂林电子科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2856', N'UniversityInfo', N'U2851', N'广西师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2857', N'UniversityInfo', N'U2852', N'桂林工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2858', N'UniversityInfo', N'U2853', N'桂林医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2859', N'UniversityInfo', N'U2854', N'广西工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2860', N'UniversityInfo', N'U2855', N'右江民族医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2861', N'UniversityInfo', N'U2856', N'百色学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2862', N'UniversityInfo', N'U2857', N'河池学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2863', N'UniversityInfo', N'U2858', N'玉林师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2864', N'UniversityInfo', N'U2859', N'钦州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2865', N'UniversityInfo', N'U2860', N'贺州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2866', N'UniversityInfo', N'U2861', N'梧州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2867', N'UniversityInfo', N'U2862', N'广西大学行健文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2868', N'UniversityInfo', N'U2863', N'广西师范大学漓江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2869', N'UniversityInfo', N'U2864', N'桂林电子科技大学信息科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2870', N'UniversityInfo', N'U2865', N'桂林工学院博文管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2871', N'UniversityInfo', N'U2866', N'广西工学院鹿山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2872', N'UniversityInfo', N'U2867', N'广西师范学院师园学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2873', N'UniversityInfo', N'U2868', N'广西民族大学相思湖学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2874', N'UniversityInfo', N'U2869', N'广西中医学院赛恩斯新医药学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2875', N'UniversityInfo', N'U2870', N'北海宏源足球职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2876', N'UniversityInfo', N'U2871', N'北海艺术设计职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2877', N'UniversityInfo', N'U2872', N'北海职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2878', N'UniversityInfo', N'U2873', N'广西城市职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2879', N'UniversityInfo', N'U2874', N'广西电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2880', N'UniversityInfo', N'U2875', N'广西东方外语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2881', N'UniversityInfo', N'U2876', N'广西工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2882', N'UniversityInfo', N'U2877', N'广西工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2883', N'UniversityInfo', N'U2878', N'广西国际商务职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2884', N'UniversityInfo', N'U2879', N'广西机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2885', N'UniversityInfo', N'U2880', N'广西建设职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2886', N'UniversityInfo', N'U2881', N'广西交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2887', N'UniversityInfo', N'U2882', N'广西经济管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2888', N'UniversityInfo', N'U2883', N'广西经贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2889', N'UniversityInfo', N'U2884', N'广西警管高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2890', N'UniversityInfo', N'U2885', N'广西农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2891', N'UniversityInfo', N'U2886', N'广西轻工高级技工学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2892', N'UniversityInfo', N'U2887', N'广西生态工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2893', N'UniversityInfo', N'U2888', N'广西水利电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2894', N'UniversityInfo', N'U2889', N'广西体育高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2895', N'UniversityInfo', N'U2890', N'广西演艺职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2896', N'UniversityInfo', N'U2891', N'广西英华国际职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2897', N'UniversityInfo', N'U2892', N'广西邕江大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2898', N'UniversityInfo', N'U2893', N'广西幼儿师范学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2899', N'UniversityInfo', N'U2894', N'广西职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2900', N'UniversityInfo', N'U2895', N'贵港职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2901', N'UniversityInfo', N'U2896', N'桂林航天工业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2902', N'UniversityInfo', N'U2897', N'桂林旅游高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2903', N'UniversityInfo', N'U2898', N'桂林山水职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2904', N'UniversityInfo', N'U2899', N'桂林师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2905', N'UniversityInfo', N'U2900', N'河池职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2906', N'UniversityInfo', N'U2901', N'柳州师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2907', N'UniversityInfo', N'U2902', N'柳州医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2908', N'UniversityInfo', N'U2903', N'柳州运输职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2909', N'UniversityInfo', N'U2904', N'柳州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2910', N'UniversityInfo', N'U2905', N'南宁师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2911', N'UniversityInfo', N'U2906', N'南宁职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2912', N'UniversityInfo', N'U2907', N'南宁地区教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2913', N'UniversityInfo', N'U2908', N'北京航空航天大学北海学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2914', N'UniversityInfo', N'U2909', N'桂林工学院南宁分院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2915', N'UniversityInfo', N'U2910', N'百色职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2916', N'UniversityInfo', N'U2911', N'昆明理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2917', N'UniversityInfo', N'U2912', N'云南农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2918', N'UniversityInfo', N'U2913', N'云南师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2919', N'UniversityInfo', N'U2914', N'云南财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2920', N'UniversityInfo', N'U2915', N'云南民大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2921', N'UniversityInfo', N'U2916', N'西南林学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2922', N'UniversityInfo', N'U2917', N'昆明医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2923', N'UniversityInfo', N'U2918', N'云南中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2924', N'UniversityInfo', N'U2919', N'红河学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2925', N'UniversityInfo', N'U2920', N'云南警官学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2926', N'UniversityInfo', N'U2921', N'云南艺术', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2927', N'UniversityInfo', N'U2922', N'云南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2928', N'UniversityInfo', N'U2923', N'曲靖师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2929', N'UniversityInfo', N'U2924', N'玉溪师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2930', N'UniversityInfo', N'U2925', N'楚雄师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2931', N'UniversityInfo', N'U2926', N'大理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2932', N'UniversityInfo', N'U2927', N'保山师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2933', N'UniversityInfo', N'U2928', N'保山中医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2934', N'UniversityInfo', N'U2929', N'楚雄医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2935', N'UniversityInfo', N'U2930', N'德宏师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2936', N'UniversityInfo', N'U2931', N'云南大学滇池学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2937', N'UniversityInfo', N'U2932', N'昆明大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2938', N'UniversityInfo', N'U2933', N'昆明工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2939', N'UniversityInfo', N'U2934', N'昆明师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2940', N'UniversityInfo', N'U2935', N'昆明扬帆职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2941', N'UniversityInfo', N'U2936', N'昆明冶金高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2942', N'UniversityInfo', N'U2937', N'昆明艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2943', N'UniversityInfo', N'U2938', N'丽江师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2944', N'UniversityInfo', N'U2939', N'曲靖医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2945', N'UniversityInfo', N'U2940', N'思茅师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2946', N'UniversityInfo', N'U2941', N'文山师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2947', N'UniversityInfo', N'U2942', N'西双版纳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2948', N'UniversityInfo', N'U2943', N'玉溪农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2949', N'UniversityInfo', N'U2944', N'云南爱因森软件职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2950', N'UniversityInfo', N'U2945', N'云南北美职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2951', N'UniversityInfo', N'U2946', N'云南广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2952', N'UniversityInfo', N'U2947', N'云南国防工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2953', N'UniversityInfo', N'U2948', N'云南国土资源职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2954', N'UniversityInfo', N'U2949', N'云南机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2955', N'UniversityInfo', N'U2950', N'云南交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2956', N'UniversityInfo', N'U2951', N'云南经济管理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2957', N'UniversityInfo', N'U2952', N'云南科技信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2958', N'UniversityInfo', N'U2953', N'云南林业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2959', N'UniversityInfo', N'U2954', N'云南能源职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2960', N'UniversityInfo', N'U2955', N'云南农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2961', N'UniversityInfo', N'U2956', N'云南热带作物职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2962', N'UniversityInfo', N'U2957', N'云南省林业科学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2963', N'UniversityInfo', N'U2958', N'云南师范大学商学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2964', N'UniversityInfo', N'U2959', N'云南司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2965', N'UniversityInfo', N'U2960', N'云南体育运动职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2966', N'UniversityInfo', N'U2961', N'云南文化艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2967', N'UniversityInfo', N'U2962', N'云南新兴职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2968', N'UniversityInfo', N'U2963', N'云南医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2969', N'UniversityInfo', N'U2964', N'云南昭通师范专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2970', N'UniversityInfo', N'U2965', N'昭通师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2971', N'UniversityInfo', N'U2966', N'昆明学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2972', N'UniversityInfo', N'U2967', N'昆明理工大学津桥学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2973', N'UniversityInfo', N'U2968', N'云南师范大学文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2974', N'UniversityInfo', N'U2969', N'昆明医学院海源学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2975', N'UniversityInfo', N'U2970', N'云南艺术学院文华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2976', N'UniversityInfo', N'U2971', N'云南大学旅游文化学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2977', N'UniversityInfo', N'U2972', N'临沧师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2978', N'UniversityInfo', N'U2973', N'贵州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2979', N'UniversityInfo', N'U2974', N'贵阳医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2980', N'UniversityInfo', N'U2975', N'贵阳中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2981', N'UniversityInfo', N'U2976', N'贵州财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2982', N'UniversityInfo', N'U2977', N'贵州民族', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2983', N'UniversityInfo', N'U2978', N'贵阳学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2984', N'UniversityInfo', N'U2979', N'贵州师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2985', N'UniversityInfo', N'U2980', N'铜仁学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2986', N'UniversityInfo', N'U2981', N'遵义医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2987', N'UniversityInfo', N'U2982', N'遵义师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2988', N'UniversityInfo', N'U2983', N'毕节学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2989', N'UniversityInfo', N'U2984', N'黔南师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2990', N'UniversityInfo', N'U2985', N'安顺学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2991', N'UniversityInfo', N'U2986', N'凯里学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2992', N'UniversityInfo', N'U2987', N'安顺职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2993', N'UniversityInfo', N'U2988', N'贵州电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2994', N'UniversityInfo', N'U2989', N'贵州电子信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2995', N'UniversityInfo', N'U2990', N'贵州航天职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2996', N'UniversityInfo', N'U2991', N'贵州鸿源管理工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2997', N'UniversityInfo', N'U2992', N'贵州交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2998', N'UniversityInfo', N'U2993', N'贵州警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'2999', N'UniversityInfo', N'U2994', N'贵州科技工程职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3000', N'UniversityInfo', N'U2995', N'贵州理工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3001', N'UniversityInfo', N'U2996', N'贵州轻工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3002', N'UniversityInfo', N'U2997', N'贵州商业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3003', N'UniversityInfo', N'U2998', N'六盘水师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3004', N'UniversityInfo', N'U2999', N'六盘水职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3005', N'UniversityInfo', N'U3000', N'黔东南民族职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3006', N'UniversityInfo', N'U3001', N'黔南民族医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3007', N'UniversityInfo', N'U3002', N'黔南民族职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3008', N'UniversityInfo', N'U3003', N'黔西南民族师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3009', N'UniversityInfo', N'U3004', N'黔西南民族职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3010', N'UniversityInfo', N'U3005', N'铜仁职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3011', N'UniversityInfo', N'U3006', N'遵义医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3012', N'UniversityInfo', N'U3007', N'遵义职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3013', N'UniversityInfo', N'U3008', N'贵州财经学院商务学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3014', N'UniversityInfo', N'U3009', N'贵州民族学院人文科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3015', N'UniversityInfo', N'U3010', N'贵州师范大学求是学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3016', N'UniversityInfo', N'U3011', N'贵阳医学院神奇民族医药学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3017', N'UniversityInfo', N'U3012', N'遵义医学院医学与科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3018', N'UniversityInfo', N'U3013', N'贵阳中医学院时珍学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3019', N'UniversityInfo', N'U3014', N'贵州大学明德学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3020', N'UniversityInfo', N'U3015', N'贵州大学科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3021', N'UniversityInfo', N'U3016', N'贵阳护理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3022', N'UniversityInfo', N'U3017', N'贵州亚泰职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3023', N'UniversityInfo', N'U3018', N'贵州教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3024', N'UniversityInfo', N'U3019', N'四川大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3025', N'UniversityInfo', N'U3020', N'四川农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3026', N'UniversityInfo', N'U3021', N'电子科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3027', N'UniversityInfo', N'U3022', N'西南交大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3028', N'UniversityInfo', N'U3023', N'成都理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3029', N'UniversityInfo', N'U3024', N'四川师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3030', N'UniversityInfo', N'U3025', N'西南民族大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3031', N'UniversityInfo', N'U3026', N'成都大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3032', N'UniversityInfo', N'U3027', N'西南财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3033', N'UniversityInfo', N'U3028', N'西华大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3034', N'UniversityInfo', N'U3029', N'成都中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3035', N'UniversityInfo', N'U3030', N'成都信息工程大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3036', N'UniversityInfo', N'U3031', N'成都医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3037', N'UniversityInfo', N'U3032', N'四川文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3038', N'UniversityInfo', N'U3033', N'成都体院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3039', N'UniversityInfo', N'U3034', N'四川音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3040', N'UniversityInfo', N'U3035', N'西南石油', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3041', N'UniversityInfo', N'U3036', N'中国民航飞行学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3042', N'UniversityInfo', N'U3037', N'四川理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3043', N'UniversityInfo', N'U3038', N'泸州医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3044', N'UniversityInfo', N'U3039', N'四川警察学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3045', N'UniversityInfo', N'U3040', N'川北医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3046', N'UniversityInfo', N'U3041', N'西华师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3047', N'UniversityInfo', N'U3042', N'内江师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3048', N'UniversityInfo', N'U3043', N'乐山师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3049', N'UniversityInfo', N'U3044', N'绵阳师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3050', N'UniversityInfo', N'U3045', N'西南科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3051', N'UniversityInfo', N'U3046', N'西昌学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3052', N'UniversityInfo', N'U3047', N'宜宾学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3053', N'UniversityInfo', N'U3048', N'攀枝花学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3054', N'UniversityInfo', N'U3049', N'阿坝师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3055', N'UniversityInfo', N'U3050', N'成都电子机械高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3056', N'UniversityInfo', N'U3051', N'成都东软信息技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3057', N'UniversityInfo', N'U3052', N'成都纺织高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3058', N'UniversityInfo', N'U3053', N'成都广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3059', N'UniversityInfo', N'U3054', N'成都航空职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3060', N'UniversityInfo', N'U3055', N'成都理工大学广播影视学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3061', N'UniversityInfo', N'U3056', N'成都农业科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3062', N'UniversityInfo', N'U3057', N'成都艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3063', N'UniversityInfo', N'U3058', N'成都职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3064', N'UniversityInfo', N'U3059', N'达州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3065', N'UniversityInfo', N'U3060', N'电子科技大学成都学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3066', N'UniversityInfo', N'U3061', N'广安职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3067', N'UniversityInfo', N'U3062', N'康定民族师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3068', N'UniversityInfo', N'U3063', N'乐山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3069', N'UniversityInfo', N'U3064', N'泸州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3070', N'UniversityInfo', N'U3065', N'眉山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3071', N'UniversityInfo', N'U3066', N'绵阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3072', N'UniversityInfo', N'U3067', N'民办四川天一学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3073', N'UniversityInfo', N'U3068', N'内江职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3074', N'UniversityInfo', N'U3069', N'南充职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3075', N'UniversityInfo', N'U3070', N'四川大学龙泉校区', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3076', N'UniversityInfo', N'U3071', N'四川电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3077', N'UniversityInfo', N'U3072', N'四川工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3078', N'UniversityInfo', N'U3073', N'四川工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3079', N'UniversityInfo', N'U3074', N'四川管理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3080', N'UniversityInfo', N'U3075', N'四川广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3081', N'UniversityInfo', N'U3076', N'四川国际标榜职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3082', N'UniversityInfo', N'U3077', N'四川航天职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3083', N'UniversityInfo', N'U3078', N'四川华新现代职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3084', N'UniversityInfo', N'U3079', N'四川化工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3085', N'UniversityInfo', N'U3080', N'四川机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3086', N'UniversityInfo', N'U3081', N'四川建筑职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3087', N'UniversityInfo', N'U3082', N'四川交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3088', N'UniversityInfo', N'U3083', N'四川教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3089', N'UniversityInfo', N'U3084', N'四川警安职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3090', N'UniversityInfo', N'U3085', N'四川烹饪高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3091', N'UniversityInfo', N'U3086', N'四川商务职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3092', N'UniversityInfo', N'U3087', N'四川师范大学绵阳初等教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3093', N'UniversityInfo', N'U3088', N'四川水利职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3094', N'UniversityInfo', N'U3089', N'四川司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3095', N'UniversityInfo', N'U3090', N'四川托普信息技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3096', N'UniversityInfo', N'U3091', N'四川外语学院成都学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3097', N'UniversityInfo', N'U3092', N'四川文化传媒职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3098', N'UniversityInfo', N'U3093', N'四川信息工程学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3099', N'UniversityInfo', N'U3094', N'四川邮电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3100', N'UniversityInfo', N'U3095', N'四川职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3101', N'UniversityInfo', N'U3096', N'四川中医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3102', N'UniversityInfo', N'U3097', N'雅安职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3103', N'UniversityInfo', N'U3098', N'宜宾职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3104', N'UniversityInfo', N'U3099', N'四川大学锦城学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3105', N'UniversityInfo', N'U3100', N'四川大学锦江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3106', N'UniversityInfo', N'U3101', N'德阳职业技术学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3107', N'UniversityInfo', N'U3102', N'四川信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3108', N'UniversityInfo', N'U3103', N'四川艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3109', N'UniversityInfo', N'U3104', N'四川师范大学成都学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3110', N'UniversityInfo', N'U3105', N'四川师范大学文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3111', N'UniversityInfo', N'U3106', N'成都信息工程学院银杏酒店管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3112', N'UniversityInfo', N'U3107', N'成都理工大学工程技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3113', N'UniversityInfo', N'U3108', N'四川文化产业职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3114', N'UniversityInfo', N'U3109', N'四川科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3115', N'UniversityInfo', N'U3110', N'西南科技大学城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3116', N'UniversityInfo', N'U3111', N'四川音乐学院绵阳艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3117', N'UniversityInfo', N'U3112', N'西南财经大学天府学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3118', N'UniversityInfo', N'U3113', N'内蒙古大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3119', N'UniversityInfo', N'U3114', N'内蒙古工业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3120', N'UniversityInfo', N'U3115', N'内蒙古农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3121', N'UniversityInfo', N'U3116', N'内蒙古师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3122', N'UniversityInfo', N'U3117', N'内蒙古医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3123', N'UniversityInfo', N'U3118', N'内蒙古财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3124', N'UniversityInfo', N'U3119', N'内蒙古科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3125', N'UniversityInfo', N'U3120', N'内蒙古民族大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3126', N'UniversityInfo', N'U3121', N'赤峰学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3127', N'UniversityInfo', N'U3122', N'呼伦贝尔学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3128', N'UniversityInfo', N'U3123', N'包头钢铁职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3129', N'UniversityInfo', N'U3124', N'包头轻工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3130', N'UniversityInfo', N'U3125', N'包头职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3131', N'UniversityInfo', N'U3126', N'河套大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3132', N'UniversityInfo', N'U3127', N'呼和浩特职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3133', N'UniversityInfo', N'U3128', N'集宁师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3134', N'UniversityInfo', N'U3129', N'科尔沁艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3135', N'UniversityInfo', N'U3130', N'内蒙古财税职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3136', N'UniversityInfo', N'U3131', N'内蒙古电子信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3137', N'UniversityInfo', N'U3132', N'内蒙古青城大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3138', N'UniversityInfo', N'U3133', N'内蒙古化工职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3139', N'UniversityInfo', N'U3134', N'内蒙古机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3140', N'UniversityInfo', N'U3135', N'内蒙古建筑职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3141', N'UniversityInfo', N'U3136', N'内蒙古交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3142', N'UniversityInfo', N'U3137', N'内蒙古民族高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3143', N'UniversityInfo', N'U3138', N'内蒙古商贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3144', N'UniversityInfo', N'U3139', N'内蒙古体育职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3145', N'UniversityInfo', N'U3140', N'通辽职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3146', N'UniversityInfo', N'U3141', N'乌海职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3147', N'UniversityInfo', N'U3142', N'乌兰察布职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3148', N'UniversityInfo', N'U3143', N'锡林郭勒职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3149', N'UniversityInfo', N'U3144', N'兴安职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3150', N'UniversityInfo', N'U3145', N'内蒙古警察职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3151', N'UniversityInfo', N'U3146', N'内蒙古北方职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3152', N'UniversityInfo', N'U3147', N'内蒙古丰州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3153', N'UniversityInfo', N'U3148', N'内蒙古经贸外语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3154', N'UniversityInfo', N'U3149', N'内蒙古科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3155', N'UniversityInfo', N'U3150', N'赤峰职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3156', N'UniversityInfo', N'U3151', N'宁夏大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3157', N'UniversityInfo', N'U3152', N'北方民大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3158', N'UniversityInfo', N'U3153', N'宁夏医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3159', N'UniversityInfo', N'U3154', N'宁夏理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3160', N'UniversityInfo', N'U3155', N'宁夏师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3161', N'UniversityInfo', N'U3156', N'吴忠职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3162', N'UniversityInfo', N'U3157', N'宁夏职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3163', N'UniversityInfo', N'U3158', N'宁夏财经职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3164', N'UniversityInfo', N'U3159', N'宁夏司法警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3165', N'UniversityInfo', N'U3160', N'宁夏师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3166', N'UniversityInfo', N'U3161', N'宁夏工业职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3167', N'UniversityInfo', N'U3162', N'宁夏经贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3168', N'UniversityInfo', N'U3163', N'宁夏建设职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3169', N'UniversityInfo', N'U3164', N'银川科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3170', N'UniversityInfo', N'U3165', N'宁夏大学新华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3171', N'UniversityInfo', N'U3166', N'兰州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3172', N'UniversityInfo', N'U3167', N'西北民大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3173', N'UniversityInfo', N'U3168', N'西北师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3174', N'UniversityInfo', N'U3169', N'甘肃中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3175', N'UniversityInfo', N'U3170', N'兰州商院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3176', N'UniversityInfo', N'U3171', N'甘肃政法学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3177', N'UniversityInfo', N'U3172', N'兰州城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3178', N'UniversityInfo', N'U3173', N'甘肃农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3179', N'UniversityInfo', N'U3174', N'兰州理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3180', N'UniversityInfo', N'U3175', N'兰州交大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3181', N'UniversityInfo', N'U3176', N'天水师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3182', N'UniversityInfo', N'U3177', N'陇东学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3183', N'UniversityInfo', N'U3178', N'河西学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3184', N'UniversityInfo', N'U3179', N'兰州石化职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3185', N'UniversityInfo', N'U3180', N'甘肃工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3186', N'UniversityInfo', N'U3181', N'甘肃警察职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3187', N'UniversityInfo', N'U3182', N'兰州理工大学技术工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3188', N'UniversityInfo', N'U3183', N'兰州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3189', N'UniversityInfo', N'U3184', N'武威职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3190', N'UniversityInfo', N'U3185', N'张掖医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3191', N'UniversityInfo', N'U3186', N'甘肃畜牧工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3192', N'UniversityInfo', N'U3187', N'陇南师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3193', N'UniversityInfo', N'U3188', N'合作民族师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3194', N'UniversityInfo', N'U3189', N'甘肃联合大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3195', N'UniversityInfo', N'U3190', N'甘肃林业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3196', N'UniversityInfo', N'U3191', N'甘肃建筑职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3197', N'UniversityInfo', N'U3192', N'酒泉职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3198', N'UniversityInfo', N'U3193', N'甘肃农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3199', N'UniversityInfo', N'U3194', N'平凉医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3200', N'UniversityInfo', N'U3195', N'兰州资源环境职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3201', N'UniversityInfo', N'U3196', N'定西师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3202', N'UniversityInfo', N'U3197', N'兰州交通大学博文学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3203', N'UniversityInfo', N'U3198', N'兰州工业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3204', N'UniversityInfo', N'U3199', N'兰州外语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3205', N'UniversityInfo', N'U3200', N'兰州教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3206', N'UniversityInfo', N'U3201', N'甘肃钢铁职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3207', N'UniversityInfo', N'U3202', N'青海大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3208', N'UniversityInfo', N'U3203', N'青海师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3209', N'UniversityInfo', N'U3204', N'青海民院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3210', N'UniversityInfo', N'U3205', N'青海民族师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3211', N'UniversityInfo', N'U3206', N'青海财经职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3212', N'UniversityInfo', N'U3207', N'青海畜牧兽医职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3213', N'UniversityInfo', N'U3208', N'青海建筑职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3214', N'UniversityInfo', N'U3209', N'青海师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3215', N'UniversityInfo', N'U3210', N'青海警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3216', N'UniversityInfo', N'U3211', N'青海交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3217', N'UniversityInfo', N'U3212', N'青海卫生职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3218', N'UniversityInfo', N'U3213', N'西藏大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3219', N'UniversityInfo', N'U3214', N'西藏藏医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3220', N'UniversityInfo', N'U3215', N'西藏民院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3221', N'UniversityInfo', N'U3216', N'拉萨师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3222', N'UniversityInfo', N'U3217', N'西藏警官高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3223', N'UniversityInfo', N'U3218', N'西藏职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3224', N'UniversityInfo', N'U3219', N'新疆大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3225', N'UniversityInfo', N'U3220', N'新疆农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3226', N'UniversityInfo', N'U3221', N'新疆医科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3227', N'UniversityInfo', N'U3222', N'新疆师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3228', N'UniversityInfo', N'U3223', N'新疆财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3229', N'UniversityInfo', N'U3224', N'新疆艺术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3230', N'UniversityInfo', N'U3225', N'石河子大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3231', N'UniversityInfo', N'U3226', N'塔里木大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3232', N'UniversityInfo', N'U3227', N'喀什师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3233', N'UniversityInfo', N'U3228', N'伊犁师院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3234', N'UniversityInfo', N'U3229', N'昌吉学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3235', N'UniversityInfo', N'U3230', N'阿克苏职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3236', N'UniversityInfo', N'U3231', N'巴音郭楞职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3237', N'UniversityInfo', N'U3232', N'昌吉职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3238', N'UniversityInfo', N'U3233', N'和田师范专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3239', N'UniversityInfo', N'U3234', N'克拉玛依职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3240', N'UniversityInfo', N'U3235', N'乌鲁木齐职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3241', N'UniversityInfo', N'U3236', N'新疆兵团警官高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3242', N'UniversityInfo', N'U3237', N'新疆工业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3243', N'UniversityInfo', N'U3238', N'新疆机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3244', N'UniversityInfo', N'U3239', N'新疆建设职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3245', N'UniversityInfo', N'U3240', N'新疆交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3246', N'UniversityInfo', N'U3241', N'新疆警官高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3247', N'UniversityInfo', N'U3242', N'新疆能源职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3248', N'UniversityInfo', N'U3243', N'新疆农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3249', N'UniversityInfo', N'U3244', N'新疆轻工职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3250', N'UniversityInfo', N'U3245', N'新疆石河子职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3251', N'UniversityInfo', N'U3246', N'新疆天山职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3252', N'UniversityInfo', N'U3247', N'新疆维吾尔医学专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3253', N'UniversityInfo', N'U3248', N'新疆现代职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3254', N'UniversityInfo', N'U3249', N'伊犁职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3255', N'UniversityInfo', N'U3250', N'新疆科信学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3256', N'UniversityInfo', N'U3251', N'新疆职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3257', N'UniversityInfo', N'U3252', N'新疆石油学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3258', N'UniversityInfo', N'U3253', N'新疆大学科学技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3259', N'UniversityInfo', N'U3254', N'新疆农业大学科学技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3260', N'UniversityInfo', N'U3255', N'新疆财经大学商务学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3261', N'UniversityInfo', N'U3256', N'新疆医科大学厚博学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3262', N'UniversityInfo', N'U3257', N'石河子大学科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3263', N'UniversityInfo', N'U3258', N'中国科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3264', N'UniversityInfo', N'U3259', N'安徽大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3265', N'UniversityInfo', N'U3260', N'合肥工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3266', N'UniversityInfo', N'U3261', N'安徽医科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3267', N'UniversityInfo', N'U3262', N'安徽建工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3268', N'UniversityInfo', N'U3263', N'安徽中医', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3269', N'UniversityInfo', N'U3264', N'合肥学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3270', N'UniversityInfo', N'U3265', N'安徽农大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3271', N'UniversityInfo', N'U3266', N'安徽工业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3272', N'UniversityInfo', N'U3267', N'安徽科技', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3273', N'UniversityInfo', N'U3268', N'皖南医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3274', N'UniversityInfo', N'U3269', N'安徽师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3275', N'UniversityInfo', N'U3270', N'安徽工程科技', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3276', N'UniversityInfo', N'U3271', N'蚌埠医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3277', N'UniversityInfo', N'U3272', N'安徽财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3278', N'UniversityInfo', N'U3273', N'阜阳师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3279', N'UniversityInfo', N'U3274', N'淮南师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3280', N'UniversityInfo', N'U3275', N'安徽理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3281', N'UniversityInfo', N'U3276', N'淮北煤炭师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3282', N'UniversityInfo', N'U3277', N'安庆师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3283', N'UniversityInfo', N'U3278', N'铜陵学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3284', N'UniversityInfo', N'U3279', N'皖西学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3285', N'UniversityInfo', N'U3280', N'巢湖学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3286', N'UniversityInfo', N'U3281', N'滁州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3287', N'UniversityInfo', N'U3282', N'宿州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3288', N'UniversityInfo', N'U3283', N'黄山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3289', N'UniversityInfo', N'U3284', N'新华学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3290', N'UniversityInfo', N'U3285', N'蚌埠学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3291', N'UniversityInfo', N'U3286', N'安徽财贸职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3292', N'UniversityInfo', N'U3287', N'安徽城市管理职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3293', N'UniversityInfo', N'U3288', N'安徽电气工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3294', N'UniversityInfo', N'U3289', N'安徽电子信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3295', N'UniversityInfo', N'U3290', N'安徽工贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3296', N'UniversityInfo', N'U3291', N'安徽工商职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3297', N'UniversityInfo', N'U3292', N'安徽工业经济职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3298', N'UniversityInfo', N'U3293', N'安徽公安职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3299', N'UniversityInfo', N'U3294', N'安徽广播影视职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3300', N'UniversityInfo', N'U3295', N'安徽国防科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3301', N'UniversityInfo', N'U3296', N'安徽国际商务职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3302', N'UniversityInfo', N'U3297', N'安徽机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3303', N'UniversityInfo', N'U3298', N'安徽交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3304', N'UniversityInfo', N'U3299', N'安徽教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3305', N'UniversityInfo', N'U3300', N'安徽经济管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3306', N'UniversityInfo', N'U3301', N'安徽警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3307', N'UniversityInfo', N'U3302', N'安徽林业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3308', N'UniversityInfo', N'U3303', N'安徽明星科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3309', N'UniversityInfo', N'U3304', N'安徽商贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3310', N'UniversityInfo', N'U3305', N'安徽审计职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3311', N'UniversityInfo', N'U3306', N'安徽省三联职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3312', N'UniversityInfo', N'U3307', N'安徽水利水电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3313', N'UniversityInfo', N'U3308', N'安徽体育运动职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3314', N'UniversityInfo', N'U3309', N'安徽文达信息技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3315', N'UniversityInfo', N'U3310', N'安徽新闻出版职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3316', N'UniversityInfo', N'U3311', N'安徽冶金科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3317', N'UniversityInfo', N'U3312', N'安徽医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3318', N'UniversityInfo', N'U3313', N'安徽艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3319', N'UniversityInfo', N'U3314', N'安徽邮电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3320', N'UniversityInfo', N'U3315', N'安徽职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3321', N'UniversityInfo', N'U3316', N'安徽中澳科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3322', N'UniversityInfo', N'U3317', N'安徽中医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3323', N'UniversityInfo', N'U3318', N'安庆职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3324', N'UniversityInfo', N'U3319', N'蚌埠高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3325', N'UniversityInfo', N'U3320', N'蚌埠职业教育专修学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3326', N'UniversityInfo', N'U3321', N'亳州师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3327', N'UniversityInfo', N'U3322', N'亳州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3328', N'UniversityInfo', N'U3323', N'巢湖职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3329', N'UniversityInfo', N'U3324', N'池州师范专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3330', N'UniversityInfo', N'U3325', N'池州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3331', N'UniversityInfo', N'U3326', N'滁州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3332', N'UniversityInfo', N'U3327', N'阜阳科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3333', N'UniversityInfo', N'U3328', N'阜阳职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3334', N'UniversityInfo', N'U3329', N'合肥市万博科技职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3335', N'UniversityInfo', N'U3330', N'合肥通用职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3336', N'UniversityInfo', N'U3331', N'淮北职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3337', N'UniversityInfo', N'U3332', N'淮南联合大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3338', N'UniversityInfo', N'U3333', N'淮南职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3339', N'UniversityInfo', N'U3334', N'六安职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3340', N'UniversityInfo', N'U3335', N'马鞍山师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3341', N'UniversityInfo', N'U3336', N'民办安徽外国语职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3342', N'UniversityInfo', N'U3337', N'民办合肥经济技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3343', N'UniversityInfo', N'U3338', N'宿州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3344', N'UniversityInfo', N'U3339', N'铜陵职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3345', N'UniversityInfo', N'U3340', N'芜湖信息技术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3346', N'UniversityInfo', N'U3341', N'芜湖职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3347', N'UniversityInfo', N'U3342', N'宣城职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3348', N'UniversityInfo', N'U3343', N'安徽师范大学皖江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3349', N'UniversityInfo', N'U3344', N'合肥师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3350', N'UniversityInfo', N'U3345', N'凤阳师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3351', N'UniversityInfo', N'U3346', N'安庆医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3352', N'UniversityInfo', N'U3347', N'安徽工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3353', N'UniversityInfo', N'U3348', N'合肥幼儿师范学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3354', N'UniversityInfo', N'U3349', N'浙江大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3355', N'UniversityInfo', N'U3350', N'浙江理工', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3356', N'UniversityInfo', N'U3351', N'浙江工大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3357', N'UniversityInfo', N'U3352', N'杭州电子科大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3358', N'UniversityInfo', N'U3353', N'浙江中医药', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3359', N'UniversityInfo', N'U3354', N'浙江工商', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3360', N'UniversityInfo', N'U3355', N'中国计量', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3361', N'UniversityInfo', N'U3356', N'浙江科技', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3362', N'UniversityInfo', N'U3357', N'浙江林院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3363', N'UniversityInfo', N'U3358', N'杭州师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3364', N'UniversityInfo', N'U3359', N'浙江传媒', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3365', N'UniversityInfo', N'U3360', N'浙江财经', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3366', N'UniversityInfo', N'U3361', N'中国美术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3367', N'UniversityInfo', N'U3362', N'树人大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3368', N'UniversityInfo', N'U3363', N'宁波大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3369', N'UniversityInfo', N'U3364', N'宁波工程', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3370', N'UniversityInfo', N'U3365', N'万里学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3371', N'UniversityInfo', N'U3366', N'诺丁汉大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3372', N'UniversityInfo', N'U3367', N'嘉兴学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3373', N'UniversityInfo', N'U3368', N'浙江海洋', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3374', N'UniversityInfo', N'U3369', N'温州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3375', N'UniversityInfo', N'U3370', N'温州医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3376', N'UniversityInfo', N'U3371', N'湖州师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3377', N'UniversityInfo', N'U3372', N'台州学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3378', N'UniversityInfo', N'U3373', N'绍兴文理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3379', N'UniversityInfo', N'U3374', N'丽水学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3380', N'UniversityInfo', N'U3375', N'浙江师大', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3381', N'UniversityInfo', N'U3376', N'长征职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3382', N'UniversityInfo', N'U3377', N'公安海警高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3383', N'UniversityInfo', N'U3378', N'杭州万向职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3384', N'UniversityInfo', N'U3379', N'杭州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3385', N'UniversityInfo', N'U3380', N'湖州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3386', N'UniversityInfo', N'U3381', N'嘉兴职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3387', N'UniversityInfo', N'U3382', N'金华职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3388', N'UniversityInfo', N'U3383', N'科技求是学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3389', N'UniversityInfo', N'U3384', N'丽水职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3390', N'UniversityInfo', N'U3385', N'宁波城市职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3391', N'UniversityInfo', N'U3386', N'宁波大红鹰职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3392', N'UniversityInfo', N'U3387', N'宁波大学科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3393', N'UniversityInfo', N'U3388', N'宁波天一职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3394', N'UniversityInfo', N'U3389', N'宁波职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3395', N'UniversityInfo', N'U3390', N'衢州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3396', N'UniversityInfo', N'U3391', N'绍兴托普信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3397', N'UniversityInfo', N'U3392', N'绍兴越秀外国语职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3398', N'UniversityInfo', N'U3393', N'台州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3399', N'UniversityInfo', N'U3394', N'温州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3400', N'UniversityInfo', N'U3395', N'义乌工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3401', N'UniversityInfo', N'U3396', N'浙江大学城市学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3402', N'UniversityInfo', N'U3397', N'浙江大学宁波理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3403', N'UniversityInfo', N'U3398', N'浙江东方职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3404', N'UniversityInfo', N'U3399', N'浙江纺织服装职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3405', N'UniversityInfo', N'U3400', N'浙江工贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3406', N'UniversityInfo', N'U3401', N'浙江工商职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3407', N'UniversityInfo', N'U3402', N'浙江工业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3408', N'UniversityInfo', N'U3403', N'浙江警察学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3409', N'UniversityInfo', N'U3404', N'浙江广厦建设职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3410', N'UniversityInfo', N'U3405', N'浙江机电职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3411', N'UniversityInfo', N'U3406', N'浙江建设职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3412', N'UniversityInfo', N'U3407', N'浙江交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3413', N'UniversityInfo', N'U3408', N'浙江教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3414', N'UniversityInfo', N'U3409', N'浙江金融职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3415', N'UniversityInfo', N'U3410', N'浙江经济职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3416', N'UniversityInfo', N'U3411', N'浙江经贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3417', N'UniversityInfo', N'U3412', N'浙江警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3418', N'UniversityInfo', N'U3413', N'浙江旅游职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3419', N'UniversityInfo', N'U3414', N'浙江商业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3420', N'UniversityInfo', N'U3415', N'浙江水利水电专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3421', N'UniversityInfo', N'U3416', N'浙江医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3422', N'UniversityInfo', N'U3417', N'浙江医药高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3423', N'UniversityInfo', N'U3418', N'浙江艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3424', N'UniversityInfo', N'U3419', N'浙江育英职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3425', N'UniversityInfo', N'U3420', N'浙江电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3426', N'UniversityInfo', N'U3421', N'嘉兴南洋职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3427', N'UniversityInfo', N'U3422', N'浙江国际海运职业技术学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3428', N'UniversityInfo', N'U3423', N'浙江工业大学浙西分校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3429', N'UniversityInfo', N'U3424', N'浙江国际海运职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3430', N'UniversityInfo', N'U3425', N'厦门大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3431', N'UniversityInfo', N'U3426', N'集美大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3432', N'UniversityInfo', N'U3427', N'厦门理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3433', N'UniversityInfo', N'U3428', N'福州大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3434', N'UniversityInfo', N'U3429', N'福建师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3435', N'UniversityInfo', N'U3430', N'福建农林大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3436', N'UniversityInfo', N'U3431', N'福建医科大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3437', N'UniversityInfo', N'U3432', N'福建工程学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3438', N'UniversityInfo', N'U3433', N'福建中医学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3439', N'UniversityInfo', N'U3434', N'闽江学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3440', N'UniversityInfo', N'U3435', N'华侨大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3441', N'UniversityInfo', N'U3436', N'仰恩大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3442', N'UniversityInfo', N'U3437', N'泉州师范学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3443', N'UniversityInfo', N'U3438', N'漳州师范', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3444', N'UniversityInfo', N'U3439', N'莆田学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3445', N'UniversityInfo', N'U3440', N'三明学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3446', N'UniversityInfo', N'U3441', N'龙岩学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3447', N'UniversityInfo', N'U3442', N'厦门大学嘉庚学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3448', N'UniversityInfo', N'U3443', N'集美大学诚毅学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3449', N'UniversityInfo', N'U3444', N'福州大学阳光学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3450', N'UniversityInfo', N'U3445', N'福州大学至诚学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3451', N'UniversityInfo', N'U3446', N'福建师范大学协和学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3452', N'UniversityInfo', N'U3447', N'福建师范大学闽南科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3453', N'UniversityInfo', N'U3448', N'福建农林大学东方学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3454', N'UniversityInfo', N'U3449', N'福建农林大学金山学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3455', N'UniversityInfo', N'U3450', N'华侨大学福建音乐学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3456', N'UniversityInfo', N'U3451', N'福建电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3457', N'UniversityInfo', N'U3452', N'福建对外经济贸易职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3458', N'UniversityInfo', N'U3453', N'福建警察学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3459', N'UniversityInfo', N'U3454', N'福建广播电视大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3460', N'UniversityInfo', N'U3455', N'福建华南女子职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3461', N'UniversityInfo', N'U3456', N'福建交通职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3462', N'UniversityInfo', N'U3457', N'福建教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3463', N'UniversityInfo', N'U3458', N'福建金融职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3464', N'UniversityInfo', N'U3459', N'福建警官职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3465', N'UniversityInfo', N'U3460', N'福建林业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3466', N'UniversityInfo', N'U3461', N'福建农业职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3467', N'UniversityInfo', N'U3462', N'福建商业高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3468', N'UniversityInfo', N'U3463', N'福建生物工程职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3469', N'UniversityInfo', N'U3464', N'福建水利电力职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3470', N'UniversityInfo', N'U3465', N'福建卫生职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3471', N'UniversityInfo', N'U3466', N'福建信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3472', N'UniversityInfo', N'U3467', N'福建行政学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3473', N'UniversityInfo', N'U3468', N'福建中医学院五洲科技学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3474', N'UniversityInfo', N'U3469', N'福州海峡职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3475', N'UniversityInfo', N'U3470', N'福州科技职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3476', N'UniversityInfo', N'U3471', N'福州黎明职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3477', N'UniversityInfo', N'U3472', N'福州软件职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3478', N'UniversityInfo', N'U3473', N'福州外语外贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3479', N'UniversityInfo', N'U3474', N'福州英华职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3480', N'UniversityInfo', N'U3475', N'福州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3481', N'UniversityInfo', N'U3476', N'黎明职业大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3482', N'UniversityInfo', N'U3477', N'湄洲湾职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3483', N'UniversityInfo', N'U3478', N'闽北职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3484', N'UniversityInfo', N'U3479', N'闽西职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3485', N'UniversityInfo', N'U3480', N'武夷学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3486', N'UniversityInfo', N'U3481', N'宁德师范高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3487', N'UniversityInfo', N'U3482', N'泉州纺织服装职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3488', N'UniversityInfo', N'U3483', N'泉州光电信息职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3489', N'UniversityInfo', N'U3484', N'泉州华光摄影艺术职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3490', N'UniversityInfo', N'U3485', N'泉州经贸职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3491', N'UniversityInfo', N'U3486', N'泉州信息职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3492', N'UniversityInfo', N'U3487', N'泉州医学高等专科学校', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3493', N'UniversityInfo', N'U3488', N'泉州理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3494', N'UniversityInfo', N'U3489', N'三明职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3495', N'UniversityInfo', N'U3490', N'厦门海洋职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3496', N'UniversityInfo', N'U3491', N'厦门华天涉外职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3497', N'UniversityInfo', N'U3492', N'厦门华厦职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3498', N'UniversityInfo', N'U3493', N'厦门南洋学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3499', N'UniversityInfo', N'U3494', N'厦门兴才职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3500', N'UniversityInfo', N'U3495', N'厦门演艺职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3501', N'UniversityInfo', N'U3496', N'漳州职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3502', N'UniversityInfo', N'U3497', N'福建政法管理干部学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3503', N'UniversityInfo', N'U3498', N'武夷职业技术学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3504', N'UniversityInfo', N'U3499', N'厦门城市职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3505', N'UniversityInfo', N'U3500', N'漳州卫生职业学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3506', N'UniversityInfo', N'U3501', N'国立台湾大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3507', N'UniversityInfo', N'U3502', N'国立中正大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3508', N'UniversityInfo', N'U3503', N'国立台湾艺术大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3509', N'UniversityInfo', N'U3504', N'国立清华大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3510', N'UniversityInfo', N'U3505', N'国立中山大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3511', N'UniversityInfo', N'U3506', N'国立政治大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3512', N'UniversityInfo', N'U3507', N'国立成功大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3513', N'UniversityInfo', N'U3508', N'国立中央大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3514', N'UniversityInfo', N'U3509', N'国立阳明大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3515', N'UniversityInfo', N'U3510', N'国立东华大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3516', N'UniversityInfo', N'U3511', N'国立中兴大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3517', N'UniversityInfo', N'U3512', N'国立台湾师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3518', N'UniversityInfo', N'U3513', N'国立台湾海洋大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3519', N'UniversityInfo', N'U3514', N'国立高雄大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3520', N'UniversityInfo', N'U3515', N'国立嘉义大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3521', N'UniversityInfo', N'U3516', N'国立台湾科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3522', N'UniversityInfo', N'U3517', N'国立空中大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3523', N'UniversityInfo', N'U3518', N'国立台北大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3524', N'UniversityInfo', N'U3519', N'国立高雄师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3525', N'UniversityInfo', N'U3520', N'国立联合大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3526', N'UniversityInfo', N'U3521', N'国立暨南国际大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3527', N'UniversityInfo', N'U3522', N'国立屏东科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3528', N'UniversityInfo', N'U3523', N'国立彰化师范大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3529', N'UniversityInfo', N'U3524', N'国立台北科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3530', N'UniversityInfo', N'U3525', N'国立台东大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3531', N'UniversityInfo', N'U3526', N'国立宜蓝大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3532', N'UniversityInfo', N'U3527', N'国立台北艺术大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3533', N'UniversityInfo', N'U3528', N'国立云林科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3534', N'UniversityInfo', N'U3529', N'国立台南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3535', N'UniversityInfo', N'U3530', N'国立虎尾科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3536', N'UniversityInfo', N'U3531', N'国立花莲教育大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3537', N'UniversityInfo', N'U3532', N'国立高雄第一科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3538', N'UniversityInfo', N'U3533', N'国立屏东教育大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3539', N'UniversityInfo', N'U3534', N'国立新竹教育大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3540', N'UniversityInfo', N'U3535', N'国立澎湖科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3541', N'UniversityInfo', N'U3536', N'建国科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3542', N'UniversityInfo', N'U3537', N'国立台南艺术大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3543', N'UniversityInfo', N'U3538', N'国立高雄应用科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3544', N'UniversityInfo', N'U3539', N'国立高雄海洋科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3545', N'UniversityInfo', N'U3540', N'国立勤益科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3546', N'UniversityInfo', N'U3541', N'东吴大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3547', N'UniversityInfo', N'U3542', N'香港大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3548', N'UniversityInfo', N'U3543', N'香港中文大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3549', N'UniversityInfo', N'U3544', N'香港科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3550', N'UniversityInfo', N'U3545', N'香港理工大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3551', N'UniversityInfo', N'U3546', N'香港城市大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3552', N'UniversityInfo', N'U3547', N'香港浸会大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3553', N'UniversityInfo', N'U3548', N'香港岭南大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3554', N'UniversityInfo', N'U3549', N'香港国际工商管理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3555', N'UniversityInfo', N'U3550', N'香港珠海学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3556', N'UniversityInfo', N'U3551', N'香港教育学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3557', N'UniversityInfo', N'U3552', N'香港树仁大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3558', N'UniversityInfo', N'U3553', N'香港演艺学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3559', N'UniversityInfo', N'U3554', N'澳门大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3560', N'UniversityInfo', N'U3555', N'澳门理工学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3561', N'UniversityInfo', N'U3556', N'澳门科技大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3562', N'UniversityInfo', N'U3557', N'澳门旅游学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3563', N'UniversityInfo', N'U3558', N'澳门镜湖护理学院', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3564', N'UniversityInfo', N'U3559', N'澳门国际公开大学', N'6', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3565', N'EducationInfo', N'Education', N'Education', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3566', N'EducationInfo', N'E3561', N'大学专科', N'3565', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3567', N'EducationInfo', N'E3562', N'大学本科', N'3565', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3568', N'EducationInfo', N'E3563', N'硕士研究生', N'3565', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3569', N'EducationInfo', N'E3564', N'博士研究生', N'3565', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3570', N'EmployeeStateInfo', N'EmployeeState', N'EmployeeState', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3571', N'EmployeeStateInfo', N'E3566', N'在项', N'3570', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3572', N'EmployeeStateInfo', N'E3567', N'离项', N'3570', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3573', N'EmployeeStateInfo', N'E3568', N'离职', N'3570', null, N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3574', N'CandidateCityInfo', N'CandidateCity', N'CandidateCity', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3575', N'CandidateCityInfo', N'CC01', N'不限', N'3574', N'1', N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3576', N'CandidateCityInfo', N'CC02', N'武汉', N'3574', N'2', N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3577', N'CandidateCityInfo', N'CC03', N'深圳', N'3574', N'3', N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3578', N'CandidateCityInfo', N'CC04', N'东莞', N'3574', N'4', N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3579', N'CandidateCityInfo', N'CC05', N'成都', N'3574', N'5', N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3580', N'CandidateCityInfo', N'CC06', N'广州', N'3574', N'6', N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3581', N'CandidateCityInfo', N'CC07', N'上海', N'3574', N'7', N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3582', N'CandidateCityInfo', N'CC08', N'大连', N'3574', N'8', N'')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3583', N'SkillInfo', N'Skill', N'Skill', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3584', N'SkillInfo', N'S01', N'JAVA', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3585', N'SkillInfo', N'S02', N'DOTNET', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3586', N'SkillInfo', N'S03', N'BI', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3587', N'SkillInfo', N'S04', N'DBA', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3588', N'SkillInfo', N'S05', N'H5', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3589', N'SkillInfo', N'S06', N'ANDROID', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3590', N'SkillInfo', N'S07', N'iOS', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3591', N'SkillInfo', N'S08', N'大数据（Hadoop、Spark等）', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3592', N'SkillInfo', N'S09', N'云计算（OpenStack、Azue等）', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3593', N'SkillInfo', N'S10', N'微服务', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3594', N'SkillInfo', N'S11', N'功能测试', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3595', N'SkillInfo', N'S12', N'性能测试', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3596', N'SkillInfo', N'S13', N'自动化测试', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3597', N'SkillInfo', N'S14', N'配置管理', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3598', N'SkillInfo', N'S15', N'敏捷开发', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3599', N'SkillInfo', N'S16', N'DevOps', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3600', N'SkillInfo', N'S17', N'ITIL', N'3583', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3601', N'DomainInfo', N'Domain', N'Domain', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3602', N'DomainInfo', N'D01', N'ERP', N'3601', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3603', N'DomainInfo', N'D02', N'CRM', N'3601', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3604', N'DomainInfo', N'D03', N'PLM', N'3601', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3605', N'DomainInfo', N'D04', N'FIN', N'3601', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3606', N'DomainInfo', N'D05', N'HR', N'3601', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3607', N'TaskStateInfo', N'TaskState', N'TaskState', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3608', N'TaskStateInfo', N'D01', N'开启', N'3607', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3609', N'TaskStateInfo', N'D02', N'结束', N'3607', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3610', N'ProficiencyInfo', N'Proficiency', N'Proficiency', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3611', N'ProficiencyInfo', N'PR01', N'了解', N'3610', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3612', N'ProficiencyInfo', N'PR02', N'掌握', N'3610', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3613', N'ProficiencyInfo', N'PR03', N'熟练', N'3610', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3614', N'ProficiencyInfo', N'PR04', N'精通', N'3610', null, N'                                                                                                    ')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3615', N'ReasonableObjectiveInfo', N'目标合理性', N'ReasonableObjective', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3616', N'ReasonableObjectiveInfo', N'RO01', N'质量目标合理性', N'3615', N'0', N'1')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3617', N'ReasonableObjectiveInfo', N'RO02', N'计划收入计划成本合理性', N'3615', N'0', N'2')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3618', N'ReasonableObjectiveInfo', N'RO03', N'变更修正合理性', N'3615', N'0', N'3')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3619', N'OperationStandardInfo', N'操作规范性', N'OperationStandard', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3620', N'OperationStandardInfo', N'OS01', N'立项结项及时性', N'3619', N'0', N'1')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3621', N'OperationStandardInfo', N'OS02', N'主项目子项目挂接正确性', N'3619', N'0', N'2')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3622', N'OperationStandardInfo', N'OS03', N'人力挂接项目（含IDLE）正确性', N'3619', N'0', N'3')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3623', N'OperationStandardInfo', N'OS04', N'项目评价合理性', N'3619', N'0', N'4')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3624', N'AccurateDataInfo', N'数据准确性', N'AccurateData', null, null, null)
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3625', N'AccurateDataInfo', N'AD01', N'质量评价数据填报准确性', N'3624', N'0', N'1')
GO
GO
INSERT INTO [dbo].[Dictionary] ([ID], [Type], [KeyName], [value], [ParentID], [SortIndex], [Remark]) VALUES (N'3626', N'AccurateDataInfo', N'AD02', N'人力地图数据准确性', N'3624', N'0', N'2')
GO
GO

-- ----------------------------
-- Indexes structure for table Dictionary
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table Dictionary
-- ----------------------------
ALTER TABLE [dbo].[Dictionary] ADD PRIMARY KEY ([ID])
GO
