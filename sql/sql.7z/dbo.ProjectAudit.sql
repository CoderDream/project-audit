/*
Navicat SQL Server Data Transfer

Source Server         : mssql
Source Server Version : 100000
Source Host           : 10.100.254.96:1433
Source Database       : BJC_Project_Audit
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 100000
File Encoding         : 65001

Date: 2017-08-10 17:42:22
*/


-- ----------------------------
-- Table structure for Dictionary
-- ----------------------------
DROP TABLE [dbo].[Dictionary]
GO
CREATE TABLE [dbo].[Dictionary] (
[ID] int NOT NULL ,
[Type] nvarchar(50) NULL ,
[KeyName] nvarchar(50) NULL ,
[value] nvarchar(50) NULL ,
[ParentID] int NULL ,
[SortIndex] int NULL ,
[Remark] nvarchar(100) NULL 
)


GO

-- ----------------------------
-- Table structure for Project
-- ----------------------------
DROP TABLE [dbo].[Project]
GO
CREATE TABLE [dbo].[Project] (
[ID] varchar(250) NOT NULL ,
[ParentID] varchar(250) NULL ,
[ProjectNo] varchar(250) NULL ,
[ProjectName] varchar(250) NULL ,
[ProjectMgr_WorkID] varchar(250) NULL ,
[ProjectMgr_Name] varchar(250) NULL ,
[Company] varchar(250) NULL ,
[DepartmentID] varchar(250) NULL ,
[DepartmentName] varchar(250) NULL ,
[OEProList] text NULL ,
[ProjectType] varchar(250) NULL ,
[ProjectSubType] varchar(250) NULL ,
[ProjectStartDate] datetime NULL ,
[ProjectEndDate] datetime NULL ,
[CustomerNo] varchar(250) NULL ,
[CustomerName] varchar(250) NULL ,
[CustomerDep] varchar(250) NULL ,
[ProductFamilyName] varchar(250) NULL ,
[ProductName] varchar(250) NULL ,
[Technology] varchar(250) NULL ,
[DeliveryType] varchar(250) NULL ,
[CustomerPM] varchar(250) NULL ,
[BU_Manager] varchar(250) NULL ,
[PersonTotal] int NULL ,
[CooperationType] varchar(250) NULL ,
[OBDORPPC] varchar(250) NULL ,
[WIP] decimal(10) NULL ,
[stock] decimal(10) NULL ,
[ProState] varchar(50) NULL ,
[isJump] varchar(50) NULL ,
[ProComputerTime] datetime NULL ,
[CreateWorkID] nvarchar(250) NULL ,
[BU_Manager_WorkID] varchar(250) NULL ,
[BU_Manager_Name] varchar(250) NULL ,
[Pro_ThreeDepartmentID] varchar(250) NULL ,
[Pro_ThreeDepartmentName] varchar(250) NULL ,
[Pro_FourDepartmentID] varchar(250) NULL ,
[Pro_FourDepartmentName] varchar(250) NULL ,
[ClientProductPM] varchar(250) NULL ,
[ClientProjectPM] varchar(250) NULL ,
[BJCProductPMWork_ID] varchar(250) NULL ,
[BJCProductPMName] varchar(250) NULL ,
[QAWork_ID] varchar(250) NULL ,
[QAName] varchar(250) NULL ,
[ProjectType2] varchar(250) NULL ,
[ProjectTechnosphere] varchar(250) NULL ,
[ProjectStartDateTime] datetime NULL ,
[ProjectEndDateTime] datetime NULL ,
[DeliveryAddress] varchar(250) NULL ,
[ISQASupport] varchar(250) NULL ,
[WorkEvaluate] varchar(250) NULL ,
[DemandRange] varchar(MAX) NULL ,
[ProStatePPC] varchar(250) NULL ,
[isJumpPPC] varchar(250) NULL ,
[BudgetCustomerNO] varchar(250) NULL ,
[BudgetCustomerName] varchar(250) NULL ,
[OEProjectNO] varchar(250) NULL ,
[OEProjectName] varchar(250) NULL ,
[EntryDate] datetime NULL ,
[BeProduct] varchar(250) NULL ,
[BeProductName] varchar(250) NULL ,
[IsOtherplace] varchar(250) NULL ,
[TeamSize] varchar(250) NULL ,
[CalendarID] int NULL ,
[CalendarName] varchar(100) NULL ,
[CreateName] varchar(250) NULL ,
[CreateDate] datetime NULL ,
[DeliveryCity] nvarchar(50) NULL ,
[DeliveryCityID] int NULL ,
[AreaType] nvarchar(250) NULL ,
[IsSite] nvarchar(250) NULL ,
[IsFinish] bit NULL ,
[EndName] varchar(1000) NULL ,
[ProjectAK] nvarchar(MAX) NULL ,
[IsOrder] varchar(200) NULL ,
[OrderDate] datetime NULL ,
[OrderMoney] decimal(18) NULL ,
[ApplicationDate] datetime NULL ,
[ProjectDescr] nvarchar(MAX) NULL ,
[ProjectTypes] varchar(200) NULL ,
[ContractNo] varchar(250) NULL ,
[ContractName] varchar(250) NULL ,
[ReadyType] varchar(500) NULL ,
[FirstCustomNo] varchar(200) NULL ,
[FirstCustomName] varchar(2000) NULL ,
[SecondCustomNo] varchar(200) NULL ,
[SecondCustomName] varchar(2000) NULL ,
[ThirdCustomNo] varchar(200) NULL ,
[ThirdCustomName] varchar(200) NULL ,
[LevelName] varchar(20) NULL ,
[IsOld] int NULL ,
[IsContinue] int NULL ,
[ProjectNewNo] varchar(250) NULL ,
[BaseType] varchar(200) NULL ,
[OverTimePayTimes] decimal(18,2) NULL ,
[PDRC] decimal(18,4) NULL ,
[PlanIncome] decimal(18,4) NULL ,
[PlanCost] decimal(18,4) NULL ,
[SubcontractorIncome] decimal(18,4) NULL ,
[SubcontractorCost] decimal(18,4) NULL ,
[IsTestProject] int NULL DEFAULT ((0)) ,
[PD_DepartID] varchar(200) NULL ,
[PD_DepartName] varchar(200) NULL ,
[MajorIncome] decimal(18,4) NULL ,
[MajorCost] decimal(18,4) NULL ,
[PassThroughIncome] decimal(18,4) NULL ,
[PassThroughCost] decimal(18,4) NULL ,
[TravelIncome] decimal(18,4) NULL ,
[TravelCost] decimal(18,4) NULL ,
[AdvanceIncome] decimal(18,4) NULL ,
[AdvanceCost] decimal(18,4) NULL ,
[SubsidyIncome] decimal(18,4) NULL ,
[SubsidyCost] decimal(18,4) NULL ,
[AttachIncome] decimal(18,4) NULL ,
[AttachCost] decimal(18,4) NULL ,
[InnerSubContractCount] int NULL ,
[InnerSubContractTotalCost] decimal(18,4) NULL 
)


GO

-- ----------------------------
-- Table structure for ProjectAudit
-- ----------------------------
DROP TABLE [dbo].[ProjectAudit]
GO
CREATE TABLE [dbo].[ProjectAudit] (
[ID] char(36) NOT NULL ,
[Audit_Type_Id] int NULL ,
[Audit_State] int NULL ,
[Audit_Work_Id] nvarchar(10) NULL ,
[Audit_Content] nvarchar(500) NULL ,
[Audit_Date] datetime NULL ,
[Project_Id] varchar(250) NULL 
)


GO

-- ----------------------------
-- Table structure for User
-- ----------------------------
DROP TABLE [dbo].[User]
GO
CREATE TABLE [dbo].[User] (
[ID] nvarchar(300) NOT NULL ,
[UserName] nvarchar(500) NOT NULL ,
[UserPWD] nvarchar(500) NOT NULL ,
[CreateDate] date NOT NULL ,
[DepartID] int NULL ,
[Email] nvarchar(200) NULL ,
[WorkId] nvarchar(10) NULL ,
[DepartName] nvarchar(200) NULL ,
[IsIntro] int NULL ,
[UserImage] image NULL ,
[IsLock] int NULL 
)


GO

-- ----------------------------
-- Indexes structure for table Dictionary
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table Dictionary
-- ----------------------------
ALTER TABLE [dbo].[Dictionary] ADD PRIMARY KEY ([ID])
GO

-- ----------------------------
-- Indexes structure for table Project
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table Project
-- ----------------------------
ALTER TABLE [dbo].[Project] ADD PRIMARY KEY ([ID])
GO

-- ----------------------------
-- Indexes structure for table User
-- ----------------------------
CREATE UNIQUE INDEX [IX_User] ON [dbo].[User]
([WorkId] ASC) 
GO

-- ----------------------------
-- Primary Key structure for table User
-- ----------------------------
ALTER TABLE [dbo].[User] ADD PRIMARY KEY ([ID])
GO
